#define Con_BYTECODE_VERSION 0
#define Con_BYTECODE_NUMBER_OF_MODULES 1
#define Con_BYTECODE_MODULES 2

#define Con_BYTECODE_MODULE_HEADER 0
#define Con_BYTECODE_MODULE_VERSION 2
#define Con_BYTECODE_MODULE_TYPE 3
#define Con_BYTECODE_MODULE_NAME 4
#define Con_BYTECODE_MODULE_NAME_SIZE 5
#define Con_BYTECODE_MODULE_FULL_NAME 6
#define Con_BYTECODE_MODULE_FULL_NAME_SIZE 7
#define Con_BYTECODE_MODULE_PROGRAM 8
#define Con_BYTECODE_MODULE_PROGRAM_SIZE 9
#define Con_BYTECODE_IMPORTS 10
#define Con_BYTECODE_NUM_IMPORTS 11
#define Con_BYTECODE_MODULE_LOCAL_VARS 12
#define Con_BYTECODE_MODULE_SRC_POSITIONS 13
#define Con_BYTECODE_MODULE_SRC_POSITIONS_SIZE 14
#define Con_BYTECODE_MODULE_NEWLINES 15
#define Con_BYTECODE_MODULE_NEWLINES_SIZE 16
#define Con_BYTECODE_MODULE_SIZE 17

#define Con_BYTECODE_MODULE_IMPORT_TYPE 0
#define Con_BYTECODE_MODULE_IMPORT_FULL_NAME_SIZE 1
#define Con_BYTECODE_MODULE_IMPORT_FULL_NAME 2

#define Con_IMPORT_BUILTIN 0
#define Con_IMPORT_CVB 1

#define Con_INSTR_ASSIGN 1                  // bits 0-7 1
#define Con_INSTR_VAR_LOOKUP 2              // bits 0-7 2, bits 8-19 continuation offset, bits 20-31 var number
#define Con_INSTR_VAR_REF 3                 // bits 0-7 3, bits 8-19 continuation offset, bits 20-31 var number
#define Con_INSTR_INT 4                     // bits 0-7 4, bits 8-30 integer value, bit 31 sign
#define Con_INSTR_ADD_FAILURE_FRAME 5       // bits 0-7 5, bits 8-30 pc offset, bit 31 offset sign
#define Con_INSTR_ADD_FAIL_UP_FRAME 6       // bits 0-7 6
#define Con_INSTR_REMOVE_FAILURE_FRAME 7    // bits 0-7 7
#define Con_INSTR_IS_ASSIGNED 8             // bits 0-7 8
#define Con_INSTR_IS 9                      // bits 0-7 9
#define Con_INSTR_FAIL_NOW 10               // bits 0-7 10
#define Con_INSTR_POP 11                    // bits 0-7 11
#define Con_INSTR_LIST 12                   // bits 0-7 12, bits 8-31 number of list elements
#define Con_INSTR_SLOT_LOOKUP 13            // bits 0-7 13, bits 8-31 size of slot name, bits 32-.. slot name
#define Con_INSTR_APPLY 14                  // bits 0-7 14, bits 8-15 number of args
#define Con_INSTR_FUNC_DEF 15               // bits 0-7 15, bits 8-15 is_bound, bits 16-23 size of function name, bits 24-31 number of local args
#define Con_INSTR_RETURN 16                 // bits 0-7 16
#define Con_INSTR_BRANCH 17                 // bits 0-7 17, bits 8-30 pc offset, bit 31 offset sign
#define Con_INSTR_YIELD 18                  // bits 0-7 18
#define Con_INSTR_PUSH_FAIL 19              // bits 0-7 19
#define Con_INSTR_IMPORT 20                 // bits 0-7 20, bits 8-31 module number
#define Con_INSTR_DICT 21                   // bits 0-7 21, bits 8-31 number of dictionary elements
#define Con_INSTR_DUP 22                    // bits 0-7 22
#define Con_INSTR_PULL 23                   // bits 0-7 23, bits 8-31 := number of entries back in the stack to pull the value from
#define Con_INSTR_CHANGE_FAIL_POINT 24      // bits 0-7 24, bits 8-30 pc offset, bit 31 offset sign
#define Con_INSTR_STRING 25                 // bits 0-7 25, bits 8-31 size of string, bits 32-.. string
#define Con_INSTR_BUILTIN_LOOKUP 26         // bits 0-7 26, bits 8-15 builtin number
#define Con_INSTR_SLOT_REF 27               // bits 0-7 13, bits 8-31 size of slot name, bits 32-.. slot name
#define Con_INSTR_EYIELD 28                 // bits 0-7 28
#define Con_INSTR_ADD_EXCEPTION_FRAME 29    // bits 0-7 5, bits 8-30 pc offset, bit 31 offset sign
#define Con_INSTR_PUSH_EXCEPTION 30         // bits 0-7 30
#define Con_INSTR_INSTANCE_OF 31            // bits 0-7 31
#define Con_INSTR_REMOVE_EXCEPTION_FRAME 32 // bits 0-7 32
#define Con_INSTR_RAISE 33                  // bits 0-7 33
#define Con_INSTR_SET_ITEM 34               // bits 0-7 34
#define Con_INSTR_EQUALS 35                 // bits 0-7 35
#define Con_INSTR_SUBTRACT 36               // bits 0-7 36
#define Con_INSTR_NOT_EQUALS 37             // bits 0-7 37
#define Con_INSTR_ADD 38                    // bits 0-7 38
#define Con_INSTR_LESS_THAN 39              // bits 0-7 39
#define Con_INSTR_GREATER_THAN 40           // bits 0-7 40
#define Con_INSTR_UNPACK_ARGS 41            // bits 0-7 = 41, bits 8-15 = num args, bits 16-24 = num mandatory args, bit 31 = has_var_args
#define Con_INSTR_GREATER_THAN_EQUALS 42    // bits 0-7 42
#define Con_INSTR_LESS_THAN_EQUALS 43       // bits 0-7 43
#define Con_INSTR_MUL 44                    // bits 0-7 44
#define Con_INSTR_DIVIDE 45                 // bits 0-7 45
#define Con_INSTR_MODULO 46                 // bits 0-7 46
#define Con_INSTR_SET 47                    // bits 0-7 47
#define Con_INSTR_BRANCH_IF_NOT_FAIL 48     // bits 0-7 48, bits 8-30 pc offset, bit 31 offset sign

void Con_Bytecode_append_cvb(Con_VM* vm, Con_Bytecode* bytecode);
Con_Module* Con_Bytecode_add_module(Con_VM* vm, Con_Bytecode* module_bytecode);
void Con_Bytecode_module_append(Con_VM* vm, int bytecode_offset);
char* Con_Bytecode_to_string(Con_VM* vm, int bytecode_offset);
int Con_Bytecode_align(int bytecode_offset);
