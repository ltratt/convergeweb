#include <string.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Bytecode.h"
#include "Memory.h"

#include "Builtins/Dict.h"
#include "Builtins/Func.h"
#include "Builtins/Func_Binding.h"
#include "Builtins/Module.h"
#include "Builtins/List.h"
#include "Builtins/String.h"
#include "Builtins/Set.h"
#include "Modules/File.h"
#include "Modules/Array.h"
#include "pcre.h"
#include "Modules/Mod_PCRE.h"

Con_Memory_Info Con_Memory_mem;

void Con_Memory_gcollect_continuation(Con_VM* vm, Con_Continuation* continuation);
void Con_Memory_gcollect_object(Con_VM* vm, Con_Object* object);
void Con_Memory_gcollect_conservative(Con_VM* vm, Con_Word* start_addr, Con_Word* end_addr);
void Con_Memory_mark_stack_push(Con_VM* vm, Con_Memory_Header* header);
void Con_Memory_mark_stack_push_value(Con_VM* vm, Con_Value value);
void Con_Memory_mark_stack_push_ptr(Con_VM* vm, void* ptr);
void Con_Memory_mark_stack_push_user_block(Con_VM* vm, void* ptr);



void* Con_malloc(Con_VM* vm, size_t size, Con_Memory_Type type)
{
	void* mem;
	void* new_entries;
	Con_Memory_Entry* entry;
	Con_Memory_Header* header;

	if (vm != NULL && vm->num_allocations_since_gc >= 25000) {
		Con_Memory_gcollect(vm);
		vm->num_allocations_since_gc = 0;
	}

	mem = malloc(size + sizeof(Con_Memory_Header));

	if (mem == NULL) {
		Con_Memory_gcollect(vm);
		mem = malloc(size + sizeof(Con_Memory_Header));
	
		if (mem == NULL) {
			CON_FATAL_ERROR("Out of memory");
		}
	}
	header = mem;
	header->flags = type;
	header->size = size;
	
	if (mem + sizeof(Con_Memory_Header) + size > Con_Memory_mem.high_addr)
		Con_Memory_mem.high_addr = mem + sizeof(Con_Memory_Header) + size;
	if (Con_Memory_mem.low_addr == NULL || mem < Con_Memory_mem.low_addr)
		Con_Memory_mem.low_addr = mem;

	if (type != Con_MEMORY_GC_NO_PTRS)
		bzero(mem + sizeof(Con_Memory_Header), size);

	if (type == Con_MEMORY_NON_GC)
		return mem + sizeof(Con_Memory_Header);
	
	if (Con_Memory_mem.num_entries == Con_Memory_mem.num_entries_allocated) {
		new_entries = realloc(Con_Memory_mem.entries, (Con_Memory_mem.num_entries_allocated + Con_MEMORY_NUM_ENTRIES_INCREMENT) * sizeof(Con_Memory_Entry));
		if (new_entries == NULL)
			CON_FATAL_ERROR("Unable to increase memory to handle more memory allocations");
		Con_Memory_mem.num_entries_allocated += Con_MEMORY_NUM_ENTRIES_INCREMENT;
		Con_Memory_mem.entries = new_entries;
	}

	entry = &Con_Memory_mem.entries[Con_Memory_mem.num_entries];
	entry->ptr = mem;
	
	Con_Memory_mem.num_entries += 1;
	
	vm->num_allocations_since_gc += 1;

	return mem + sizeof(Con_Memory_Header);
}



void* Con_realloc(Con_VM* vm, void *ptr, size_t size)
{
	void* new_ptr;
	int i, type;
	Con_Memory_Entry* entry;
	Con_Memory_Header* header;

	new_ptr = realloc(ptr - sizeof(Con_Memory_Header), size + sizeof(Con_Memory_Header));
	if (new_ptr == NULL) {
		Con_Memory_gcollect(vm);
		new_ptr = realloc(ptr - sizeof(Con_Memory_Header), size + sizeof(Con_Memory_Header));
		if (new_ptr == NULL)
			CON_FATAL_ERROR("Unable to increase memory allocation");
	}

	if (new_ptr + sizeof(Con_Memory_Header) + size > Con_Memory_mem.high_addr)
		Con_Memory_mem.high_addr = new_ptr + sizeof(Con_Memory_Header) + size;
	if (Con_Memory_mem.low_addr == NULL || new_ptr < Con_Memory_mem.low_addr)
		Con_Memory_mem.low_addr = new_ptr;
	vm->num_allocations_since_gc += 1;

	header = new_ptr;
	type = header->flags & Con_MEMORY_ENTRY_FLAGS_TYPE;
	if (type != Con_MEMORY_GC_NO_PTRS && size > header->size)
		bzero(new_ptr + sizeof(Con_Memory_Header) + header->size, size - header->size);
	if (type == Con_MEMORY_NON_GC) {
		header->size = size;
		return new_ptr + sizeof(Con_Memory_Header);
	}
	header->size = size;

	entry = Con_Memory_mem.entries;
	for (i = 0; i < Con_Memory_mem.num_entries; i++) {
		if (entry->ptr == ptr - sizeof(Con_Memory_Header)) {
			header = entry->ptr;
//			if (size > header->size)
//				bzero(new_ptr + sizeof(Con_Memory_Header) + header->size, size - header->size);
			entry->ptr = new_ptr;
			return new_ptr + sizeof(Con_Memory_Header);
		}
		entry += 1;
	}

	return new_ptr + sizeof(Con_Memory_Header);
}



void Con_free(Con_VM* vm, void* ptr)
{
	Con_Memory_Header* header = ptr - sizeof(Con_Memory_Header);

	if (ptr + sizeof(Con_Memory_Header) + header->size >= Con_Memory_mem.high_addr) {
		// This gets called fairly infrequently, but is probably worth the hit for the times it works
		Con_Memory_mem.high_addr = ptr;
	}
	if (ptr <= Con_Memory_mem.low_addr) {
		// This is pretty unlikely to get called to be honest... but you never know.
		Con_Memory_mem.low_addr = ptr + sizeof(Con_Memory_Header) + header->size;
	}

	free(ptr - sizeof(Con_Memory_Header));

/*	entry = Con_Memory_mem.entries;
	for (i = 0; i < Con_Memory_mem.num_entries; i++) {
		if (entry->ptr == ptr)
			XXX;
//			entry->ptr = new_ptr;
		entry += 1;
	} */
}



////////////////////////////////////////////////////////////////////////////////////////////////////
// Garbage collector routines
//

void Con_Memory_init(Con_VM* vm)
{
	Con_Memory_mem.low_addr = NULL;
	Con_Memory_mem.high_addr = NULL;
	Con_Memory_mem.num_entries = 0;
	Con_Memory_mem.num_entries_allocated = Con_MEMORY_DEFAULT_NUM_ENTRIES;
	Con_Memory_mem.entries = malloc(Con_Memory_mem.num_entries_allocated * sizeof(Con_Memory_Entry));
	if (Con_Memory_mem.entries == NULL)
		CON_FATAL_ERROR("Failed to initialize garbage collector.");
	Con_Memory_mem.mark_stack_size_allocated = Con_MEMORY_STACK_DEFAULT_SIZE;
	Con_Memory_mem.mark_stack = malloc(Con_Memory_mem.mark_stack_size_allocated * sizeof(Con_Memory_Entry));
	if (Con_Memory_mem.mark_stack == NULL)
		CON_FATAL_ERROR("Failed to initialize garbage collector.");
}



int _Con_Memory_entry_compare(const Con_Memory_Entry* e1, const Con_Memory_Entry* e2);

int _Con_Memory_entry_compare(const Con_Memory_Entry* e1, const Con_Memory_Entry* e2)
{
	if (e1->ptr < e2->ptr)
		return -1;
	if (e1->ptr == e2->ptr)
		return 0;
	return 1;
}


void Con_Memory_gcollect(Con_VM* vm)
{
	int i, type;
	Con_Memory_Entry* entry;
	Con_Object* object;
	Con_Continuation* continuation;
	Con_Memory_Header* header;
	jmp_buf env;

	// Flush the current jmp_buf. For 99% of platforms this is probably unnecessarily parnoid,
	// because all relevant info will probably have been stored in the current continuation's C stack
	// in the function call to Con_Memory_gcollect, but it's better to be safe than sorry.
	//
	// We flush the jmp_buf here before it potentially becomes contaminated with pointers to objects
	// that might actually be garbage collectable.

	setjmp(env);

#ifdef HAVE_MERGESORT

	// mergesort is normally a touch quicker for this (because the entries are often largely
	// sorted), but requires extra memory, so we try mergesort first and only fall back on qsort
	// (which doesn't require extra memory) if we have to.
	//
	// The cast for _Con_Memory_entry_compare is just to shut the compiler up. I know it's evil.

	if (mergesort(Con_Memory_mem.entries, Con_Memory_mem.num_entries, sizeof(Con_Memory_Entry), (void*) _Con_Memory_entry_compare) == -1)
		qsort(Con_Memory_mem.entries, Con_Memory_mem.num_entries, sizeof(Con_Memory_Entry), (void*) _Con_Memory_entry_compare);
		
#else

	qsort(Con_Memory_mem.entries, Con_Memory_mem.num_entries, sizeof(Con_Memory_Entry), (void*) _Con_Memory_entry_compare);
	
#endif /* HAVE_MERGESORT */

	// Reset all the mark bits

	entry = Con_Memory_mem.entries;
	Con_Memory_mem.mark_stack_size = 0;
	for (i = 0; i < Con_Memory_mem.num_entries; i += 1) {
		header = entry->ptr;
		header->flags &= ~Con_MEMORY_ENTRY_MARK_BIT;
		entry += 1;
	}
	entry = NULL;
	header = NULL;
	
	// Actually GC the jmp_buf
	
	Con_Memory_gcollect_conservative(vm, (void*) &env, ((void*) &env) + sizeof(jmp_buf));
	
	// Push the current continuation
	
	Con_Memory_mark_stack_push_user_block(vm, vm->continuation);
	
	// Push the builtin objects
	
	for (i = 0; i < CON_NUMBER_OF_BUILTINS; i += 1) {
		Con_Memory_mark_stack_push_value(vm, vm->builtins[i]);
	}
	
	// Push all imported modules
	
	for (i = 0; i < vm->modules_size; i += 1) {
		Con_Memory_mark_stack_push_value(vm, vm->modules[i]->module_val);
	}
	
	// Traverse entries

//	printf("traversing...\n");
	while (Con_Memory_mem.mark_stack_size > 0) {
//		printf("%d\n", Con_Memory_mem.mark_stack_size);
		header = Con_Memory_mem.mark_stack[--Con_Memory_mem.mark_stack_size];
		type = header->flags & Con_MEMORY_ENTRY_FLAGS_TYPE;
		if (type == Con_MEMORY_OBJECT) {
			Con_Memory_gcollect_object(vm, ((void*) header) + sizeof(Con_Memory_Header));
		}
		else if (type == Con_MEMORY_GC) {
			Con_Memory_gcollect_conservative(vm, ((void*) header) + sizeof(Con_Memory_Header), ((void*) header) + sizeof(Con_Memory_Header) + header->size);
		}
		else if (type == Con_MEMORY_GC_NO_PTRS) {
			// do nothing
		}
		else {
			printf("%d\n", header->flags & Con_MEMORY_ENTRY_FLAGS_TYPE);
			XXX
		}
	}
//	printf("num entries=%d\n", Con_Memory_mem.num_entries);
	i = 0;
	while (i < Con_Memory_mem.num_entries) {
		header = Con_Memory_mem.entries[i].ptr;
		if (!(header->flags & Con_MEMORY_ENTRY_MARK_BIT)) {
			type = header->flags & Con_MEMORY_ENTRY_FLAGS_TYPE;
			if (type == Con_MEMORY_GC || type == Con_MEMORY_GC_NO_PTRS) {
				Con_free(vm, header + 1);
			}
			else {
				object = (Con_Object*) (header + 1);

//				printf("object @ %x type %d free\n", entry->ptr, object->type);
				switch (object->type) {
					case CON_OBJECT_STRING:
						// fall through
					case CON_OBJECT_FUNC_BINDING:
						break;
					case CON_OBJECT_CONTINUATION:
						continuation = (Con_Continuation*) object;
						if (continuation->c_stack_start != NULL) {
							Con_free(vm, continuation->c_stack_start);
							Con_free(vm, continuation->con_stack_start);
						}
						Con_free(vm, continuation->vars);
						break;
					case CON_OBJECT_LIST:
						Con_free(vm, ((Con_List*) object)->items);
						break;
					case CON_OBJECT_DICT:
						Con_free(vm, ((Con_Dict_Object*) object)->items);
						break;
					case CON_OBJECT_FILE:
						// Since we're garbage collecting, we ignore any errors from closing the file.
						fclose(((Con_File_Object*) object)->file);
						break;
					case CON_MOD_ARRAY_ARRAY:
						Con_free(vm, ((Con_Mod_Array_Array_Object*) object)->elements);
						break;
					case CON_OBJECT_SET:
						Con_free(vm, ((Con_Set_Object*) object)->items);
						break;
					case CON_OBJECT_PCRE_PATTERN:
						free(((Con_PCRE_Pattern_Object*) object)->compiled_re);
						break;
					case CON_OBJECT_PCRE_MATCH:
						break;
					case CON_OBJECT_FUNC:
						// fall through
					case CON_OBJECT_MODULE:
						// fall through
					case CON_NORMAL_OBJECT:
						// fall through
						break;
					default:
						printf("%d\n", object->type);
						XXX;
				}
				if (object->slots != NULL) {
					Con_free(vm, object->slots);
					Con_free(vm, object->slots_names);
				}
				Con_free(vm, header + 1);
			}
			// Rather than shuffling memory down, we simply copy the last memory entry to the current
			// position. This is a *big* saving over shuffling. It does mean that the list will
			// quickly become unsorted, and that assumes this isn't a problem for this chunk of code
			Con_Memory_mem.entries[i] = Con_Memory_mem.entries[Con_Memory_mem.num_entries - 1];
			Con_Memory_mem.num_entries -= 1;
		}
		else {
//			printf("entry @ %x type %d in use\n", entry->ptr, header->flags & Con_MEMORY_ENTRY_FLAGS_TYPE);
			i += 1;
		}
	}
	
//	printf("gc done\n");
}



void Con_Memory_gcollect_object(Con_VM* vm, Con_Object* object)
{
	Con_List* list_obj;
	Con_Dict_Object* dict_obj;
	Con_Object_Func* func_obj;
	Con_Object_Func_Binding* func_obj_binding;
	Con_Set_Object* set_obj;
	Con_Slot* slot;
	int i;

	switch (object->type) {
		case CON_OBJECT_CONTINUATION:
			Con_Memory_gcollect_continuation(vm, (Con_Continuation*) object);
			break;
		case CON_OBJECT_LIST:
			list_obj = (Con_List*) object;
			for (i = 0; i < list_obj->list_size; i += 1) {
				Con_Memory_mark_stack_push_value(vm, list_obj->items[i]);
			}
			break;
		case CON_OBJECT_FUNC:
			func_obj = (Con_Object_Func*) object;
			if (func_obj->parent_continuation != NULL)
				Con_Memory_mark_stack_push_user_block(vm, func_obj->parent_continuation);
			break;
		case CON_OBJECT_FUNC_BINDING:
			func_obj_binding = (Con_Object_Func_Binding*) object;
			Con_Memory_mark_stack_push_value(vm, func_obj_binding->self_obj);
			Con_Memory_mark_stack_push_value(vm, func_obj_binding->func);
			break;
		case CON_OBJECT_DICT:
			dict_obj = (Con_Dict_Object*) object;
			for (i = 0; i < dict_obj->num_items; i += 1) {
				Con_Memory_mark_stack_push_value(vm, dict_obj->items[i].key);
				Con_Memory_mark_stack_push_value(vm, dict_obj->items[i].value);
			}
			break;
		case CON_OBJECT_SET:
			set_obj = (Con_Set_Object*) object;
			for (i = 0; i < set_obj->num_items; i += 1) {
				Con_Memory_mark_stack_push_value(vm, set_obj->items[i].val);
			}
			break;
		case CON_OBJECT_PCRE_PATTERN:
			break;
		case CON_OBJECT_PCRE_MATCH:
			if (((Con_PCRE_Match_Object*) object)->ovector != NULL)
				Con_Memory_mark_stack_push_user_block(vm, ((Con_PCRE_Match_Object*) object)->ovector);
			break;
		case CON_OBJECT_FILE:
			// fall through
		case CON_OBJECT_STRING:
			// fall through
		case CON_OBJECT_MODULE:
			// fall through
		case CON_NORMAL_OBJECT:
			// fall through
		case CON_OBJECT_BACKTRACE:
			// fall through
		case CON_OBJECT_META_C_CLASS:
			// fall through
		case CON_MOD_ARRAY_ARRAY:
			break;
		default:
			printf("%d\n", object->type);
			XXX;
	}

	if (object->slots != NULL) {
		slot = (Con_Slot*) object->slots;
		for (i = 0; i < object->num_slots; i += 1) {
			Con_Memory_mark_stack_push_value(vm, slot->value);
			slot += 1;
		}
	}
}



void Con_Memory_gcollect_continuation(Con_VM* vm, Con_Continuation* continuation)

{
	int slot_name_size;
	int i;
	void* stack_current;
	Con_VM_Stack_Generator_Frame* generator_frame;
	
	stack_current = continuation->con_stack;

	if (continuation->parent_continuation != NULL)
		Con_Memory_mark_stack_push_user_block(vm, continuation->parent_continuation);

	if (continuation->calling_continuation != NULL)
		Con_Memory_mark_stack_push_user_block(vm, continuation->calling_continuation);

//	if (continuation->module != NULL)
//		Con_Memory_mark_stack_push_ptr(vm, continuation->module);

	Con_Memory_mark_stack_push_value(vm, continuation->function);
	Con_Memory_mark_stack_push_value(vm, continuation->current_exception);

	for (i = 0; i < continuation->num_local_vars; i += 1) {
		Con_Memory_mark_stack_push_value(vm, continuation->local_vars[i]);
	}

	// We don't need to worry about stuff pointed to in the two stacks of a continuation iff the continuation has been
	// returned, so skip it.

	if (continuation->pc_type != PC_TYPE_NULL) {
		while (stack_current != continuation->con_stack_start) {
			stack_current -= sizeof(Con_VM_Stack_Types);
			switch (*((Con_VM_Stack_Types*) stack_current)) {
				case CON_VM_STACK_VALUE:
					stack_current -= sizeof(Con_Value);
					Con_Memory_mark_stack_push_value(vm, *((Con_Value*) stack_current));
					break;
				case CON_VM_STACK_VAR_REF:
					stack_current -= sizeof(Con_VM_Stack_Var_Ref);
					break;
				case CON_VM_STACK_SLOT_REF:
					slot_name_size = *((int*) stack_current - 1);
					stack_current -= sizeof(int) + Con_Bytecode_align(slot_name_size + 1) + sizeof(Con_Value);
					Con_Memory_mark_stack_push_value(vm, *((Con_Value*) stack_current));
					break;
				case CON_VM_STACK_FAILURE_FRAME:
					stack_current -= sizeof(Con_VM_Stack_Failure_Frame);
					break;
				case CON_VM_STACK_GENERATOR_FRAME:
					stack_current -= sizeof(Con_VM_Stack_Generator_Frame);
					generator_frame = (Con_VM_Stack_Generator_Frame*) stack_current;
					Con_Memory_mark_stack_push_user_block(vm, generator_frame->continuation);
					Con_Memory_gcollect_conservative(vm, (void*) generator_frame->env, ((void*) generator_frame->env) + sizeof(jmp_buf));
					break;
				case CON_VM_STACK_EXCEPTION_FRAME:
					stack_current -= sizeof(Con_VM_Stack_Exception_Frame);
					break;
				default:
					printf("%d\n", *((Con_VM_Stack_Types*) stack_current));
					XXX;
			}
		}
		Con_Memory_gcollect_conservative(vm, continuation->c_stack_start, continuation->c_stack_end);
		Con_Memory_gcollect_conservative(vm, (void*) &continuation->return_env, ((void*) &continuation->return_env) + sizeof(jmp_buf));
	}
	else {
		if (continuation->c_stack_start != NULL) {
			Con_free(vm, continuation->c_stack_start);
			Con_free(vm, continuation->con_stack_start);
			continuation->c_stack_start = NULL;
			continuation->con_stack_start = NULL;
		}
	}
}



void Con_Memory_gcollect_conservative(Con_VM* vm, Con_Word* start_addr, Con_Word* end_addr)
{
	Con_Word* current_addr = start_addr;

	while (current_addr < end_addr) {
		Con_Memory_mark_stack_push_ptr(vm, (void*) *current_addr);
		current_addr += 1;
	}
}



void Con_Memory_mark_stack_push(Con_VM* vm, Con_Memory_Header* header)
{
	if ((header->flags & Con_MEMORY_ENTRY_MARK_BIT) == 0) {
		if (Con_Memory_mem.mark_stack_size == Con_Memory_mem.mark_stack_size_allocated)
			XXX;

		header->flags |= Con_MEMORY_ENTRY_MARK_BIT;
		Con_Memory_mem.mark_stack[Con_Memory_mem.mark_stack_size++] = header;
	}
}



void Con_Memory_mark_stack_push_value(Con_VM* vm, Con_Value value)
{
	Con_Memory_Header* header;

	switch (value.type) {
		case CON_VALUE_INT:
			break;
		case CON_VALUE_OBJECT:
			header = ((void*) value.datum.object) - sizeof(Con_Memory_Header);
			if (!(header->flags & Con_MEMORY_ENTRY_MARK_BIT))
				Con_Memory_mark_stack_push(vm, header);
			break;
		case CON_VALUE_UNASSIGNED:
			break;
		default:
			printf("%d %d\n", value.type, CON_VALUE_ILLEGAL);
			CON_FATAL_ERROR("Trying to push non-value onto the stack");
	}
}



void Con_Memory_mark_stack_push_ptr(Con_VM* vm, void* ptr)
{
	Con_Memory_Entry* entry;
	Con_Memory_Header* header;
	int high = Con_Memory_mem.num_entries, low = -1, probe;

	if ((ptr < Con_Memory_mem.low_addr) || (ptr > Con_Memory_mem.high_addr))
		return;
	
	while (high - low > 1) {
		probe = (high + low) / 2;
		entry = Con_Memory_mem.entries + probe;
		if (entry->ptr > ptr)
			high = probe;
		else
			low = probe;
	}
	if (low == -1)
		return;
		
	entry = Con_Memory_mem.entries + low;
	header = entry->ptr;
	
	// Save ourselves some time by not going forward with pointless comparisons if this entry is
	// already marked to be saved
	if (header->flags & Con_MEMORY_ENTRY_MARK_BIT)
		return;

	if ((ptr >= entry->ptr + sizeof(sizeof(Con_Memory_Header))) && (ptr < entry->ptr + sizeof(Con_Memory_Header) + header->size)) {
		Con_Memory_mark_stack_push(vm, header);
	}
}



void Con_Memory_mark_stack_push_user_block(Con_VM* vm, void* ptr)
{
	Con_Memory_mark_stack_push(vm, ptr - sizeof(Con_Memory_Header));
}
