#ifndef Con_OBJECT_H
#define Con_OBJECT_H

Con_Value Con_Object_get_slot(Con_VM* vm, Con_Value value, const char* slot_name);
Con_Value Con_Object_get_slot_raw(Con_VM* vm, Con_Value value, const char* slot_name);
void Con_Object_set_slot(Con_VM* vm, Con_Value value, const char* slot_name, Con_Value slot_value);
void Con_Object_set_slot_raw(Con_VM* vm, Con_Value value, const char* slot_name, Con_Value slot_value);
Con_Value Con_Object_new(Con_VM* vm);
void Con_Object_init(Con_VM* vm, Con_Object* obj);
bool Con_Object_has_slot(Con_VM* vm, Con_Value value, const char* slot_name);
bool Con_Object_has_slot_raw(Con_VM* vm, Con_Value value, const char* slot_name);

#endif /* Con_OBJECT_H */
