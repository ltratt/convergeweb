#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Bytecode.h"
#include "Memory.h"
#include "Object.h"
#include "Import.h"
#include "Builtins/String.h"
#include "Builtins/List.h"
#include "Builtins/Module.h"
#include "Builtins/Func.h"
#include "Builtins/Func_Binding.h"
#include "Builtins/Object_Class.h"
#include "Builtins/Class_Class.h"
#include "Builtins/Dict.h"
#include "Builtins/Int.h"
#include "Builtins/Backtrace.h"
#include "Builtins/Null_Class.h"
#include "Builtins/Set.h"
#include "Builtins/Meta_C_Class.h"
#include "Modules/Backtrace.h"
#include "Modules/Exceptions.h"




// This variable temporarily holds a pointer to the current VM when a longjmp is done. This is safe
// in normal contexts, but would need to be protected by a mutex in a multi-threaded environment, or
// somehow embedded in the longjmp environment.

Con_VM* Con_VM_execute_vm_switch;
void Con_VM_main_loop(void);

void Con_VM_unpack_args(Con_VM* vm, int num_args_required, int num_mandatory_args, bool has_var_args);

void _Con_VM_con_stack_ensure_room(Con_VM* vm, Con_Continuation* continuation, int size);



Con_VM* Con_VM_create(char** argv, int argc, char* program_path)
{
	Con_VM* vm = NULL;
	int i;

	vm = Con_malloc(vm, sizeof(Con_VM), Con_MEMORY_NON_GC);

	vm->bytecode_size = 0;
	vm->continuation = NULL;
	vm->state = VM_INITIALIZING;
	vm->num_allocations_since_gc = 0;
	vm->argc = argc;
	vm->argv = argv;
	vm->program_path = program_path;
	vm->modules_size = 0;

	vm->bytecode = Con_malloc(vm, 0, Con_MEMORY_NON_GC);
	vm->modules = Con_malloc(vm, CON_VM_MODULES_SIZE_ALLOCATED_INITIAL * sizeof(Con_Module*), Con_MEMORY_NON_GC);
	vm->modules_size_allocated = CON_VM_MODULES_SIZE_ALLOCATED_INITIAL;

	/* Initialize builtins */
	
	for (i = 0; i < CON_NUMBER_OF_BUILTINS; i += 1) {
		vm->builtins[i] = Con_Object_new(vm);
		Con_Object_set_slot(vm, vm->builtins[i], "instance_of", vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	}
	Con_Object_Class_bootstrap(vm);
	Con_Class_Class_bootstrap(vm);  // must be bootstrapped after Object_Class
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));

	Con_String_class_bootstrap(vm);
	Con_List_class_bootstrap(vm);
	Con_Module_class_bootstrap(vm);
	Con_Func_class_bootstrap(vm);
	Con_Dict_class_bootstrap(vm);
	Con_Func_Binding_class_bootstrap(vm);
	Con_Int_Class_bootstrap(vm);
	Con_Backtrace_Class_bootstrap(vm);
	Con_Null_Class_bootstrap(vm);
	Con_Set_class_bootstrap(vm);
	
	return vm;
}



void Con_VM_init(Con_VM* vm)
{
	Con_Meta_C_Class_bootstrap(vm);

	vm->builtins[CON_BUILTIN_EXCEPTIONS_MODULE] = Con_Import_builtin_module(vm, "Exceptions");
	vm->builtins[CON_BUILTIN_SYS_MODULE] = Con_Import_builtin_module(vm, "Sys");
	vm->builtins[CON_BUILTIN_BACKTRACE_MODULE] = Con_Import_builtin_module(vm, "Backtrace");
	
	vm->state = VM_NORMAL;
}



Con_Continuation* Con_VM_continuation_create(Con_VM* vm, int num_vars, Con_Continuation* calling_continuation, Con_Continuation* parent_continuation, Con_Module* module, Con_Value function)
{
	Con_Continuation* continuation;
	int i, num_ancestors;

	continuation = Con_malloc(vm, sizeof(Con_Continuation), Con_MEMORY_OBJECT);
	Con_Object_init(vm, (Con_Object*) continuation);
	continuation->c_stack_start = Con_malloc(vm, DEFAULT_C_STACK_SIZE * sizeof(Con_Word), Con_MEMORY_NON_GC);
	continuation->con_stack = continuation->con_stack_start = Con_malloc(vm, DEFAULT_CON_STACK_SIZE, Con_MEMORY_NON_GC);

	continuation->type = CON_OBJECT_CONTINUATION;
	continuation->pc_type = PC_TYPE_BYTECODE;
	
	continuation->c_stack_end = continuation->c_stack_start + DEFAULT_C_STACK_SIZE - 1;

	continuation->con_stack_end = continuation->con_stack_start + DEFAULT_CON_STACK_SIZE;

	if (parent_continuation != NULL)
		num_ancestors = parent_continuation->num_ancestors;
	else
		num_ancestors = 0;

	continuation->vars = Con_malloc(vm, (num_ancestors + 1) * sizeof(Con_Value**) + num_vars * sizeof(Con_Value), Con_MEMORY_NON_GC);

	continuation->num_ancestors = num_ancestors + 1;
	continuation->continuation_vars = continuation->vars;
	continuation->local_vars = continuation->vars + (num_ancestors + 1) * sizeof(Con_Value**);
	continuation->num_local_vars = num_vars;
	
	continuation->continuation_vars[0] = continuation;
	if (parent_continuation != NULL)
		memmove(continuation->continuation_vars + 1, parent_continuation->vars, num_ancestors * sizeof(Con_Value**));
	
	for (i = 0; i < num_vars; i += 1) {
		continuation->local_vars[i].type = CON_VALUE_UNASSIGNED;
	}
	continuation->efp = -1;
	continuation->gfp = -1;
	continuation->xfp = -1;
	continuation->module = module;
	continuation->function = function;
	continuation->current_exception = vm->builtins[CON_BUILTIN_NULL_VAL];
	continuation->calling_continuation = calling_continuation;
	continuation->parent_continuation = parent_continuation;

	return continuation;
}



void Con_VM_execute(Con_VM* vm, Con_Continuation* new_continuation, void* return_addr, Con_PC return_pc, Con_PC_Type return_pc_type)
{
	jmp_buf env;
	
	if (vm->continuation != NULL) {
		if (setjmp(new_continuation->return_env) > 0) {
			return;
		}
		else {
			if (return_addr != NULL) {
#if defined(__OpenBSD__) && defined(Con_C_STACK_GROWS_DOWN)
				new_continuation->return_env[0] = (long) return_addr;
				new_continuation->return_env[2] = (long) vm->continuation->c_stack_end;
#elif defined(__FreeBSD__) && defined(Con_C_STACK_GROWS_DOWN)
				new_continuation->return_env->_jb[0] = (int) return_addr;
				new_continuation->return_env->_jb[2] = (int) vm->continuation->c_stack_end;
#elif defined(__linux__) && defined(Con_C_STACK_GROWS_DOWN)
			    new_continuation->return_env->__jmpbuf[JB_SP] = (int) vm->continuation->c_stack_end;
			    new_continuation->return_env->__jmpbuf[JB_PC] = (int) return_addr;
#elif defined(__CYGWIN__)
				new_continuation->return_env[8] = (int) return_addr;
				new_continuation->return_env[7] = (int) vm->continuation->c_stack_end;
#else
				XXX;
#endif
				new_continuation->return_is_simple = false;
			}
			else
				new_continuation->return_is_simple = true;
			new_continuation->return_pc = return_pc;
			new_continuation->return_pc_type = return_pc_type;
		}
	}
	vm->continuation = new_continuation;
	setjmp(env);
#if defined(__OpenBSD__) && defined(Con_C_STACK_GROWS_DOWN)
	env[0] = (long) Con_VM_main_loop;
	env[2] = (long) vm->continuation->c_stack_end;
#elif defined(__FreeBSD__) && defined(Con_C_STACK_GROWS_DOWN)
	env->_jb[0] = (int) Con_VM_main_loop;
	env->_jb[2] = (int) vm->continuation->c_stack_end;
#elif defined(__linux__) && defined(Con_C_STACK_GROWS_DOWN)
    env->__jmpbuf[JB_SP] = (int) vm->continuation->c_stack_end;
    env->__jmpbuf[JB_PC] = (int) Con_VM_main_loop;
#elif defined(__CYGWIN__)
    env[8] = (int) Con_VM_main_loop;
    env[7] = (int) vm->continuation->c_stack_end;
#else
	XXX;
#endif
	Con_VM_execute_vm_switch = vm;
	longjmp(env, 1);
}



void Con_VM_main_loop(void)
{
	Con_VM* vm = NULL;
	Con_PC pc;
	Con_Value new_func, val, val2, int_val, new_set;
	Con_VM_Stack_Var_Ref var_ref;
	int i, instruction, size_of_instruction, fail_point, offset;

//	if (vm->continuation->calling_continuation != NULL && vm->continuation->c_stack_end == (void*) vm->continuation->return_env[2])
//		bzero(vm->continuation->calling_continuation->c_stack_start, DEFAULT_C_STACK_SIZE * sizeof(Con_Word));

	while (1) {
//		printf("%p\n", vm);
//Con_Memory_gcollect(vm);
//if (vm->continuation->module != NULL && vm->continuation->module->imports != NULL)
//printf("%s\n", vm->continuation->module->imports[1].full_name);
		vm = Con_VM_execute_vm_switch;
		if (vm->num_allocations_since_gc >= 5000) {
			Con_Memory_gcollect(vm);
			vm->num_allocations_since_gc = 0;
		}
		if (vm->continuation->pc_type == PC_TYPE_BYTECODE) {
			instruction = vm->bytecode[vm->continuation->pc.bytecode / sizeof(Con_Bytecode)];
#if DEBUG
			{
				int len_instr;
				char* decoded;
				
				decoded = Con_Bytecode_to_string(vm, vm->continuation->pc.bytecode);
				printf("  %d %s %n", vm->continuation->pc.bytecode, decoded, &len_instr);
				Con_free(vm, decoded);
				for (i = len_instr; i < 29; i += 1) {
					printf(" ");
				}
				Con_VM_print_stack(vm);
				printf("\n");
				printf("                             continuation=%p efp=%d gfp=%d\n", vm->continuation, vm->continuation->efp, vm->continuation->gfp);
			}
#endif
			switch (instruction & 0x000000FF) {
				case Con_INSTR_ASSIGN:
					Con_VM_assign(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_POP:
					Con_VM_con_stack_pop(vm, vm->continuation);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_VAR_REF:
					Con_VM_con_stack_push_var_ref(vm, vm->continuation, (instruction & 0x000FFF00) >> 8, (instruction & 0xFFF00000) >> 20);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_PULL:
					Con_VM_con_stack_pull(vm, vm->continuation, (instruction & 0xFFFFFF00) >> 8);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_BUILTIN_LOOKUP:
					Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[(instruction & 0x0000FF00) >> 8]);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_FUNC_DEF:
					size_of_instruction = Con_Bytecode_align(sizeof(Con_Bytecode) + ((instruction & 0x00FF0000) >> 16) + 1);
					pc.bytecode = vm->continuation->pc.bytecode + size_of_instruction + sizeof(Con_Bytecode);
					new_func = Con_Func_new(vm, (instruction & 0x0000FF00) >> 8, pc, PC_TYPE_BYTECODE, Con_String_new(vm, (char*) &vm->bytecode[(vm->continuation->pc.bytecode + sizeof(Con_Bytecode)) / sizeof(Con_Bytecode)], (instruction & 0x00FF0000) >> 16), (instruction & 0xFF000000) >> 24, vm->continuation, vm->continuation->module);
					Con_VM_con_stack_push_value(vm, vm->continuation, new_func);
					vm->continuation->pc.bytecode += size_of_instruction;
					break;
				case Con_INSTR_BRANCH:
					offset = (instruction & 0x7FFFFF00) >> 8;
					if (instruction & (1 << 31))
						offset = -offset;
					vm->continuation->pc.bytecode += offset;
					break;
				case Con_INSTR_DICT:
					Con_VM_con_stack_push_value(vm, vm->continuation, Con_Dict_new_init_from_stack(vm, (instruction & 0xFFFFFF00) >> 8));
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_ADD_FAILURE_FRAME:
					if (instruction & (1 << 31))
						pc.bytecode = vm->continuation->pc.bytecode - ((instruction & 0x7FFFFF00) >> 8);
					else
						pc.bytecode = vm->continuation->pc.bytecode + ((instruction & 0x7FFFFF00) >> 8);
					Con_VM_add_failure_frame(vm, pc, PC_TYPE_BYTECODE);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_IS_ASSIGNED:
					var_ref = Con_VM_con_stack_pop_var_ref(vm, vm->continuation);
					if (!Con_VM_var_is_assigned(vm, vm->continuation, var_ref.continuation_offset, var_ref.var_number))
						Con_VM_fail(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_REMOVE_FAILURE_FRAME:
					Con_VM_remove_failure_frame(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_DUP:
					Con_VM_con_stack_dup(vm, vm->continuation);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_SLOT_LOOKUP:
					Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, Con_VM_con_stack_pop_value(vm, vm->continuation), ((char*) vm->bytecode) + vm->continuation->pc.bytecode + sizeof(Con_Bytecode)));
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode) + Con_Bytecode_align(((instruction & 0xFFFFFF00) >> 8) + 1);
					break;
				case Con_INSTR_STRING:
					Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new(vm, ((char*) vm->bytecode) + vm->continuation->pc.bytecode + sizeof(Con_Bytecode), (int) (instruction & 0xFFFFFF00) >> 8));
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode) + Con_Bytecode_align(((instruction & 0xFFFFFF00) >> 8) + 1);
					break;
				case Con_INSTR_VAR_LOOKUP:
					Con_VM_con_stack_push_value(vm, vm->continuation, Con_VM_var_lookup(vm, vm->continuation, (instruction & 0x000FFF00) >> 8, (instruction & 0xFFF00000) >> 20));
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_SLOT_REF:
					Con_VM_con_stack_push_slot_ref_with_size(vm, vm->continuation, Con_VM_con_stack_pop_value(vm, vm->continuation), ((char*) vm->bytecode) + vm->continuation->pc.bytecode + sizeof(Con_Bytecode), (int) (instruction & 0xFFFFFF00) >> 8);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode) + Con_Bytecode_align(((instruction & 0xFFFFFF00) >> 8) + 1);
					break;
				case Con_INSTR_SET_ITEM:
					Con_VM_set_item(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_RETURN:
					Con_VM_return(vm);
					break; // even though it won't get this far
				case Con_INSTR_INT:
					int_val.type = CON_VALUE_INT;
					int_val.datum.integer = (instruction & 0x7FFFFF00) >> 8;
					if (instruction & (1 << 31))
						int_val.datum.integer = -int_val.datum.integer;
					Con_VM_con_stack_push_value(vm, vm->continuation, int_val);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_APPLY:
					Con_VM_apply_with_return(vm, (instruction & 0x0000FF00) >> 8, Con_VM_main_loop, (Con_PC) (int) (vm->continuation->pc.bytecode + sizeof(Con_Bytecode)), PC_TYPE_BYTECODE);
					XXX;
					break; // even though we won't get this far
				case Con_INSTR_EQUALS:
					val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
					val = Con_VM_con_stack_pop_value(vm, vm->continuation);
					if (!Con_VM_equals(vm, val, val2))
						Con_VM_fail(vm);
					Con_VM_con_stack_push_value(vm, vm->continuation, val2);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_SUBTRACT:
					Con_VM_subtract(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_CHANGE_FAIL_POINT:
					fail_point = (instruction & 0x7FFFFF00) >> 8;
					if (fail_point & (1 << 31))
						fail_point = -fail_point;
					((Con_VM_Stack_Failure_Frame*) (vm->continuation->con_stack_start + vm->continuation->efp))->failure_pc.bytecode = vm->continuation->pc.bytecode + fail_point;
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_NOT_EQUALS:
					val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
					val = Con_VM_con_stack_pop_value(vm, vm->continuation);
					if (!Con_VM_not_equals(vm, val, val2))
						Con_VM_fail(vm);
					Con_VM_con_stack_push_value(vm, vm->continuation, val2);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_ADD_FAIL_UP_FRAME:
					Con_VM_add_fail_up_frame(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_LIST:
					Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_new_init_from_stack(vm, (instruction & 0xFFFFFF00) >> 8));
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_ADD:
					Con_VM_add(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_LESS_THAN:
					val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
					val = Con_VM_con_stack_pop_value(vm, vm->continuation);
					if (!Con_VM_less_than(vm, val, val2))
						Con_VM_fail(vm);
					Con_VM_con_stack_push_value(vm, vm->continuation, val2);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_YIELD:
					Con_VM_yield(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_FAIL_NOW:
					Con_VM_fail(vm);
					break; // even though we won't get this far
				case Con_INSTR_EYIELD:
					Con_VM_eyield(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_GREATER_THAN:
					val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
					val = Con_VM_con_stack_pop_value(vm, vm->continuation);
					if (!Con_VM_greater_than(vm, val, val2))
						Con_VM_fail(vm);
					Con_VM_con_stack_push_value(vm, vm->continuation, val2);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_INSTANCE_OF:
					val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
					val = Con_VM_con_stack_pop_value(vm, vm->continuation);
					if (!Con_VM_instance_of(vm, val, val2))
						Con_VM_fail(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_IMPORT:
					Con_VM_con_stack_push_value(vm, vm->continuation, Con_Import_module_in_bytecode(vm, (instruction & 0xFFFFFF00) >> 8));
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_IS:
					val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
					val = Con_VM_con_stack_pop_value(vm, vm->continuation);
					if (!Con_VM_is(vm, val, val2))
						Con_VM_fail(vm);
					Con_VM_con_stack_push_value(vm, vm->continuation, val2);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_UNPACK_ARGS:
					Con_VM_unpack_args(vm, (instruction & 0x0000FF00) >> 8, (instruction & 0x00FF0000) >> 16, (instruction & (1 << 31)) == 1 << 31 ? true : false);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_RAISE:
					Con_VM_raise(vm, Con_VM_con_stack_pop_value(vm, vm->continuation));
					break; // even though we won't get this far
				case Con_INSTR_ADD_EXCEPTION_FRAME:
					if (instruction & (1 << 31))
						pc.bytecode = vm->continuation->pc.bytecode - ((instruction & 0x7FFFFF00) >> 8);
					else
						pc.bytecode = vm->continuation->pc.bytecode + ((instruction & 0x7FFFFF00) >> 8);
					Con_VM_add_exception_frame(vm, pc, PC_TYPE_BYTECODE);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_REMOVE_EXCEPTION_FRAME:
					Con_VM_remove_exception_frame(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_PUSH_EXCEPTION:
					Con_VM_con_stack_push_value(vm, vm->continuation, vm->continuation->current_exception);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_GREATER_THAN_EQUALS:
					val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
					val = Con_VM_con_stack_pop_value(vm, vm->continuation);
					if (!Con_VM_greater_than_equals(vm, val, val2))
						Con_VM_fail(vm);
					Con_VM_con_stack_push_value(vm, vm->continuation, val2);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_LESS_THAN_EQUALS:
					val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
					val = Con_VM_con_stack_pop_value(vm, vm->continuation);
					if (!Con_VM_less_than_equals(vm, val, val2))
						Con_VM_fail(vm);
					Con_VM_con_stack_push_value(vm, vm->continuation, val2);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_MUL:
					Con_VM_mul(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_DIVIDE:
					Con_VM_divide(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_MODULO:
					Con_VM_modulo(vm);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_SET:
					new_set = Con_Set_new(vm);
					for (i = 0; i < (instruction & 0xFFFFFF00) >> 8; i += 1) {
						Con_Set_add(vm, new_set, Con_VM_con_stack_pop_value(vm, vm->continuation));
					}
					Con_VM_con_stack_push_value(vm, vm->continuation, new_set);
					vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				case Con_INSTR_BRANCH_IF_NOT_FAIL:
					offset = (instruction & 0x7FFFFF00) >> 8;
					if (instruction & (1 << 31))
						offset = -offset;
					val = Con_VM_con_stack_pop_value(vm, vm->continuation);
					if (!Con_VM_is(vm, val, vm->builtins[CON_BUILTIN_FAIL_VAL]))
						vm->continuation->pc.bytecode += offset;
					else
						vm->continuation->pc.bytecode += sizeof(Con_Bytecode);
					break;
				default:
					printf("%d\n", instruction & 0x000000FF);
					XXX;
			}
		}
		else {
#if DEBUG
			printf("  <internal@%p>\n", vm->continuation->pc.c_function);
			Con_VM_print_stack(vm);
			printf("\n");
			printf("                             continuation=%p efp=%d gfp=%d\n", vm->continuation, vm->continuation->efp, vm->continuation->gfp);
#endif
			vm->continuation->pc.c_function(vm);
		}
	}
}



void Con_VM_unpack_args(Con_VM* vm, int num_args_required, int num_mandatory_args, bool has_var_args)
{
	Con_Value num_args_passed_val, var_args, unassigned;
	int num_args_passed, i;
	int var_refs;
	int arg_vals;
	int con_stack_end;
	Con_VM_Stack_Var_Ref* var_ref;
	Con_Value* arg_val;
	
	num_args_passed_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
	Con_VM_ensure_type(vm, num_args_passed_val, "i", "XXX");
	num_args_passed = num_args_passed_val.datum.integer;
	
	if (num_args_passed < num_mandatory_args)
		Con_Mod_Exceptions_quick(vm, "Parameters_Exception", 1, Con_String_new_c_str(vm, "Not enough args passed"));
	
	if (!has_var_args && num_args_passed > num_args_required)
		Con_Mod_Exceptions_quick(vm, "Parameters_Exception", 1, Con_String_new_c_str(vm, "Too many args passed"));

	var_refs = (num_args_required + (has_var_args ? 1 : 0)) * (sizeof(Con_VM_Stack_Var_Ref) + sizeof(Con_VM_Stack_Types));
	arg_vals = var_refs;
	con_stack_end = arg_vals;
	
	for (i = 0; i < num_args_required; i += 1) {
		var_ref = vm->continuation->con_stack - var_refs;
		if (i >= num_args_passed) {
			unassigned.type = CON_VALUE_UNASSIGNED;
			Con_VM_var_set(vm, vm->continuation, var_ref->continuation_offset, var_ref->var_number, unassigned);
		}
		else {
			arg_vals += sizeof(Con_Value) + sizeof(Con_VM_Stack_Types);
			arg_val = vm->continuation->con_stack - arg_vals;
			Con_VM_var_set(vm, vm->continuation, var_ref->continuation_offset, var_ref->var_number, *arg_val);
		}
		var_refs -= sizeof(Con_VM_Stack_Var_Ref) + sizeof(Con_VM_Stack_Types);
	}
	
	if (has_var_args) {
		var_args = Con_List_new(vm);
		var_ref = vm->continuation->con_stack - var_refs;
		for (; i < num_args_passed; i += 1) {
			arg_vals += sizeof(Con_Value) + sizeof(Con_VM_Stack_Types);
			arg_val = vm->continuation->con_stack - arg_vals;
			Con_List_append(vm, var_args, *arg_val);
		}
		Con_VM_var_set(vm, vm->continuation, var_ref->continuation_offset, var_ref->var_number, var_args);
	}
	
	vm->continuation->con_stack = vm->continuation->con_stack - con_stack_end;
}



//
//
//


void Con_VM_assign(Con_VM* vm)
{
	Con_Value val;

	val = Con_VM_con_stack_pop_value(vm, vm->continuation);
	if (Con_VM_con_stack_type(vm, vm->continuation) == CON_VM_STACK_VAR_REF) {
		Con_VM_Stack_Var_Ref var_ref;
		
		var_ref = Con_VM_con_stack_pop_var_ref(vm, vm->continuation);
		Con_VM_var_set(vm, vm->continuation, var_ref.continuation_offset, var_ref.var_number, val);
	}
	else {
		int slot_name_size;
		
		if (Con_VM_con_stack_type(vm, vm->continuation) != CON_VM_STACK_SLOT_REF) {
			Con_Mod_Exceptions_quick(vm, "Internal_Exception", 1, Con_String_new_c_str(vm, "Attempted to pop a non-slot reference from the stack."));
		}
		vm->continuation->con_stack -= sizeof(Con_VM_Stack_Types);
		slot_name_size = *((int*) vm->continuation->con_stack - 1);
		vm->continuation->con_stack -= sizeof(int) + Con_Bytecode_align(slot_name_size + 1) + sizeof(Con_Value);
		Con_Object_set_slot(vm, *((Con_Value*) vm->continuation->con_stack), vm->continuation->con_stack + sizeof(Con_Value), val);
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, val);
}



void Con_VM_fail(Con_VM* vm)
{
	Con_VM_Stack_Failure_Frame* failure_frame;
	Con_VM_Stack_Generator_Frame* generator_frame;
	int prev_stack;
	jmp_buf env;
	ptrdiff_t size;

	while (1) {
		if (vm->continuation->gfp != -1) {
			generator_frame = (Con_VM_Stack_Generator_Frame*) (vm->continuation->con_stack_start + vm->continuation->gfp);
			if (generator_frame->type == CON_VM_STACK_GENERATOR_FRAME_EXPR) {
#if DEBUG
				printf("    resuming alternation\n");
#endif
				vm->continuation->pc = generator_frame->pc;
				vm->continuation->pc_type = generator_frame->pc_type;
				vm->continuation->gfp = generator_frame->gfp;
				vm->continuation->con_stack = generator_frame;
				setjmp(env);
#if defined(__OpenBSD__) && defined(Con_C_STACK_GROWS_DOWN)
				env[0] = (long) Con_VM_main_loop;
				env[2] = (long) vm->continuation->c_stack_end;
#elif defined(__FreeBSD__) && defined(Con_C_STACK_GROWS_DOWN)
				env->_jb[0] = (int) Con_VM_main_loop;
				env->_jb[2] = (int) vm->continuation->c_stack_end;
#elif defined(__linux__) && defined(Con_C_STACK_GROWS_DOWN)
			    env->__jmpbuf[JB_SP] = (int) vm->continuation->c_stack_end;
			    env->__jmpbuf[JB_PC] = (int) Con_VM_main_loop;
#elif defined(__CYGWIN__)
			    env[8] = (int) Con_VM_main_loop;
			    env[7] = (int) vm->continuation->c_stack_end;
#else
				XXX;
#endif
				Con_VM_execute_vm_switch = vm;
				longjmp(env, 1);
			}
			else {
				if (generator_frame->continuation->pc_type == PC_TYPE_NULL) {
#if DEBUG
					printf("    unwinding gfp\n");
#endif
					vm->continuation->pc = generator_frame->pc;
					vm->continuation->pc_type = generator_frame->pc_type;
					vm->continuation->gfp = generator_frame->gfp;
					vm->continuation->efp = generator_frame->efp;
					vm->continuation->con_stack = generator_frame;
					continue;
				}
#if DEBUG
				printf("    resuming generator...\n");
#endif
				vm->continuation->con_stack = (void*) generator_frame + sizeof(Con_VM_Stack_Generator_Frame) + sizeof(Con_VM_Stack_Types);
				
				if (generator_frame->efp != -1)
					prev_stack = generator_frame->efp + sizeof(Con_VM_Stack_Failure_Frame) + sizeof(Con_VM_Stack_Types);
				else if (generator_frame->gfp != -1)
					prev_stack = generator_frame->gfp + sizeof(Con_VM_Stack_Generator_Frame) + sizeof(Con_VM_Stack_Types);
				else
					prev_stack = 0;

				if (prev_stack != 0) {
					generator_frame = (void*) (((void*) generator_frame) - vm->continuation->con_stack_start);
					size = (int) (((int) generator_frame) - prev_stack);
					_Con_VM_con_stack_ensure_room(vm, vm->continuation, size);
					memmove(vm->continuation->con_stack, vm->continuation->con_stack_start + prev_stack, size);
					vm->continuation->con_stack += size;
					generator_frame = vm->continuation->con_stack_start + ((int) generator_frame);
					// XXX mem check
				}
				vm->continuation = generator_frame->continuation;
//				vm->continuation->pc = generator_frame->pc;
//				vm->continuation->pc_type = generator_frame->pc_type;
#if DEBUG
				Con_VM_print_stack(vm);
				printf("\n");
				printf("                             continuation=%p efp=%d gfp=%d\n", vm->continuation, vm->continuation->efp, vm->continuation->gfp);
#endif
				Con_VM_execute_vm_switch = vm;
				longjmp(generator_frame->env, 1);
			}
		}
#if DEBUG
		printf("    failure...\n");
#endif
		failure_frame = (Con_VM_Stack_Failure_Frame*) (vm->continuation->con_stack_start + vm->continuation->efp);
		vm->continuation->pc_type = failure_frame->failure_pc_type;
		vm->continuation->pc = failure_frame->failure_pc;
		vm->continuation->gfp = failure_frame->gfp;
		vm->continuation->efp = failure_frame->efp;
		vm->continuation->con_stack = failure_frame;
		if (vm->continuation->pc_type == PC_TYPE_NULL)
			continue;
		setjmp(env);
#if defined(__OpenBSD__) && defined(Con_C_STACK_GROWS_DOWN)
		env[0] = (long) Con_VM_main_loop;
		env[2] = (long) vm->continuation->c_stack_end;
#elif defined(__FreeBSD__) && defined(Con_C_STACK_GROWS_DOWN)
		env->_jb[0] = (int) Con_VM_main_loop;
		env->_jb[2] = (int) vm->continuation->c_stack_end;
#elif defined(__linux__) && defined(Con_C_STACK_GROWS_DOWN)
	    env->__jmpbuf[JB_SP] = (int) vm->continuation->c_stack_end;
	    env->__jmpbuf[JB_PC] = (int) Con_VM_main_loop;
#elif defined(__CYGWIN__)
    	env[8] = (int) Con_VM_main_loop;
	    env[7] = (int) vm->continuation->c_stack_end;
#else
		XXX;
#endif
		Con_VM_execute_vm_switch = vm;
		longjmp(env, 1);
	}
}



void Con_VM_var_set(Con_VM* vm, Con_Continuation* continuation, int continuation_offset, int var_number, Con_Value value)
{
	if ((continuation_offset >= continuation->num_ancestors + 1) || (var_number >= continuation->continuation_vars[continuation_offset]->num_local_vars))
		CON_FATAL_ERROR("Trying to access var beyond bounds.");
	
	continuation->continuation_vars[continuation_offset]->local_vars[var_number] = value;
}



Con_Value Con_VM_var_lookup(Con_VM* vm, Con_Continuation* continuation, int continuation_offset, int var_number)
{
	Con_Value result;

	if ((continuation_offset >= continuation->num_ancestors + 1) || (var_number >= continuation->continuation_vars[continuation_offset]->num_local_vars))
		CON_FATAL_ERROR("Trying to access var beyond bounds.");
	
	result = continuation->continuation_vars[continuation_offset]->local_vars[var_number];
	if (result.type == CON_VALUE_UNASSIGNED)
		Con_Mod_Exceptions_quick(vm, "Unassigned_Var_Exception", 1, Con_String_new_c_str(vm, "Var has not yet been assigned to."));
	
	return result;
}



bool Con_VM_var_is_assigned(Con_VM* vm, Con_Continuation* continuation, int continuation_offset, int var_number)
{
	Con_Value result;

	if ((continuation_offset >= continuation->num_ancestors + 1) || (var_number >= continuation->continuation_vars[continuation_offset]->num_local_vars))
		CON_FATAL_ERROR("Trying to access var beyond bounds.");
	
	result = continuation->continuation_vars[continuation_offset]->local_vars[var_number];
	if (result.type == CON_VALUE_UNASSIGNED)
		return false;
	
	return true;
}



void Con_VM_set_item(Con_VM* vm)
{
	Con_Value target, key, val;
	
	val = Con_VM_con_stack_pop_value(vm, vm->continuation);
	key = Con_VM_con_stack_pop_value(vm, vm->continuation);
	target = Con_VM_con_stack_pop_value(vm, vm->continuation);
	if (target.type == CON_VALUE_OBJECT && target.datum.object->type == CON_OBJECT_DICT) {
		Con_Dict_set_item(vm, target, key, val);
	}
	else {
		XXX;
	}
}



void Con_VM_return(Con_VM* vm)
{
	Con_Value return_val;
	Con_Continuation* old_continuation = vm->continuation;
	
	if (vm->continuation->calling_continuation == NULL) {
		exit(0);
	}

	vm->continuation->pc_type = PC_TYPE_NULL;

	return_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
	if (Con_VM_is(vm, return_val, vm->builtins[CON_BUILTIN_FAIL_VAL])) {
		vm->continuation = vm->continuation->calling_continuation;
		Con_VM_fail(vm);
	}

	Con_VM_con_stack_push_value(vm, vm->continuation->calling_continuation, return_val);
	vm->continuation = vm->continuation->calling_continuation;
	Con_VM_execute_vm_switch = vm;
	vm->continuation->pc = old_continuation->return_pc;
	vm->continuation->pc_type = old_continuation->return_pc_type;
	longjmp(old_continuation->return_env, 1);
}



void Con_VM_yield(Con_VM* vm)
{
	Con_Value yield_val;
	Con_Continuation* calling_continuation;
	Con_Continuation* old_continuation;
	Con_VM_Stack_Generator_Frame* calling_gfp = NULL;
	void* prev_stack;
	
	yield_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
	if (Con_VM_is(vm, yield_val, vm->builtins[CON_BUILTIN_FAIL_VAL])) {
		vm->continuation = vm->continuation->calling_continuation;
		Con_VM_fail(vm);
	}
		
	calling_continuation = vm->continuation->calling_continuation;
	if ((calling_continuation->gfp == -1) || (((Con_VM_Stack_Generator_Frame*) (calling_continuation->con_stack_start + calling_continuation->gfp))->continuation != vm->continuation)) {
		Con_VM_add_generator_frame(vm, calling_continuation, CON_VM_STACK_GENERATOR_FRAME_FUNC, vm->continuation, vm->continuation->pc, vm->continuation->pc_type);
		calling_gfp = (Con_VM_Stack_Generator_Frame*) (calling_continuation->con_stack_start + calling_continuation->gfp);
	}
	else {
		calling_gfp = (Con_VM_Stack_Generator_Frame*) (calling_continuation->con_stack_start + calling_continuation->gfp);
		calling_continuation->con_stack = (void*) calling_gfp + sizeof(Con_VM_Stack_Generator_Frame) + sizeof(Con_VM_Stack_Types);
	}

	if (calling_gfp->efp != -1)
		prev_stack = calling_continuation->con_stack_start + calling_gfp->efp + sizeof(Con_VM_Stack_Failure_Frame) + sizeof(Con_VM_Stack_Types);
	else if (calling_gfp->gfp != -1)
		prev_stack = calling_continuation->con_stack_start + calling_gfp->gfp + sizeof(Con_VM_Stack_Generator_Frame) + sizeof(Con_VM_Stack_Types);
	else
		prev_stack = NULL;

	if (prev_stack != NULL) {
//		if (calling_continuation->con_stack + ((void*) calling_gfp - (void*) prev_stack) >= calling_continuation->con_stack_end)
//			XXX
		prev_stack = (void*) ((int) prev_stack - (int) calling_continuation->con_stack_start);
		calling_gfp = (void*) ((int) calling_gfp - (int) calling_continuation->con_stack_start);
		_Con_VM_con_stack_ensure_room(vm, calling_continuation, (void*) calling_gfp - (void*) prev_stack);
		prev_stack = (void*) ((int) prev_stack + (int) calling_continuation->con_stack_start);
		calling_gfp = (void*) ((int) calling_gfp + (int) calling_continuation->con_stack_start);
		memmove(calling_continuation->con_stack, prev_stack, (void*) calling_gfp - (void*) prev_stack);
		calling_continuation->con_stack += (void*) calling_gfp - (void*) prev_stack;
	}
	calling_gfp = (void*) ((int) calling_gfp - (int) calling_continuation->con_stack_start);
	Con_VM_con_stack_push_value(vm, calling_continuation, yield_val);
	calling_gfp = (void*) ((int) calling_gfp + (int) calling_continuation->con_stack_start);

	if (vm->continuation->return_is_simple)
		CON_FATAL_ERROR("Can't yield to functions that don't set up an explicit return address.");

	if (setjmp(calling_gfp->env) == 0) {
		old_continuation = vm->continuation;
		calling_continuation->pc = old_continuation->return_pc;
		calling_continuation->pc_type = old_continuation->return_pc_type;
		vm->continuation = calling_continuation;
		longjmp(old_continuation->return_env, 1);
	}
}



void Con_VM_eyield(Con_VM* vm)
{
	Con_Value eyield_val;
	Con_PC pc;
	Con_PC_Type pc_type;
	int prev_stack_frame;
	ptrdiff_t orig_stack;

	eyield_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
	if (Con_VM_is(vm, eyield_val, vm->builtins[CON_BUILTIN_FAIL_VAL]))
		Con_VM_fail(vm);
	
	pc = ((Con_VM_Stack_Failure_Frame*) (vm->continuation->con_stack_start + vm->continuation->efp))->failure_pc;
	pc_type = ((Con_VM_Stack_Failure_Frame*) (vm->continuation->con_stack_start + vm->continuation->efp))->failure_pc_type;
	Con_VM_remove_failure_frame(vm);
		
	if (vm->continuation->efp > vm->continuation->gfp)
		prev_stack_frame = vm->continuation->efp + sizeof(Con_VM_Stack_Failure_Frame) + sizeof(Con_VM_Stack_Types);
	else if (vm->continuation->efp < vm->continuation->gfp)
		prev_stack_frame = vm->continuation->gfp + sizeof(Con_VM_Stack_Generator_Frame) + sizeof(Con_VM_Stack_Types);
	else
		XXX;
	
	Con_VM_add_generator_frame(vm, vm->continuation, CON_VM_STACK_GENERATOR_FRAME_EXPR, NULL, pc, pc_type);
	orig_stack = vm->continuation->con_stack - vm->continuation->con_stack_start;
	_Con_VM_con_stack_ensure_room(vm, vm->continuation, orig_stack - prev_stack_frame);
	orig_stack = vm->continuation->con_stack - vm->continuation->con_stack_start;
	
	memmove(vm->continuation->con_stack, vm->continuation->con_stack_start + prev_stack_frame, orig_stack - prev_stack_frame);
	vm->continuation->con_stack += orig_stack - prev_stack_frame;
	Con_VM_con_stack_push_value(vm, vm->continuation, eyield_val);
}



void Con_VM_apply(Con_VM* vm, int num_args)
{
	Con_VM_apply_with_return(vm, num_args, NULL, vm->continuation->pc, vm->continuation->pc_type);
}



void Con_VM_apply_with_return(Con_VM* vm, int num_args, void* return_addr, Con_PC return_pc, Con_PC_Type return_pc_type)
{
	Con_Value func, genuine_func;
	void* stack_current;
	Con_Object_Func* func_obj = NULL;
	Con_Object_Func_Binding* func_binding_obj = NULL;
	bool is_bound = false;
	Con_Value self_obj;
	Con_Continuation* new_continuation;
	int i;

	stack_current = vm->continuation->con_stack;
	for (i = 0; i < num_args; i += 1) {
		stack_current -= sizeof(Con_VM_Stack_Types);
		if (*((int*) stack_current) != CON_VM_STACK_VALUE) {
			printf("%d\n", num_args);
			Con_VM_print_stack(vm);
			Con_Mod_Exceptions_quick(vm, "Internal_Exception", 1, Con_String_new_c_str(vm, "Trying to pop a non-value from the stack."));
		}
		stack_current -= sizeof(Con_Value);
	}
	stack_current -= sizeof(Con_VM_Stack_Types);
	func = *((Con_Value*) stack_current - 1);
	if (func.type == CON_VALUE_OBJECT && func.datum.object->type == CON_OBJECT_FUNC) {
		func_obj = (Con_Object_Func*) func.datum.object;
		is_bound = false;
		genuine_func = func;
	}
	else if (func.type == CON_VALUE_OBJECT && func.datum.object->type == CON_OBJECT_FUNC_BINDING) {
		func_binding_obj = (Con_Object_Func_Binding*) func.datum.object;
		func_obj = (Con_Object_Func*) func_binding_obj->func.datum.object;
		self_obj = func_binding_obj->self_obj;
		is_bound = true;
		genuine_func = func_binding_obj->func;
	}
	else if (func.type == CON_VALUE_OBJECT) {// && func.datum.object->type == CON_NORMAL_OBJECT) {
		if (Con_Object_has_slot(vm, func, "instance_of") && Con_VM_instance_of(vm, Con_Object_get_slot(vm, func, "instance_of"), vm->builtins[CON_BUILTIN_CLASS_CLASS])) {
			func_binding_obj = (Con_Object_Func_Binding*) Con_Object_get_slot(vm, func, "new").datum.object;
			genuine_func = func_binding_obj->func;
			func_obj = (Con_Object_Func*) func_binding_obj->func.datum.object;
			self_obj = func;
			is_bound = true;
		}
		else {
			printf("%d %d %p %p\n", func.type, func.datum.object->type, Con_Object_get_slot(vm, func, "instance_of").datum.object, vm->builtins[CON_BUILTIN_OBJECT_CLASS].datum.object);
			XXX;
		}
	}
	else
		Con_Mod_Exceptions_quick(vm, "Apply_Exception", 1, func);

	new_continuation = Con_VM_continuation_create(vm, func_obj->num_local_vars, vm->continuation, func_obj->parent_continuation, func_obj->module, genuine_func);

	// Transfer the args
	
	for (i = 0; i < num_args; i += 1) {
		Con_VM_con_stack_push_value(vm, new_continuation, Con_VM_con_stack_pop_value(vm, vm->continuation));
	}
	
	// If this function is bound, push the self variable
	
	if (is_bound) {
		Con_VM_con_stack_push_value(vm, new_continuation, self_obj);
		Con_VM_con_stack_push_value(vm, new_continuation, Con_Int_new(num_args + 1));
	}
	else
		Con_VM_con_stack_push_value(vm, new_continuation, Con_Int_new(num_args));

	// Pop the function value off of the stack

	Con_VM_con_stack_pop_value(vm, vm->continuation);

	new_continuation->pc_type = func_obj->pc_type;
	new_continuation->pc = func_obj->pc;
	Con_VM_execute(vm, new_continuation, return_addr, return_pc, return_pc_type);
}



Con_Value Con_VM_apply_c(Con_VM* vm, Con_Value func, int num_args, ...)
{
	va_list ap;
	int args_processed;
	Con_Value arg;
	
	va_start(ap, num_args);
	Con_VM_con_stack_push_value(vm, vm->continuation, func);
	for (args_processed = 0; args_processed < num_args; args_processed += 1) {
		arg = va_arg(ap, Con_Value);
		Con_VM_con_stack_push_value(vm, vm->continuation, arg);
	}
	va_end(ap);
	Con_VM_apply(vm, num_args);
	return Con_VM_con_stack_pop_value(vm, vm->continuation);
}



bool Con_VM_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type == CON_VALUE_INT)
		return Con_Int_equals(vm, val1, val2);
	else if (val1.type == CON_VALUE_OBJECT) {
		if (val1.datum.object->type == CON_OBJECT_STRING)
			return Con_String_equals(vm, val1, val2);
		if (val1.datum.object->type == CON_OBJECT_LIST)
			return Con_List_eq(vm, val1, val2);
		else if (Con_VM_is(vm, val1, vm->builtins[CON_BUILTIN_NULL_VAL])) {
			if (Con_VM_is(vm, val2, vm->builtins[CON_BUILTIN_NULL_VAL]))
				return true;
			else
				return false;
		}
	}
	
	Con_Mod_Exceptions_quick(vm, "Slot_Exception", 2, Con_String_new_c_str(vm, "=="), Con_Object_get_slot(vm, val1, "instance_of"));
	// Won't ever get this far
	return false;
}



bool Con_VM_not_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type == CON_VALUE_INT)
		return Con_Int_not_equals(vm, val1, val2);
	else if (val1.type == CON_VALUE_OBJECT) {
		if (val1.datum.object->type == CON_OBJECT_STRING)
			return Con_String_not_equals(vm, val1, val2);
		else if (val1.datum.object->type == CON_OBJECT_LIST)
			return Con_List_neq(vm, val1, val2);
		else if (Con_VM_is(vm, val1, vm->builtins[CON_BUILTIN_NULL_VAL])) {
			if (Con_VM_is(vm, val2, vm->builtins[CON_BUILTIN_NULL_VAL]))
				return false;
			else
				return true;
		}
	}
	
	if (val1.type == CON_VALUE_OBJECT)
		printf("%d %d\n", val1.type, val1.datum.object->type);
	else
		printf("%d\n", val1.type);
	XXX;
	
	return false;
}



bool Con_VM_less_than(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type == CON_VALUE_INT)
		return Con_Int_less_than(vm, val1, val2);

	Con_Mod_Exceptions_quick(vm, "Slot_Exception", 2, Con_String_new_c_str(vm, "<"), Con_Object_get_slot(vm, val1, "instance_of"));
	// Won't ever get this far
	return false;
}



bool Con_VM_greater_than(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type == CON_VALUE_INT)
		return Con_Int_greater_than(vm, val1, val2);
	else
		XXX;
}



bool Con_VM_greater_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type == CON_VALUE_INT)
		return Con_Int_greater_than_equals(vm, val1, val2);
	else if (val1.type == CON_VALUE_OBJECT) {
		if (val1.datum.object->type == CON_OBJECT_STRING)
			return Con_String_greater_than_equals(vm, val1, val2);
		else if (Con_VM_is(vm, val1, vm->builtins[CON_BUILTIN_NULL_VAL])) {
			if (Con_VM_is(vm, val2, vm->builtins[CON_BUILTIN_NULL_VAL]))
				return true;
			else
				return false;
		}
	}
	
	if (val1.type == CON_VALUE_OBJECT)
		printf("%d %d\n", val1.type, val1.datum.object->type);
	else
		printf("%d\n", val1.type);
	XXX;
	
	return false;
}




bool Con_VM_less_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type == CON_VALUE_INT)
		return Con_Int_less_than_equals(vm, val1, val2);
	else if (val1.type == CON_VALUE_OBJECT) {
		if (val1.datum.object->type == CON_OBJECT_STRING)
			return Con_String_less_than_equals(vm, val1, val2);
		else if (Con_VM_is(vm, val1, vm->builtins[CON_BUILTIN_NULL_VAL])) {
			if (Con_VM_is(vm, val2, vm->builtins[CON_BUILTIN_NULL_VAL]))
				return true;
			else
				return false;
		}
	}
	
	if (val1.type == CON_VALUE_OBJECT)
		printf("%d %d\n", val1.type, val1.datum.object->type);
	else
		printf("%d\n", val1.type);
	XXX;
	
	return false;
}



void Con_VM_subtract(Con_VM* vm)
{
	Con_Value val1, val2, result;
	
	val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	val1 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	
	if (val1.type == CON_VALUE_INT)
		result = Con_Int_subtract(vm, val1, val2);
	else
		XXX;
	
	Con_VM_con_stack_push_value(vm, vm->continuation, result);
}



void Con_VM_add(Con_VM* vm)
{
	Con_Value val1, val2;
	
	val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	val1 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	
	if (val1.type == CON_VALUE_INT)
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_add(vm, val1, val2));
	else if (val1.type == CON_VALUE_OBJECT) {
		if (val1.datum.object->type == CON_OBJECT_STRING)
			Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_add(vm, val1, val2));
		else if (val1.datum.object->type == CON_OBJECT_LIST)
			Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_add(vm, val1, val2));
		else {
			Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, val1, "add"));
			Con_VM_con_stack_push_value(vm, vm->continuation, val2);
			Con_VM_apply(vm, 1);
		}
	}
	else
		XXX;
}



void Con_VM_mul(Con_VM* vm)
{
	Con_Value val1, val2;
	
	val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	val1 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	
	if (val1.type == CON_VALUE_INT)
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_mul(vm, val1, val2));
	else if (val1.type == CON_VALUE_OBJECT) {
		if ((val1.datum.object->type == CON_OBJECT_STRING) || (val1.datum.object->type == CON_OBJECT_LIST)) {
			if (!Con_VM_is_type(vm, val2, "i"))
				Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, val2, "instance_of"));
			if (val1.datum.object->type == CON_OBJECT_STRING)
				Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_mul(vm, val1, val2.datum.integer));
			else if (val1.datum.object->type == CON_OBJECT_LIST)
				Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_mul(vm, val1, val2.datum.integer));
		}
		else
			XXX
	}
	else
		XXX
}



void Con_VM_divide(Con_VM* vm)
{
	Con_Value val1, val2;
	
	val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	val1 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	
	if (val1.type == CON_VALUE_INT)
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_divide(vm, val1, val2));
	else
		XXX
}



void Con_VM_modulo(Con_VM* vm)
{
	Con_Value val1, val2;
	
	val2 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	val1 = Con_VM_con_stack_pop_value(vm, vm->continuation);
	
	if (val1.type == CON_VALUE_INT)
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_modulo(vm, val1, val2));
	else
		XXX
}



bool Con_VM_is(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type != val2.type || val1.type == CON_VALUE_INT)
		return false;
	if ((val1.type != CON_VALUE_OBJECT || val1.type != CON_VALUE_OBJECT) || val1.datum.object != val2.datum.object)
		return false;
	
	return true;
}



bool Con_VM_instance_of(Con_VM* vm, Con_Value val, Con_Value class)
{
	Con_Value classes, candidate_class, supers;
	int i, j;

	classes = Con_List_new(vm);
	Con_List_append(vm, classes, Con_Object_get_slot(vm, val, "instance_of"));
	i = 0;
	while (i < Con_List_get_size(vm, classes)) {
		candidate_class = Con_List_get_item(vm, classes, i);
		if (Con_VM_is(vm, candidate_class, class))
			return true;
		supers = Con_Object_get_slot(vm, candidate_class, "supers");
		for (j = 0; j < Con_List_get_size(vm, supers); j += 1) {
			Con_List_append(vm, classes, Con_List_get_item(vm, supers, j));
		}
		i += 1;
	}
	
	return false;
}



void _Con_VM_raise_backtrace(Con_VM* vm);

void Con_VM_raise(Con_VM* vm, Con_Value exception)
{
	Con_Continuation* continuation;
	Con_Continuation* new_continuation;
	Con_VM_Stack_Exception_Frame* exception_frame;
	Con_Value module_val;
	
	continuation = vm->continuation;

	if (!Con_VM_instance_of(vm, exception, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_EXCEPTIONS_MODULE], "Exception")))
		Con_Mod_Exceptions_quick(vm, "Exception_Exception", 1, Con_String_new_c_str(vm, "Object passed to raise is not an instance of Exceptions.Exception"));

	if (!Con_Object_has_slot(vm, exception, "backtrace_objs")) {
		Con_Value backtrace_objs;
		
		backtrace_objs = Con_List_new(vm);
		while (!Con_VM_is(vm, continuation->function, vm->builtins[CON_BUILTIN_NULL_VAL])) {
			if (continuation->module == NULL)
				module_val = vm->builtins[CON_BUILTIN_NULL_VAL];
			else
				module_val = continuation->module->module_val;
			Con_List_insert(vm, backtrace_objs, 0, Con_Backtrace_new(vm, module_val, continuation->function, continuation->pc, continuation->pc_type));
			if (continuation->calling_continuation == NULL)
				break;
			continuation = continuation->calling_continuation;
		}
		
		Con_Object_set_slot(vm, exception, "backtrace_objs", backtrace_objs);
	}
	else {
		while (continuation->calling_continuation != NULL) {
			continuation = continuation->calling_continuation;
		}
	}

	if (continuation->xfp == -1) {
		// We've got to the top of the call-chain, so this exception is going to terminate the
		// application after a backtrace has been printed.
		new_continuation = Con_VM_continuation_create(vm, 0, NULL, NULL, NULL, vm->builtins[CON_BUILTIN_NULL_VAL]);
		new_continuation->current_exception = exception;
		new_continuation->pc.c_function = (C_Function) _Con_VM_raise_backtrace;
		new_continuation->pc_type = PC_TYPE_C_FUNCTION;
		Con_VM_con_stack_push_value(vm, new_continuation, exception);
		Con_VM_execute(vm, new_continuation, NULL, (Con_PC) (C_Function) NULL, PC_TYPE_NULL);
		// Will never get here
	}
	else {
		exception_frame = (Con_VM_Stack_Exception_Frame*) (vm->continuation->con_stack_start + continuation->xfp);
		continuation->efp = exception_frame->efp;
		continuation->gfp = exception_frame->gfp;
		continuation->xfp = exception_frame->xfp;
		continuation->pc = exception_frame->xpc;
		continuation->pc_type = exception_frame->xpc_type;
		continuation->con_stack = exception_frame;
		Con_VM_con_stack_push_value(vm, continuation, exception);
		continuation->current_exception = exception;
		Con_VM_execute(vm, continuation, Con_VM_main_loop, continuation->return_pc, continuation->return_pc_type);
		// Will never get here
	}
}



void _Con_VM_raise_backtrace(Con_VM* vm)
{
	Con_Value exception;
	Con_Value backtrace;

	exception = Con_VM_con_stack_pop_value(vm, vm->continuation);
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_BACKTRACE_MODULE], "backtrace"));
	Con_VM_con_stack_push_value(vm, vm->continuation, exception);
	Con_VM_apply(vm, 1); // Backtrace.backtrace
	backtrace = Con_VM_con_stack_pop_value(vm, vm->continuation);
	if (!Con_VM_equals(vm, backtrace, Con_String_new_c_str(vm, ""))) {
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_SYS_MODULE], "println"));
		Con_VM_con_stack_push_value(vm, vm->continuation, backtrace);
		Con_VM_apply(vm, 1); // Sys.println
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_SYS_MODULE], "println"));
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, exception, "to_str"));
	Con_VM_apply(vm, 0); // exception.to_str
	Con_VM_apply(vm, 1); // Sys.println
	exit(1);
}



////////////////////////////////////////////////////////////////////////////////////////////////////
// Continuation stack operations
//

//
// Generic operations not specific to any particular type of item stored on the stack
//


Con_VM_Stack_Types Con_VM_con_stack_type(Con_VM* vm, Con_Continuation* continuation)
{
	if (continuation->con_stack == continuation->con_stack_start)
		XXX

	return *((Con_VM_Stack_Types*) continuation->con_stack - 1);
}


void Con_VM_con_stack_pop(Con_VM* vm, Con_Continuation* continuation)
{
	if (continuation->con_stack == continuation->con_stack_start)
		XXX

	switch (Con_VM_con_stack_type(vm, vm->continuation)) {
		case CON_VM_STACK_VALUE:
			Con_VM_con_stack_pop_value(vm, continuation);
			break;
		case CON_VM_STACK_VAR_REF:
			Con_VM_con_stack_pop_var_ref(vm, continuation);
			break;
		case CON_VM_STACK_SLOT_REF:
			continuation->con_stack -= sizeof(Con_Value) + Con_Bytecode_align(*((Con_VM_Stack_Types*) continuation->con_stack - 2) + 1) + sizeof(int) + sizeof(Con_VM_Stack_Types);
			break;
		default:
			CON_FATAL_ERROR("Unknown type on stack.");
	}
}


void Con_VM_con_stack_dup(Con_VM* vm, Con_Continuation* continuation)
{
	int size;
	void* item_begin = continuation->con_stack;

	if (continuation->con_stack == continuation->con_stack_start)
		XXX

	switch (*((Con_VM_Stack_Types*) continuation->con_stack - 1)) {
		case CON_VM_STACK_VALUE:
			size = sizeof(Con_Value) + sizeof(Con_VM_Stack_Types);
			break;
		case CON_VM_STACK_VAR_REF:
			size = sizeof(Con_VM_Stack_Var_Ref) + sizeof(Con_VM_Stack_Types);
			break;
		case CON_VM_STACK_SLOT_REF:
			size = sizeof(Con_Value) + Con_Bytecode_align(*((Con_VM_Stack_Types*) continuation->con_stack - 2) + 1) + sizeof(int) + sizeof(Con_VM_Stack_Types);
			break;
		default:
			CON_FATAL_ERROR("Unknown type on stack.");
	}
	switch (*((Con_VM_Stack_Types*) continuation->con_stack - 1)) {
		case CON_VM_STACK_VALUE:
			item_begin -= sizeof(Con_Value) + sizeof(Con_VM_Stack_Types);
			break;
		case CON_VM_STACK_VAR_REF:
			item_begin -= sizeof(Con_VM_Stack_Var_Ref) + sizeof(Con_VM_Stack_Types);
			break;
		case CON_VM_STACK_SLOT_REF:
			item_begin -= sizeof(Con_Value) + Con_Bytecode_align(*((Con_VM_Stack_Types*) continuation->con_stack - 2) + 1) + sizeof(int) + sizeof(Con_VM_Stack_Types);
			break;
		default:
			CON_FATAL_ERROR("Unknown type on stack.");
	}

	item_begin = (void*) ((int) item_begin - (int) continuation->con_stack_start);
	_Con_VM_con_stack_ensure_room(vm, continuation, size);
	item_begin = (void*) ((int) item_begin + (int) continuation->con_stack_start);

	memmove(continuation->con_stack, item_begin, size);
	
	continuation->con_stack += size;
}



void Con_VM_con_stack_pull(Con_VM* vm, Con_Continuation* continuation, int num_entries)
{
	void* item_1_begin;
	void* item_2_begin;
	void* correct_values;
	int entry_size, diff;
	Con_VM_Stack_Failure_Frame* failure_frame;
	int i;

	if (continuation->con_stack == continuation->con_stack_start)
		XXX

	item_1_begin = continuation->con_stack;	
	for (i = 0; i < num_entries; i += 1) {
		switch (*(((Con_VM_Stack_Types*) item_1_begin) - 1)) {
			case CON_VM_STACK_VALUE:
				item_1_begin -= sizeof(Con_Value) + sizeof(Con_VM_Stack_Types);
				break;
			case CON_VM_STACK_VAR_REF:
				item_1_begin -= sizeof(Con_VM_Stack_Var_Ref) + sizeof(Con_VM_Stack_Types);
				break;
			case CON_VM_STACK_SLOT_REF:
				item_1_begin -= sizeof(Con_Value) + Con_Bytecode_align(*((int*) (item_1_begin - sizeof(Con_VM_Stack_Types) - sizeof(int))) + 1) + sizeof(int) + sizeof(Con_VM_Stack_Types);
				break;
			case CON_VM_STACK_FAILURE_FRAME:
				item_1_begin -= sizeof(Con_VM_Stack_Failure_Frame) + sizeof(Con_VM_Stack_Types);
				break;
			default:
				CON_FATAL_ERROR("Unknown type on stack.");
		}
		if (item_1_begin <= continuation->con_stack_start)
			CON_FATAL_ERROR("Trying to pull beyond the stacks range");
	}

	item_2_begin = item_1_begin;
	switch (*(((Con_VM_Stack_Types*) item_2_begin) - 1)) {
		case CON_VM_STACK_VALUE:
			item_2_begin -= sizeof(Con_Value) + sizeof(Con_VM_Stack_Types);
			break;
		case CON_VM_STACK_VAR_REF:
			item_2_begin -= sizeof(Con_VM_Stack_Var_Ref) + sizeof(Con_VM_Stack_Types);
			break;
		case CON_VM_STACK_SLOT_REF:
			item_2_begin -= sizeof(Con_Value) + Con_Bytecode_align(*((int*) (item_2_begin - sizeof(Con_VM_Stack_Types) - sizeof(int))) + 1) + sizeof(int) + sizeof(Con_VM_Stack_Types);
			break;
		default:
			printf("%d\n", *(((Con_VM_Stack_Types*) item_2_begin) - 1));
			CON_FATAL_ERROR("Unknown type on stack.");
	}
	
	entry_size = item_1_begin - item_2_begin;

	correct_values = continuation->con_stack;	
	for (i = 0; i < num_entries; i += 1) {
		switch (*(((Con_VM_Stack_Types*) correct_values) - 1)) {
			case CON_VM_STACK_VALUE:
				correct_values -= sizeof(Con_Value) + sizeof(Con_VM_Stack_Types);
				break;
			case CON_VM_STACK_VAR_REF:
				correct_values -= sizeof(Con_VM_Stack_Var_Ref) + sizeof(Con_VM_Stack_Types);
				break;
			case CON_VM_STACK_SLOT_REF:
				correct_values -= sizeof(Con_Value) + Con_Bytecode_align(*((int*) (correct_values - sizeof(Con_VM_Stack_Types) - sizeof(int))) + 1) + sizeof(int) + sizeof(Con_VM_Stack_Types);
				break;
			case CON_VM_STACK_FAILURE_FRAME:
				correct_values -= sizeof(Con_VM_Stack_Failure_Frame) + sizeof(Con_VM_Stack_Types);
				failure_frame = (Con_VM_Stack_Failure_Frame*) correct_values;
				diff = (int) failure_frame - (int) continuation->con_stack_start;
				if (diff == continuation->efp)
					continuation->efp -= entry_size;
				else if (diff == continuation->gfp)
					continuation->gfp -= entry_size;
				else {
					XXX
					// this isn't tested yet
					if (failure_frame->efp != -1)
						failure_frame->efp -= entry_size;
					if (failure_frame->gfp != -1)
						failure_frame->gfp -= entry_size;
				}
				break;
			default:
				CON_FATAL_ERROR("Unknown type on stack.");
		}
	}
	
	item_1_begin = (void*) ((int) item_1_begin - (int) continuation->con_stack_start);
	item_2_begin = (void*) ((int) item_2_begin - (int) continuation->con_stack_start);

	_Con_VM_con_stack_ensure_room(vm, continuation, item_1_begin - item_2_begin);
	
	item_1_begin = (void*) ((int) item_1_begin + (int) continuation->con_stack_start);
	item_2_begin = (void*) ((int) item_2_begin + (int) continuation->con_stack_start);
	
	memmove(continuation->con_stack, item_2_begin, entry_size);
	memmove(item_2_begin, item_1_begin, continuation->con_stack - item_2_begin);
}



//
// Operations for particular types of item stored on the stack
//

void _Con_VM_con_stack_ensure_room(Con_VM* vm, Con_Continuation* continuation, int size)
{
	void* new_stack;
	int new_size;

	while (continuation->con_stack + size >= continuation->con_stack_end) {
		new_size = (continuation->con_stack_end - continuation->con_stack_start) + DEFAULT_CON_STACK_SIZE_INCREMENT;
		new_stack = Con_realloc(vm, continuation->con_stack_start, new_size);
		continuation->con_stack_end = new_stack + new_size;
		continuation->con_stack = new_stack + (continuation->con_stack - continuation->con_stack_start);
		continuation->con_stack_start = new_stack;
	}
}


void Con_VM_add_failure_frame(Con_VM* vm, Con_PC failure_pc, Con_PC_Type failure_pc_type)
{
	Con_VM_Stack_Failure_Frame* failure_frame;

	_Con_VM_con_stack_ensure_room(vm, vm->continuation, sizeof(Con_VM_Stack_Failure_Frame) + sizeof(Con_VM_Stack_Types));
	
	failure_frame = vm->continuation->con_stack;

	failure_frame->failure_pc = failure_pc;
	failure_frame->failure_pc_type = failure_pc_type;
	failure_frame->efp = vm->continuation->efp;
	failure_frame->gfp = vm->continuation->gfp;
	vm->continuation->efp = (void*) failure_frame - vm->continuation->con_stack_start;
	vm->continuation->gfp = -1;
	
	vm->continuation->con_stack += sizeof(Con_VM_Stack_Failure_Frame);
	*((int*) vm->continuation->con_stack) = CON_VM_STACK_FAILURE_FRAME;
	vm->continuation->con_stack += sizeof(Con_VM_Stack_Types);
}



void Con_VM_add_fail_up_frame(Con_VM* vm)
{
	Con_VM_Stack_Failure_Frame* failure_frame;
	
	_Con_VM_con_stack_ensure_room(vm, vm->continuation, sizeof(Con_VM_Stack_Failure_Frame) + sizeof(Con_VM_Stack_Types));
	
	failure_frame = vm->continuation->con_stack;
	
	failure_frame->failure_pc.bytecode = 0;
	failure_frame->failure_pc_type = PC_TYPE_NULL;
	failure_frame->efp = vm->continuation->efp;
	failure_frame->gfp = vm->continuation->gfp;
	vm->continuation->efp = (void*) failure_frame - vm->continuation->con_stack_start;
	vm->continuation->gfp = -1;
	
	vm->continuation->con_stack += sizeof(Con_VM_Stack_Failure_Frame);
	*((int*) vm->continuation->con_stack) = CON_VM_STACK_FAILURE_FRAME;
	vm->continuation->con_stack += sizeof(Con_VM_Stack_Types);
}



void Con_VM_add_exception_frame(Con_VM* vm, Con_PC exception_pc, Con_PC_Type exception_pc_type)
{
	Con_VM_Stack_Exception_Frame* exception_frame;

	_Con_VM_con_stack_ensure_room(vm, vm->continuation, sizeof(Con_VM_Stack_Exception_Frame) + sizeof(Con_VM_Stack_Types));

	exception_frame = vm->continuation->con_stack;

	exception_frame->xpc = exception_pc;
	exception_frame->xpc_type = exception_pc_type;
	exception_frame->efp = vm->continuation->efp;
	exception_frame->gfp = vm->continuation->gfp;
	exception_frame->xfp = vm->continuation->xfp;
	vm->continuation->xfp = (void*) exception_frame - vm->continuation->con_stack_start;
	
	vm->continuation->con_stack += sizeof(Con_VM_Stack_Exception_Frame);
	*((int*) vm->continuation->con_stack) = CON_VM_STACK_EXCEPTION_FRAME;
	vm->continuation->con_stack += sizeof(Con_VM_Stack_Types);
}



void Con_VM_remove_exception_frame(Con_VM* vm)
{
	Con_VM_Stack_Exception_Frame* exception_frame = (Con_VM_Stack_Exception_Frame*) (vm->continuation->con_stack_start + vm->continuation->xfp);

	if (vm->continuation->xfp == -1)
		CON_FATAL_ERROR("Trying to remove exception frame when none exists");

	vm->continuation->efp = exception_frame->efp;
	vm->continuation->gfp = exception_frame->gfp;
	vm->continuation->xfp = exception_frame->xfp;
	vm->continuation->con_stack = exception_frame;
}



void Con_VM_remove_failure_frame(Con_VM* vm)
{
	Con_VM_Stack_Failure_Frame* failure_frame = (Con_VM_Stack_Failure_Frame*) (vm->continuation->con_stack_start + vm->continuation->efp);

	if (vm->continuation->efp == -1)
		CON_FATAL_ERROR("Trying to remove failure frame when none exists");

	vm->continuation->efp = failure_frame->efp;
	vm->continuation->gfp = failure_frame->gfp;
	vm->continuation->con_stack = failure_frame;
}



void Con_VM_add_generator_frame(Con_VM* vm, Con_Continuation* continuation, Con_VM_Stack_Generator_Frame_Type type, Con_Continuation* generator_continuation, Con_PC pc, Con_PC_Type pc_type)
{
	Con_VM_Stack_Generator_Frame* generator_frame;
	
	_Con_VM_con_stack_ensure_room(vm, continuation, sizeof(Con_VM_Stack_Generator_Frame) + sizeof(Con_VM_Stack_Types));
	
	generator_frame = continuation->con_stack;
	
	generator_frame->type = type;
	generator_frame->continuation = generator_continuation;
	generator_frame->efp = continuation->efp;
	generator_frame->gfp = continuation->gfp;
	generator_frame->pc = pc;
	generator_frame->pc_type = pc_type;
// XXX	generator_frame->c_pc = continuation->env[0];
	continuation->gfp = (void*) generator_frame - continuation->con_stack_start;
	
	continuation->con_stack += sizeof(Con_VM_Stack_Generator_Frame);
	*((int*) continuation->con_stack) = CON_VM_STACK_GENERATOR_FRAME;
	continuation->con_stack += sizeof(Con_VM_Stack_Types);
}



void Con_VM_con_stack_push_value(Con_VM* vm, Con_Continuation* continuation, Con_Value value)
{
	_Con_VM_con_stack_ensure_room(vm, continuation, sizeof(Con_Value) + sizeof(Con_VM_Stack_Types));

	*((Con_Value*) continuation->con_stack) = value;
	continuation->con_stack += sizeof(Con_Value);
	*((Con_VM_Stack_Types*) continuation->con_stack) = CON_VM_STACK_VALUE;
	continuation->con_stack += sizeof(Con_VM_Stack_Types);
}



void Con_VM_con_stack_push_slot_ref(Con_VM* vm, Con_Continuation* continuation, Con_Value object, char* slot_name)
{
	Con_VM_con_stack_push_slot_ref_with_size(vm, continuation, object, slot_name, strlen(slot_name));
}



void Con_VM_con_stack_push_slot_ref_with_size(Con_VM* vm, Con_Continuation* continuation, Con_Value object, char* slot_name, int slot_name_size)
{
	_Con_VM_con_stack_ensure_room(vm, continuation, sizeof(Con_Value) + Con_Bytecode_align(slot_name_size + 1) + sizeof(int) + sizeof(Con_VM_Stack_Types));

	*((Con_Value*) continuation->con_stack) = object;
	strncpy((char*) continuation->con_stack + sizeof(Con_Value), slot_name, slot_name_size);
	((char*) ((Con_Value*) continuation->con_stack + 1))[slot_name_size] = 0;
	
	continuation->con_stack += sizeof(Con_Value) + Con_Bytecode_align(slot_name_size + 1);
	*((int*) continuation->con_stack) = slot_name_size;
	continuation->con_stack += sizeof(int);
	*((Con_VM_Stack_Types*) continuation->con_stack) = CON_VM_STACK_SLOT_REF;
	continuation->con_stack += sizeof(Con_VM_Stack_Types);
}



void Con_VM_con_stack_push_var_ref(Con_VM* vm, Con_Continuation* continuation, int continuation_offset, int var_number)
{
	_Con_VM_con_stack_ensure_room(vm, continuation, sizeof(int) + sizeof(int) + sizeof(Con_VM_Stack_Types));

	*((int*) continuation->con_stack) = continuation_offset;
	continuation->con_stack += sizeof(int);
	*((int*) continuation->con_stack) = var_number;
	continuation->con_stack += sizeof(int);
	*((Con_VM_Stack_Types*) continuation->con_stack) = CON_VM_STACK_VAR_REF;
	continuation->con_stack += sizeof(Con_VM_Stack_Types);
}



Con_Value Con_VM_con_stack_pop_value(Con_VM* vm, Con_Continuation* continuation)
{
	Con_Value result;
	
	if (Con_VM_con_stack_type(vm, vm->continuation) != CON_VM_STACK_VALUE) {
		CON_FATAL_ERROR("Attempted to pop a non-value from the stack.");
	}
	
	continuation->con_stack -= sizeof(Con_VM_Stack_Types);
	result = *((Con_Value*) continuation->con_stack - 1);
	continuation->con_stack -= sizeof(Con_Value);
	
	return result;
}



Con_VM_Stack_Var_Ref Con_VM_con_stack_pop_var_ref(Con_VM* vm, Con_Continuation* continuation)
{
	Con_VM_Stack_Var_Ref result;

	if (Con_VM_con_stack_type(vm, vm->continuation) != CON_VM_STACK_VAR_REF) {
		CON_FATAL_ERROR("Attempted to pop a non-var reference from the stack.");
	}

	continuation->con_stack -= sizeof(Con_VM_Stack_Types);
	result.var_number = *((int*) continuation->con_stack - 1);
	continuation->con_stack -= sizeof(int);
	result.continuation_offset = *((int*) continuation->con_stack - 1);
	continuation->con_stack -= sizeof(int);
	
	return result;
}



void Con_VM_print_stack(Con_VM* vm)
{
	Con_VM_Stack_Failure_Frame* failure_frame;
	Con_VM_Stack_Generator_Frame* generator_frame;
	Con_VM_Stack_Exception_Frame* exception_frame;
	void* stack_current = vm->continuation->con_stack;
	int slot_name_size;
	
	printf("[");
	while (stack_current != vm->continuation->con_stack_start) {
//		printf("%d %d %d\n", stack_current, vm->continuation->con_stack_start, *(((Con_VM_Stack_Types*) stack_current) - 1));
		stack_current -= sizeof(Con_VM_Stack_Types);
		switch (*((Con_VM_Stack_Types*) stack_current)) {
			case CON_VM_STACK_VALUE:
				printf("<val type=%d datum=%p>", ((Con_Value*) stack_current - 1)->type, ((Con_Value*) stack_current - 1)->datum.object);
				stack_current -= sizeof(Con_Value);
				break;
			case CON_VM_STACK_VAR_REF:
				printf("<var ref %d %d>", *((int*) stack_current - 1), *((int*) stack_current - 2));
				stack_current -= 2 * sizeof(int);
				break;
			case CON_VM_STACK_SLOT_REF:
				slot_name_size = *((int*) stack_current - 1);
				stack_current -= sizeof(int) + Con_Bytecode_align(slot_name_size + 1) + sizeof(Con_Value);
				printf("<slot ref %d %p %s>", ((Con_Value*) stack_current)->type, ((Con_Value*) stack_current)->datum.object, (char*) ((Con_Value*) stack_current + 1));
				break;
			case CON_VM_STACK_FAILURE_FRAME:
				failure_frame = stack_current - sizeof(Con_VM_Stack_Failure_Frame);
				if (failure_frame->failure_pc_type == PC_TYPE_BYTECODE)
					printf("<failure frame pc=(B)%d efp=%d gfp=%d>", failure_frame->failure_pc.bytecode, failure_frame->efp, failure_frame->gfp);
				else
					printf("<failure frame pc=(C)%p efp=%d gfp=%d>", failure_frame->failure_pc.c_function, failure_frame->efp, failure_frame->gfp);
				stack_current -= sizeof(Con_VM_Stack_Failure_Frame);
				break;
			case CON_VM_STACK_GENERATOR_FRAME:
				generator_frame = stack_current - sizeof(Con_VM_Stack_Generator_Frame);
				printf("<generator frame type=%d efp=%d gfp=%d con=%p>", generator_frame->type, generator_frame->efp, generator_frame->gfp, generator_frame->continuation);
				stack_current -= sizeof(Con_VM_Stack_Generator_Frame);
				break;
			case CON_VM_STACK_EXCEPTION_FRAME:
				exception_frame = stack_current - sizeof(Con_VM_Stack_Exception_Frame);
				if (exception_frame->xpc_type == PC_TYPE_BYTECODE)
					printf("<exception frame pc=(B)%d efp=%d gfp=%d xfp=%d>", exception_frame->xpc.bytecode, exception_frame->efp, exception_frame->gfp, exception_frame->xfp);
				else
					printf("<exception frame pc=(C)%p efp=%d gfp=%d xfp=%d>", exception_frame->xpc.c_function, exception_frame->efp, exception_frame->gfp, exception_frame->xfp);
				stack_current -= sizeof(Con_VM_Stack_Exception_Frame);
				break;
			default:
				printf("%d\n", *((Con_VM_Stack_Types*) stack_current));
				XXX;
		}
		if (stack_current != vm->continuation->con_stack_start)
			printf(", ");
	}
	printf("]");
}



////////////////////////////////////////////////////////////////////////////////////////////////////
// Argument parsing
//

#define INVALID_ARG_TYPE(x) XXX

void Con_VM_decode_args(Con_VM* vm, const char* args, ...)
{
	va_list ap;
	int num_args, args_processed, corrected_parameter_num;
	Con_Value arg_val, list_val, error_msg, type_should_be;
	bool optional_args, incorrect_type;
	
	va_start(ap, args);
	num_args = Con_VM_con_stack_pop_value(vm, vm->continuation).datum.integer;
	args_processed = 0;
	optional_args = false;
	while (*args) {
		if (*args == ';') {
			args += 1;
			optional_args = true;
			continue;
		}
		if (args_processed == num_args) {
			if (optional_args) {
				*va_arg(ap, Con_Value*) = vm->builtins[CON_BUILTIN_NULL_VAL];
				args_processed += 1;
				args += 1;
				continue;
			}
			else if (*args != 'v') {
				Con_VM_raise(vm, Con_VM_apply_c(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_EXCEPTIONS_MODULE], "Parameters_Exception"), 1, Con_String_new_c_str(vm, "Too few parameters passed.")));
			}
		}
		incorrect_type = false;
		switch (*args) {
			case 'o':
				*va_arg(ap, Con_Value*) = Con_VM_con_stack_pop_value(vm, vm->continuation);
				args_processed += 1;
				args += 1;
				break;
			case 'i':
				arg_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
				if (!Con_VM_is_type(vm, arg_val, "i"))
					Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, arg_val, "instance_of"));
				*va_arg(ap, Con_Value*) = arg_val;
				args_processed += 1;
				args += 1;
				break;
			case 's':
				arg_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
				if (!Con_VM_is_type(vm, arg_val, "s")) {
					incorrect_type = true;
					type_should_be = vm->builtins[CON_BUILTIN_STRING_CLASS];
					break;
				}
				*va_arg(ap, Con_Value*) = arg_val;
				args_processed += 1;
				args += 1;
				break;
			case 'c':
				arg_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
				if (!Con_VM_is_type(vm, arg_val, "c")) {
					incorrect_type = true;
					type_should_be = vm->builtins[CON_BUILTIN_CLASS_CLASS];
					break;
				}
				*va_arg(ap, Con_Value*) = arg_val;
				args_processed += 1;
				args += 1;
				break;
			case 'd':
				arg_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
				if (arg_val.type != CON_VALUE_OBJECT || arg_val.datum.object->type != CON_OBJECT_DICT) {
					incorrect_type = true;
					type_should_be = vm->builtins[CON_BUILTIN_DICT_CLASS];
					break;
				}
				*va_arg(ap, Con_Value*) = arg_val;
				args_processed += 1;
				args += 1;
				break;
			case 'l':
				arg_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
				if (arg_val.type != CON_VALUE_OBJECT || arg_val.datum.object->type != CON_OBJECT_LIST) {
					incorrect_type = true;
					type_should_be = vm->builtins[CON_BUILTIN_LIST_CLASS];
					break;
				}
				*va_arg(ap, Con_Value*) = arg_val;
				args_processed += 1;
				args += 1;
				break;
			case 'm':
				arg_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
				if (!Con_VM_is_type(vm, arg_val, "m")) {
					incorrect_type = true;
					type_should_be = vm->builtins[CON_BUILTIN_MODULE_CLASS];
					break;
				}
				*va_arg(ap, Con_Value*) = arg_val;
				args_processed += 1;
				args += 1;
				break;
			case 'S':
				arg_val = Con_VM_con_stack_pop_value(vm, vm->continuation);
				if (arg_val.type != CON_VALUE_OBJECT || arg_val.datum.object->type != CON_OBJECT_SET) {
					incorrect_type = true;
					type_should_be = vm->builtins[CON_BUILTIN_SET_CLASS];
					break;
				}
				*va_arg(ap, Con_Value*) = arg_val;
				args_processed += 1;
				args += 1;
				break;
			case 'v':
				list_val = Con_List_new(vm);
				while (args_processed < num_args) {
					Con_List_append(vm, list_val, Con_VM_con_stack_pop_value(vm, vm->continuation));
					args_processed += 1;
				}
				*va_arg(ap, Con_Value*) = list_val;
				args += 1;
				break;
			default:
				printf("%c\n", *args);
				CON_FATAL_ERROR("Unknown arg type");
		}
		if (incorrect_type) {
			error_msg = Con_String_new_c_str(vm, "parameter ");
			// If it's a bound function, we don't want to expose to the user that internally we
			// pass "self" as the first parameter.
			if (!Con_VM_is(vm, vm->continuation->function, vm->builtins[CON_BUILTIN_NULL_VAL]) && (((Con_Object_Func*) vm->continuation->function.datum.object)->is_bound))
				corrected_parameter_num = args_processed;
			else
				corrected_parameter_num = args_processed + 1;
			error_msg = Con_String_add(vm, error_msg, Con_VM_apply_c(vm, Con_Object_get_slot(vm, Con_Int_new(corrected_parameter_num), "to_str"), 0));
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 3, type_should_be, Con_Object_get_slot(vm, arg_val, "instance_of"), error_msg);
		}
	}
	if (args_processed < num_args) {
		Con_VM_raise(vm, Con_VM_apply_c(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_EXCEPTIONS_MODULE], "Parameters_Exception"), 1, Con_String_new_c_str(vm, "Too many parameters passed.")));
	}
	va_end(ap);
}



void Con_VM_ensure_type(Con_VM* vm, Con_Value val, const char* type, const char* err_msg)
{
	if (!Con_VM_is_type(vm, val, type))
		CON_FATAL_ERROR(err_msg);
//		Con_Mod_Exceptions_quick(vm, "Internal_Exception", 1, Con_String_new_c_str(vm, err_msg));
}



bool Con_VM_is_type(Con_VM* vm, Con_Value val, const char* type)
{
	switch (*type) {
		case 'i':
			if (val.type != CON_VALUE_INT)
				return false;
			break;
		case 's':
			if (!((val.type == CON_VALUE_OBJECT) && val.datum.object->type == CON_OBJECT_STRING))
				return false;
			break;
		case 'c':
			if (!((val.type == CON_VALUE_OBJECT) && val.datum.object->type == CON_NORMAL_OBJECT && Con_VM_instance_of(vm, val, vm->builtins[CON_BUILTIN_CLASS_CLASS])))
				return false;
			break;
		case 'l':
			if (!((val.type == CON_VALUE_OBJECT) && val.datum.object->type == CON_OBJECT_LIST))
				return false;
			break;
		case 'm':
			if (!((val.type == CON_VALUE_OBJECT) && val.datum.object->type == CON_OBJECT_MODULE))
				return false;
			break;
		case 'S':
			if (!((val.type == CON_VALUE_OBJECT) && val.datum.object->type == CON_OBJECT_SET))
				return false;
			break;
		default:
			printf("%s\n", type);
			CON_FATAL_ERROR("Unknown type");
	}
	
	return true;
}



int Con_VM_translate_index(Con_VM* vm, int index, int upper_bound)
{
	int new_index = index;

	if (index < 0)
		new_index = upper_bound + index;
	if ((new_index < 0) || (new_index >= upper_bound))
		Con_Mod_Exceptions_quick(vm, "Bounds_Exception", 2, Con_Int_new(index), Con_Int_new(upper_bound));
	
	return new_index;
}



int Con_VM_translate_slice_index(Con_VM* vm, int index, int upper_bound)
{
	int new_index = index;

	if (index < 0)
		new_index = upper_bound + index;
	if ((new_index < 0) || (new_index > upper_bound))
		Con_Mod_Exceptions_quick(vm, "Bounds_Exception", 2, Con_Int_new(index), Con_Int_new(upper_bound));
	
	return new_index;
}
