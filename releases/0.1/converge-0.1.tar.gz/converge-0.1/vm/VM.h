#ifndef Con_VM_H
#define Con_VM_H

// Object stuff

// Unassigned is a legal value, but should never be exposed to the user
// Illegal is a totally illegal value; it is only to be used for e.g. terminating a var args list of
//   Con_Result's.

typedef enum {CON_VALUE_UNASSIGNED, CON_VALUE_OBJECT, CON_VALUE_INT, CON_VALUE_ILLEGAL} Con_Value_Type;

typedef enum {CON_NORMAL_OBJECT, CON_OBJECT_STRING, CON_OBJECT_LIST, CON_OBJECT_DICT, CON_OBJECT_FAIL, CON_OBJECT_FUNC, CON_OBJECT_MODULE, CON_OBJECT_FUNC_BINDING, CON_OBJECT_CONTINUATION, CON_OBJECT_BACKTRACE, CON_OBJECT_FILE, CON_MOD_ARRAY_ARRAY, CON_OBJECT_SET, CON_OBJECT_PCRE_PATTERN, CON_OBJECT_PCRE_MATCH, CON_OBJECT_META_C_CLASS, CON_OBJECT_LIB_XML_XML_DOC} Con_Object_Type;

#define CON_OBJECT_HEAD Con_Object_Type type; \
	int slots_space_allocated; \
	int num_slots; \
	void* slots; \
	void* slots_names; \
	bool custom_get_slot, custom_set_slot, custom_has_slot; \
	int slots_names_size, slots_names_size_allocated;
	
typedef struct {
	CON_OBJECT_HEAD
	} Con_Object;

typedef union {
	int integer;
	Con_Object* object; }
	Con_Value_Datum;

typedef struct {
	Con_Value_Type type;
	Con_Value_Datum datum;
	} Con_Value;

typedef struct {
	Con_Value value;
	int name_offset;
	} Con_Slot;


//
// VM stuff
//

#include <setjmp.h>

#define CON_NUMBER_OF_BUILTINS 26
#define CON_BUILTIN_CLASS_CLASS 0
#define CON_BUILTIN_OBJECT_CLASS 1
#define CON_BUILTIN_INT_CLASS 2
#define CON_BUILTIN_STRING_CLASS 3
#define CON_BUILTIN_LIST_CLASS 4
#define CON_BUILTIN_DICT_CLASS 5
#define CON_BUILTIN_FUNC_CLASS 6
#define CON_BUILTIN_FUNC_BINDING_CLASS 7
#define CON_BUILTIN_SYS_MODULE 8
#define CON_BUILTIN_STRINGS_MODULE 9
#define CON_BUILTIN_MODULE_CLASS 10
#define CON_BUILTIN_NULL_VAL 11
#define CON_BUILTIN_FAIL_VAL 12
#define CON_BUILTIN_IMPORT_FUNC 13
#define CON_BUILTIN_BOOLEAN_CLASS 14
#define CON_BUILTIN_TRUE_VAL 15
#define CON_BUILTIN_FALSE_VAL 16
#define CON_BUILTIN_EXCEPTIONS_MODULE 17
#define CON_BUILTIN_BACKTRACE_MODULE 18
#define CON_BUILTIN_BACKTRACE_CLASS 19
#define CON_BUILTIN_NULL_CLASS 20
#define CON_BUILTIN_SET_CLASS 21
#define CON_BUILTIN_META_C_CLASS 22
#define CON_BUILTIN_DEFAULT_GET_SLOT_FUNC 23
#define CON_BUILTIN_DEFAULT_SET_SLOT_FUNC 24
#define CON_BUILTIN_DEFAULT_HAS_SLOT_FUNC 25

typedef enum {VM_INITIALIZING, VM_NORMAL} Con_VM_State;
typedef enum {PC_TYPE_BYTECODE, PC_TYPE_C_FUNCTION, PC_TYPE_NULL} Con_PC_Type;

typedef int Con_Bytecode;

typedef void (*C_Function)(void *);

typedef union {
	int bytecode;
	C_Function c_function; } Con_PC;

typedef struct {
	int type;
	char* full_name;
	} Con_Module_Import;

typedef struct {
	char* module_name;
	char* full_name;
	Con_PC pc;
	Con_PC_Type pc_type;
	int num_local_vars;
	Con_Value module_val;
	int type;
	Con_Module_Import* imports;
	int bytecode_offset;
	} Con_Module;

typedef struct continuation {
	CON_OBJECT_HEAD;
	Con_Word* c_stack_start;
	Con_Word* c_stack_end;
	void* con_stack_start;
	void* con_stack;
	void* con_stack_end;
	int num_ancestors;
	// vars is a pointer to a chunk of memory which contains the continuation var pointers and then
	// the local vars.
	// This is an implementation detail and should not be relied upon.
	void* vars;
	struct continuation** continuation_vars;
	Con_Value* local_vars;
	int num_local_vars;
	Con_PC pc;
	Con_PC_Type pc_type;
	int gfp;
	int efp;
	int xfp;
	Con_Module* module;
	Con_Value function; // can be null
	Con_Value current_exception;
	struct continuation* parent_continuation;
	// Calling continuation gubbins
	struct continuation* calling_continuation;
	jmp_buf return_env;
	Con_PC return_pc;
	Con_PC_Type return_pc_type;
	bool return_is_simple;
	} Con_Continuation;

typedef struct {
	Con_Bytecode* bytecode;
	int bytecode_size;
	Con_VM_State state;
	Con_Continuation* continuation;
	Con_Module** modules;
	int modules_size, modules_size_allocated;
	int num_allocations_since_gc;
	char** argv;
	int argc;
	Con_Value builtins[CON_NUMBER_OF_BUILTINS];
	bool dealing_with_exception;
	char* program_path;
	} Con_VM;

// The stack grows from the bottom up.
//
// Items are stored <stack item> <stack item type>.
//
// Slot references are a pain since the slot name is of a variable size. They're stored as:
//   <value> <slot_name> <null terminator> [align to wordsize] <size of slot_name> <stack item type>

typedef enum {CON_VM_STACK_VALUE, CON_VM_STACK_VAR_REF, CON_VM_STACK_SLOT_REF, CON_VM_STACK_FAILURE_FRAME, CON_VM_STACK_GENERATOR_FRAME, CON_VM_STACK_EXCEPTION_FRAME} Con_VM_Stack_Types;

typedef struct {
	int continuation_offset;
	int var_number;
	} Con_VM_Stack_Var_Ref;

typedef struct {
	Con_PC failure_pc;
	Con_PC_Type failure_pc_type;
	int gfp;
	int efp;
	} Con_VM_Stack_Failure_Frame;

typedef enum {CON_VM_STACK_GENERATOR_FRAME_FUNC, CON_VM_STACK_GENERATOR_FRAME_EXPR} Con_VM_Stack_Generator_Frame_Type;

typedef struct {
	Con_VM_Stack_Generator_Frame_Type type;
	int gfp;
	int efp;
	Con_Continuation* continuation;
	Con_PC pc;
	Con_PC_Type pc_type;
	jmp_buf env;
	} Con_VM_Stack_Generator_Frame;

typedef struct {
	int gfp;
	int efp;
	int xfp;
	Con_PC xpc;
	Con_PC_Type xpc_type;
	} Con_VM_Stack_Exception_Frame;

Con_VM* Con_VM_create(char** argv, int argc, char* program_path);
void Con_VM_init(Con_VM* vm);
Con_Continuation* Con_VM_continuation_create(Con_VM* vm, int num_vars, Con_Continuation* calling_continuation, Con_Continuation* parent_continuation, Con_Module* module, Con_Value function);
void Con_VM_execute(Con_VM* vm, Con_Continuation* new_continuation, void* return_addr, Con_PC return_pc, Con_PC_Type return_pc_type);

// 

void Con_VM_assign(Con_VM* vm);
void Con_VM_fail(Con_VM* vm);
Con_Value Con_VM_var_lookup(Con_VM* vm, Con_Continuation* continuation, int continuation_offset, int var_number);
void Con_VM_var_set(Con_VM* vm, Con_Continuation* continuation, int continuation_offset, int var_number, Con_Value value);
bool Con_VM_var_is_assigned(Con_VM* vm, Con_Continuation* continuation, int continuation_offset, int var_number);
void Con_VM_set_item(Con_VM* vm);
void Con_VM_return(Con_VM* vm);
void Con_VM_apply(Con_VM* vm, int num_args);
void Con_VM_apply_with_return(Con_VM* vm, int num_args, void* return_addr, Con_PC return_pc, Con_PC_Type return_pc_type);
Con_Value Con_VM_apply_c(Con_VM* vm, Con_Value func, int num_args, ...);
bool Con_VM_equals(Con_VM* vm, Con_Value val1, Con_Value val2);
bool Con_VM_not_equals(Con_VM* vm, Con_Value val1, Con_Value val2);
bool Con_VM_less_than(Con_VM* vm, Con_Value val1, Con_Value val2);
bool Con_VM_greater_than(Con_VM* vm, Con_Value val1, Con_Value val2);
bool Con_VM_greater_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2);
bool Con_VM_less_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2);
void Con_VM_subtract(Con_VM* vm);
void Con_VM_add(Con_VM* vm);
void Con_VM_mul(Con_VM* vm);
void Con_VM_divide(Con_VM* vm);
void Con_VM_modulo(Con_VM* vm);
bool Con_VM_is(Con_VM* vm, Con_Value val1, Con_Value val2);
bool Con_VM_instance_of(Con_VM* vm, Con_Value val1, Con_Value val2);
void Con_VM_raise(Con_VM* vm, Con_Value exception);
void Con_VM_yield(Con_VM* vm);
void Con_VM_eyield(Con_VM* vm);
int Con_VM_translate_index(Con_VM* vm, int index, int upper_bound);
int Con_VM_translate_slice_index(Con_VM* vm, int index, int upper_bound);

// Stack ops

Con_VM_Stack_Types Con_VM_con_stack_type(Con_VM* vm, Con_Continuation* continuation);
void Con_VM_con_stack_pop(Con_VM* vm, Con_Continuation* continuation);
void Con_VM_con_stack_dup(Con_VM* vm, Con_Continuation* continuation);
void Con_VM_con_stack_pull(Con_VM* vm, Con_Continuation* continuation, int num_entries);
void Con_VM_add_failure_frame(Con_VM* vm, Con_PC failure_pc, Con_PC_Type failure_pc_type);
void Con_VM_add_fail_up_frame(Con_VM* vm);
void Con_VM_remove_failure_frame(Con_VM* vm);
void Con_VM_add_generator_frame(Con_VM* vm, Con_Continuation* continuation, Con_VM_Stack_Generator_Frame_Type type, Con_Continuation* generator_continuation, Con_PC pc, Con_PC_Type pc_type);
void Con_VM_add_exception_frame(Con_VM* vm, Con_PC exception_pc, Con_PC_Type exception_pc_type);
void Con_VM_remove_exception_frame(Con_VM* vm);
void Con_VM_con_stack_push_value(Con_VM* vm, Con_Continuation* continuation, Con_Value value);
void Con_VM_con_stack_push_var_ref(Con_VM* vm, Con_Continuation* continuation, int continuation_offset, int var_number);
void Con_VM_con_stack_push_slot_ref(Con_VM* vm, Con_Continuation* continuation, Con_Value object, char* slot_name);
void Con_VM_con_stack_push_slot_ref_with_size(Con_VM* vm, Con_Continuation* continuation, Con_Value object, char* slot_name, int slot_name_size);
Con_Value Con_VM_con_stack_pop_value(Con_VM* vm, Con_Continuation* continuation);
Con_VM_Stack_Var_Ref Con_VM_con_stack_pop_var_ref(Con_VM* vm, Con_Continuation* continuation);
void Con_VM_print_stack(Con_VM* vm);

////////////////////////////////////////////////////////////////////////////////////////////////////
// Argument parsing
//

void Con_VM_decode_args(Con_VM* vm, const char* args, ...);
void Con_VM_ensure_type(Con_VM* vm, Con_Value val, const char* type, const char* err_msg);
bool Con_VM_is_type(Con_VM* vm, Con_Value val, const char* type);

#endif /* Con_VM_H */
