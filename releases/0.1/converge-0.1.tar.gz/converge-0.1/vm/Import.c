#include <assert.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Memory.h"
#include "Bytecode.h"
#include "Import.h"
#include "Builtins/Module.h"
#include "Builtins/String.h"

#include "Modules/Exceptions.h"
#include "Modules/Sys.h"
#include "Modules/Backtrace.h"
#include "Modules/File.h"
#include "Modules/OS.h"
#include "Modules/C_Parser.h"
#include "Modules/Array.h"
#include "pcre.h"
#include "Modules/Mod_PCRE.h"
#include "Modules/Mod_VM.h"



Con_Value Con_Import_module(Con_VM* vm, Con_Module* module)
{
	Con_Continuation* new_continuation;
	Con_Value module_val;

	module_val = Con_Module_new(vm, module);
	module->module_val = module_val;
	new_continuation = Con_VM_continuation_create(vm, module->num_local_vars, vm->continuation, NULL, module, vm->builtins[CON_BUILTIN_NULL_VAL]);

	new_continuation->pc = module->pc;
	new_continuation->pc_type = module->pc_type;
	Con_VM_con_stack_push_value(vm, new_continuation, module_val);
	Con_VM_execute(vm, new_continuation, NULL, vm->continuation->pc, vm->continuation->pc_type);
	Con_VM_con_stack_pop_value(vm, vm->continuation);

	return module_val;
}



Con_Value Con_Import_module_in_bytecode(Con_VM* vm, int module_num)
{
	Con_Module_Import* module_import;
	
	module_import = &vm->continuation->module->imports[module_num];
	if (module_import->type == Con_IMPORT_BUILTIN)
		return Con_Import_builtin_module(vm, module_import->full_name);
	else
		return Con_Import_user_module(vm, module_import->full_name);
}



Con_Value Con_Import_builtin_module(Con_VM* vm, const char* name)
{
	int i;
	Con_Module* module;
	Con_Value module_val;
	
	for (i = 0; i < vm->modules_size; i += 1) {
		if ((vm->modules[i]->type == Con_IMPORT_BUILTIN) && (strcmp(vm->modules[i]->full_name, name) == 0))
			return vm->modules[i]->module_val;
		module += 1;
	}

	if (vm->modules_size == vm->modules_size_allocated) {
		vm->modules = Con_realloc(vm, vm->modules, (vm->modules_size + CON_VM_MODULES_SIZE_ALLOCATED_INCREMENT) * sizeof(Con_Module*));
		vm->modules_size_allocated += CON_VM_MODULES_SIZE_ALLOCATED_INCREMENT;
	}
	
	module = Con_malloc(vm, sizeof(Con_Module), Con_MEMORY_NON_GC);

	if (strcmp(name, "Exceptions") == 0) {
		module->pc.c_function = (C_Function) Con_Mod_Exceptions_init;
	}
	else if (strcmp(name, "Sys") == 0) {
		module->pc.c_function = (C_Function) Con_Mod_Sys_init;
	}
	else if (strcmp(name, "_File") == 0) {
		module->pc.c_function = (C_Function) Con_Mod_File_init;
	}
	else if (strcmp(name, "OS") == 0) {
		module->pc.c_function = (C_Function) Con_Mod_OS_init;
	}
	else if (strcmp(name, "Backtrace") == 0) {
		module->pc.c_function = (C_Function) Con_Mod_Backtrace_init;
	}
	else if (strcmp(name, "C_Parser") == 0) {
		module->pc.c_function = (C_Function) Con_Mod_C_Parser_init;
	}
	else if (strcmp(name, "Array") == 0) {
		module->pc.c_function = (C_Function) Con_Mod_Array_init;
	}
	else if (strcmp(name, "PCRE") == 0) {
		module->pc.c_function = (C_Function) Con_Mod_PCRE_init;
	}
	else if (strcmp(name, "VM") == 0) {
		module->pc.c_function = (C_Function) Con_Mod_VM_init;
	}
	else {
		printf("%s\n", name);
		CON_FATAL_ERROR("Unknown module");
	}

#if DEBUG
	printf("Importing builtin: %s\n", name);
#endif

	module->pc_type = PC_TYPE_C_FUNCTION;
	module->module_name = Con_malloc(vm, strlen(name) + 1, Con_MEMORY_NON_GC);
	strcpy(module->module_name, name);
	module->full_name = Con_malloc(vm, strlen(name) + 1, Con_MEMORY_NON_GC);
	strcpy(module->full_name, name);
	module->type = Con_IMPORT_BUILTIN;
	module->num_local_vars = 0;
	module->imports = Con_malloc(vm, 0, Con_MEMORY_NON_GC);
	
	module_val = Con_Import_module(vm, module);

	if (vm->modules_size == vm->modules_size_allocated) {
		XXX
	}
	vm->modules[vm->modules_size] = module;
	vm->modules_size += 1;
	
#if DEBUG
	printf("Successfully imported builtin: %s\n", name);
#endif

	return module_val;
}



Con_Value Con_Import_user_module(Con_VM* vm, char* name)
{
	int i;
	Con_Module* module;
	Con_Value module_val, msg;
	
	for (i = 0; i < vm->modules_size; i += 1) {
		module = vm->modules[i];
		if (module->type == Con_IMPORT_CVB && strcmp(module->full_name, name) == 0) {
#if DEBUG
			printf("Importing cvb: %s\n", name);
#endif
			if (module->module_val.type == CON_VALUE_UNASSIGNED)
				module_val = Con_Import_module(vm, module);
			else
				module_val = module->module_val;
#if DEBUG
			printf("Successfully imported cvb: %s\n", name);
#endif
			return module_val;
		}
		module += 1;
	}
	
	msg = Con_String_new_c_str(vm, "Unable to find '");
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, name));
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "'."));
	Con_Mod_Exceptions_quick(vm, "Import_Exception", 1, msg);
	
	// We'll never reach here, but just to shut the compiler up...
	
	return vm->builtins[CON_BUILTIN_NULL_VAL];
}
