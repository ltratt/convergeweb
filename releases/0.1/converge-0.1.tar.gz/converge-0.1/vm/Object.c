#include <stdio.h>
#include <string.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Builtins/Func_Binding.h"
#include "Memory.h"
#include "Object.h"
#include "Builtins/Dict.h"
#include "Builtins/Int.h"
#include "Builtins/List.h"
#include "Builtins/String.h"
#include "Builtins/Func.h"
#include "Modules/Exceptions.h"



Con_Value Con_Object_get_slot(Con_VM* vm, Con_Value value, const char* slot_name)
{
	if (value.type == CON_VALUE_OBJECT && value.datum.object->custom_get_slot) {
		return Con_VM_apply_c(vm, Con_Object_get_slot_raw(vm, value, "get_slot"), 1, Con_String_new_c_str(vm, slot_name));
	}

	return Con_Object_get_slot_raw(vm, value, slot_name);
}



Con_Value Con_Object_get_slot_raw(Con_VM* vm, Con_Value value, const char* slot_name)
{
	Con_Object* obj;
	Con_Slot* current_slot;
	int i;
	Con_Value result, class, fields, slot_name_str;
	bool found_slot = false, found_in_class = false;

	if (value.type == CON_VALUE_INT) {
		class = vm->builtins[CON_BUILTIN_INT_CLASS];
		found_in_class = true;
		found_slot = false;
	}
	else if (value.type == CON_VALUE_OBJECT) {
		obj = value.datum.object;
		found_slot = false;
		found_in_class = false;
		if (obj->slots != NULL) {
			current_slot = obj->slots;
			for (i = 0; i < obj->num_slots; i += 1) {
				if (strcmp(slot_name, obj->slots_names + current_slot->name_offset) == 0) {
					result = current_slot->value;
					found_slot = true;
					break;
				}
				current_slot += 1;
			}
		}
		if (!found_slot) {
			found_in_class = true;
			if (obj->type == CON_OBJECT_STRING)
				class = vm->builtins[CON_BUILTIN_STRING_CLASS];
			else if (obj->type == CON_OBJECT_DICT)
				class = vm->builtins[CON_BUILTIN_DICT_CLASS];
			else if (obj->type == CON_OBJECT_LIST)
				class = vm->builtins[CON_BUILTIN_LIST_CLASS];
			else if (obj->type == CON_OBJECT_FUNC_BINDING)
				class = vm->builtins[CON_BUILTIN_FUNC_BINDING_CLASS];
			else if (obj->type == CON_OBJECT_MODULE) 
				class = vm->builtins[CON_BUILTIN_MODULE_CLASS];
			else if (obj->type == CON_OBJECT_SET) 
				class = vm->builtins[CON_BUILTIN_SET_CLASS];
			else if (obj->type == CON_OBJECT_FUNC) 
				class = vm->builtins[CON_BUILTIN_FUNC_CLASS];
			else
				found_in_class = false;
		}
	}
	
	if (!found_slot) {
		if (strcmp(slot_name, "instance_of") == 0) {
			result = class;
			found_slot = true;
		}
		else if (found_in_class) {
			fields = Con_Object_get_slot(vm, class, "fields");
			slot_name_str = Con_String_new_c_str(vm, slot_name);
			// Attempt to optimise the standard case where the class does contain the necessary
			// method -- saves allocating memory unnecessarily.
			if (Con_Dict_contains(vm, fields, slot_name_str)) {
				result = Con_Dict_lookup(vm, fields, slot_name_str);
				found_slot = true;
			}
			else {
				Con_Value stack, candidate;

				stack = Con_List_new(vm);
				Con_List_append(vm, stack, class);
				i = 0;
				while (i < Con_List_get_size(vm, stack)) {
					candidate = Con_Object_get_slot(vm, Con_List_get_item(vm, stack, i), "fields");
					if (Con_Dict_contains(vm, candidate, slot_name_str)) {
						result = Con_Dict_lookup(vm, candidate, slot_name_str);
						found_slot = true;
						break;
					}
					else
						Con_List_extend(vm, stack, Con_Object_get_slot(vm, Con_List_get_item(vm, stack, i), "supers"));
					i += 1;
				}
			}
		}
	}
	
	if (!found_slot) {
		if (!Con_VM_is(vm, vm->builtins[CON_BUILTIN_EXCEPTIONS_MODULE], vm->builtins[CON_BUILTIN_NULL_VAL])) {
			if (Con_Object_has_slot(vm, value, "instance_of"))
				Con_Mod_Exceptions_quick(vm, "Slot_Exception", 2, Con_String_new_c_str(vm, slot_name), Con_Object_get_slot(vm, value, "instance_of"));
			else
				Con_Mod_Exceptions_quick(vm, "Slot_Exception", 1, Con_String_new_c_str(vm, slot_name));
		}
		else {
			printf("%s\n", slot_name);
			XXX;
		}
	}
	
	if ((result.type == CON_VALUE_OBJECT) && (result.datum.object->type == CON_OBJECT_FUNC)) {
		if ((value.type == CON_VALUE_OBJECT) && (value.datum.object->type == CON_OBJECT_MODULE) && (!found_in_class))
			return result;
		return Con_Func_Binding_new(vm, value, result);
	}
	else
		return result;
	printf("%d\n", value.type);
	XXX;
	return result;
}



bool Con_Object_has_slot(Con_VM* vm, Con_Value value, const char* slot_name)
{
	if (value.type == CON_VALUE_OBJECT && value.datum.object->custom_has_slot) {
		XXX
	}
	
	return Con_Object_has_slot_raw(vm, value, slot_name);
}



bool Con_Object_has_slot_raw(Con_VM* vm, Con_Value value, const char* slot_name)
{
	Con_Object* obj;
	Con_Slot* current_slot;
	int i;
	Con_Value result, class, fields, slot_name_str;
	bool found_slot = false, found_in_class = false;

	if (value.type == CON_VALUE_INT) {
		class = vm->builtins[CON_BUILTIN_INT_CLASS];
		found_in_class = true;
		found_slot = false;
	}
	else if (value.type == CON_VALUE_OBJECT) {
		obj = value.datum.object;
		found_slot = false;
		found_in_class = false;
		if (obj->slots != NULL) {
			current_slot = obj->slots;
			for (i = 0; i < obj->num_slots; i += 1) {
				if (strcmp(slot_name, obj->slots_names + current_slot->name_offset) == 0) {
					result = current_slot->value;
					found_slot = true;
					break;
				}
				current_slot += 1;
			}
		}
		if (!found_slot) {
			found_in_class = true;
			if (obj->type == CON_OBJECT_STRING)
				class = vm->builtins[CON_BUILTIN_STRING_CLASS];
			else if (obj->type == CON_OBJECT_DICT)
				class = vm->builtins[CON_BUILTIN_DICT_CLASS];
			else if (obj->type == CON_OBJECT_LIST)
				class = vm->builtins[CON_BUILTIN_LIST_CLASS];
			else if (obj->type == CON_OBJECT_FUNC_BINDING)
				class = vm->builtins[CON_BUILTIN_FUNC_BINDING_CLASS];
			else if (obj->type == CON_OBJECT_MODULE) 
				class = vm->builtins[CON_BUILTIN_MODULE_CLASS];
			else if (obj->type == CON_OBJECT_SET)
				class = vm->builtins[CON_BUILTIN_SET_CLASS];
			else if (obj->type == CON_OBJECT_FUNC)
				class = vm->builtins[CON_BUILTIN_FUNC_CLASS];
			else
				found_in_class = false;
		}
	}
	
	if (!found_slot) {
		if (strcmp(slot_name, "instance_of") == 0) {
			result = class;
			found_slot = true;
		}
		else if (found_in_class) {
			fields = Con_Object_get_slot(vm, class, "fields");
			slot_name_str = Con_String_new_c_str(vm, slot_name);
			// Attempt to optimise the standard case where the class does contain the necessary
			// method -- saves allocating memory unnecessarily.
			if (Con_Dict_contains(vm, fields, slot_name_str)) {
				result = Con_Dict_lookup(vm, fields, slot_name_str);
				found_slot = true;
			}
			else {
				Con_Value stack, candidate;

				stack = Con_List_new(vm);
				Con_List_append(vm, stack, class);
				i = 0;
				while (i < Con_List_get_size(vm, stack)) {
					candidate = Con_Object_get_slot(vm, Con_List_get_item(vm, stack, i), "fields");
					if (Con_Dict_contains(vm, candidate, slot_name_str)) {
						result = Con_Dict_lookup(vm, candidate, slot_name_str);
						found_slot = true;
						break;
					}
					else
						Con_List_extend(vm, stack, Con_Object_get_slot(vm, Con_List_get_item(vm, stack, i), "supers"));
					i += 1;
				}
			}
		}
	}
	
	if (found_slot)
		return true;
	else
		return false;
}



void Con_Object_set_slot(Con_VM* vm, Con_Value value, const char* slot_name, Con_Value slot_value)
{
	if (value.type != CON_VALUE_OBJECT) {
		printf("Error setting slots: %d %s\n", value.type, slot_name);
		exit(22);
	}
	
	if (value.datum.object->custom_get_slot) {
		Con_VM_apply_c(vm, Con_Object_get_slot_raw(vm, value, "set_slot"), 2, Con_String_new_c_str(vm, slot_name), slot_value);
	}
	
	Con_Object_set_slot_raw(vm, value, slot_name, slot_value);
}



void Con_Object_set_slot_raw(Con_VM* vm, Con_Value value, const char* slot_name, Con_Value slot_value)
{
	Con_Slot* current_slot;
	Con_Slot* new_slot;
	Con_Object* obj;
	int i, slot_name_size;

	if (value.type != CON_VALUE_OBJECT) {
		printf("Error setting slots: %d %s\n", value.type, slot_name);
		exit(22);
	}
	
	obj = value.datum.object;

	if (!Con_VM_is(vm, value, vm->builtins[CON_BUILTIN_OBJECT_CLASS])) {
		if (strcmp(slot_name, "get_slot") == 0 && !Con_VM_is(vm, slot_value, vm->builtins[CON_BUILTIN_DEFAULT_GET_SLOT_FUNC])) {
			obj->custom_get_slot = true;
		}
		else if (strcmp(slot_name, "set_slot") == 0 && !Con_VM_is(vm, slot_value, vm->builtins[CON_BUILTIN_DEFAULT_SET_SLOT_FUNC])) {
			obj->custom_set_slot = true;
		}
		else if (strcmp(slot_name, "has_slot") == 0 && !Con_VM_is(vm, slot_value, vm->builtins[CON_BUILTIN_DEFAULT_HAS_SLOT_FUNC])) {
			obj->custom_has_slot = true;
		}
	}
	
	if (obj->slots == NULL) {
		obj->slots = Con_malloc(vm, sizeof(Con_Slot) * DEFAULT_NUM_SLOTS, Con_MEMORY_NON_GC);
		obj->slots_space_allocated = DEFAULT_NUM_SLOTS;
		obj->slots_names = Con_malloc(vm, DEFAULT_SLOTS_NAMES_SIZE, Con_MEMORY_NON_GC);
		obj->slots_names_size = 0;
		obj->slots_names_size_allocated = DEFAULT_SLOTS_NAMES_SIZE;
	}

	current_slot = obj->slots;
	for (i = 0; i < obj->num_slots; i += 1) {
		if (strcmp(slot_name, obj->slots_names + current_slot->name_offset) == 0) {
			current_slot->value = slot_value;
			return;
		}
		current_slot += 1;
	}
	
	if (obj->num_slots == obj->slots_space_allocated) {
		obj->slots = Con_realloc(vm, obj->slots, (obj->slots_space_allocated + DEFAULT_NUM_SLOTS) * sizeof(Con_Slot));
		obj->slots_space_allocated = obj->slots_space_allocated + DEFAULT_NUM_SLOTS;
	}
	
	slot_name_size = strlen(slot_name);
	if (obj->slots_names_size + slot_name_size >= obj->slots_names_size_allocated) {
		// Heuristic -- if someone's going to add one slot, they'll probably add another couple
		// at about the same time, so we increase by more than we really need.
		obj->slots_names = Con_realloc(vm, obj->slots_names, obj->slots_names_size_allocated + 3 * (slot_name_size + 1));
		obj->slots_names_size_allocated += 3 * (slot_name_size + 1);
	}
	
	new_slot = (Con_Slot*) obj->slots + obj->num_slots;
	new_slot->value = slot_value;
	new_slot->name_offset = obj->slots_names_size;
	strcpy(obj->slots_names + obj->slots_names_size, slot_name);
	obj->slots_names_size += slot_name_size + 1;
	obj->num_slots += 1;
}



Con_Value Con_Object_new(Con_VM* vm)
{
	Con_Object* obj;
	Con_Value result;
	
	result.type = CON_VALUE_OBJECT;
	result.datum.object = obj = Con_malloc(vm, sizeof(Con_Object), Con_MEMORY_OBJECT);
	obj->type = CON_NORMAL_OBJECT;
	
	Con_Object_init(vm, obj);
	
	return result;
}



void Con_Object_init(Con_VM* vm, Con_Object* obj)
{
	obj->slots = NULL;
	obj->slots_space_allocated = 0;
	obj->num_slots = 0;
	obj->custom_get_slot = false;
	obj->custom_set_slot = false;
	obj->custom_has_slot = false;
}
