#include <ctype.h>
#include <string.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Memory.h"
#include "Object.h"
#include "String.h"
#include "List.h"
#include "Dict.h"
#include "Func.h"
#include "Func_Binding.h"
#include "Int.h"

#include "Modules/Exceptions.h"



void _Con_String_len_func(Con_VM* vm);
void _Con_String_lookup_func(Con_VM* vm);
void _Con_String_to_str_func(Con_VM* vm);
void _Con_String_slice_func(Con_VM* vm);
void _Con_String_prefixed_by_func(Con_VM* vm);
void _Con_String_upper_case_func(Con_VM* vm);
void _Con_String_lower_case_func(Con_VM* vm);
void _Con_String_ascii_val_func(Con_VM* vm);
void _Con_String_iterate_func(Con_VM* vm);
void _Con_String_find_func(Con_VM* vm);
void _Con_String_hash_func(Con_VM* vm);
void _Con_String_rfind_func(Con_VM* vm);
void _Con_String_dcopy_func(Con_VM* vm);



void Con_String_class_bootstrap(Con_VM* vm)
{
	Con_Value supers, fields, len_func, lookup_func, to_str_func, slice_func, prefixed_by_func, upper_case_func, lower_case_func, ascii_val_func, iterate_func, find_func, hash_func, rfind_func, dcopy_func;

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_STRING_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_STRING_CLASS], "name", Con_String_new_c_str(vm, "String"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_STRING_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));

	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_STRING_CLASS], "supers", supers);
	
	fields = Con_Dict_new(vm);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_STRING_CLASS], "fields", fields);
	
	len_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_len_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "len"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "len"), len_func);

	lookup_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_lookup_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "lookup"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "lookup"), lookup_func);

	slice_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_slice_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "slice"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "slice"), slice_func);

	prefixed_by_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_prefixed_by_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "prefixed_by"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "prefixed_by"), prefixed_by_func);

	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);

	upper_case_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_upper_case_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "upper_case"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "upper_case"), upper_case_func);

	ascii_val_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_ascii_val_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "ascii_val"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "ascii_val"), ascii_val_func);

	lower_case_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_lower_case_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "lower_case"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "lower_case"), lower_case_func);

	iterate_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_iterate_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "iterate"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "iterate"), iterate_func);

	find_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_find_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "find"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "find"), find_func);

	hash_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_hash_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "hash"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "hash"), hash_func);

	rfind_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_rfind_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "rfind"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "rfind"), rfind_func);

	dcopy_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_String_dcopy_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "dcopy"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "dcopy"), dcopy_func);
}



Con_Value Con_String_new_blank(Con_VM* vm, int str_size)
{
	Con_String_Object* str_obj;
	Con_Value result;

	result.type = CON_VALUE_OBJECT;
	str_obj = Con_malloc(vm, sizeof(Con_String_Object) + str_size + 1, Con_MEMORY_OBJECT);
	result.datum.object = (Con_Object*) str_obj;
	str_obj->type = CON_OBJECT_STRING;
	str_obj->str_size = str_size;

	Con_Object_init(vm, (Con_Object*) str_obj);
//	Con_Object_set_slot(vm, result, "instance_of", vm->builtins[CON_BUILTIN_STRING_CLASS]);

	return result;
}



Con_Value Con_String_new(Con_VM* vm, const char* str, int str_size)
{
	Con_String_Object* str_obj;
	Con_Value result;
	
	result = Con_String_new_blank(vm, str_size);
	str_obj = (Con_String_Object*) result.datum.object;

	memmove(str_obj->str, str, str_size);
	str_obj->str[str_size] = 0;
	str_obj->hash = Con_String_hash(str, str_size);
	
	return result;
}



Con_Value Con_String_new_c_str(Con_VM* vm, const char* str)
{
	return Con_String_new(vm, str, strlen(str));
}



char* Con_String_get_str(Con_VM* vm, Con_Value str_val)
{
	return ((Con_String_Object *) str_val.datum.object)->str;
}



int Con_String_get_size(Con_VM* vm, Con_Value str_val)
{
	return ((Con_String_Object *) str_val.datum.object)->str_size;
}



Con_Hash Con_String_hash(const char *str, int str_size)
{
	unsigned long hash = 5381;
	int i;

	for (i = 0; i < str_size; i += 1)
		hash = ((hash << 5) + hash) + str[i]; /* hash * 33 + c */

	return hash;
}



bool Con_String_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	int i;
	Con_String_Object* str_obj1;
	Con_String_Object* str_obj2;
	char* str1;
	char* str2;

	if (val2.type != CON_VALUE_OBJECT || val2.datum.object->type != CON_OBJECT_STRING)
		return false;
	
	str_obj1 = (Con_String_Object*) val1.datum.object;
	str_obj2 = (Con_String_Object*) val2.datum.object;
	
	if (str_obj1->hash != str_obj2->hash || str_obj1->str_size != str_obj2->str_size)
		return false;
	
	str1 = str_obj1->str;
	str2 = str_obj2->str;
	for (i = 0; i < str_obj1->str_size; i += 1) {
		if (*str1 != *str2)
			return false;
		str1 += 1;
		str2 += 1;
	}
	
	return true;
}



bool Con_String_greater_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	int i;
	Con_String_Object* str_obj1;
	Con_String_Object* str_obj2;
	char* str1;
	char* str2;

	if (val2.type != CON_VALUE_OBJECT || val2.datum.object->type != CON_OBJECT_STRING)
		return false;
	
	str_obj1 = (Con_String_Object*) val1.datum.object;
	str_obj2 = (Con_String_Object*) val2.datum.object;
	
	str1 = str_obj1->str;
	str2 = str_obj2->str;
	for (i = 0; i < str_obj1->str_size; i += 1) {
		if (i == str_obj2->str_size)
			return true;
		if (*str1 < *str2)
			return false;
		str1 += 1;
		str2 += 1;
	}
	
	return true;
}



bool Con_String_less_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	int i;
	Con_String_Object* str_obj1;
	Con_String_Object* str_obj2;
	char* str1;
	char* str2;

	if (val2.type != CON_VALUE_OBJECT || val2.datum.object->type != CON_OBJECT_STRING)
		return false;
	
	str_obj1 = (Con_String_Object*) val1.datum.object;
	str_obj2 = (Con_String_Object*) val2.datum.object;
	
	str1 = str_obj1->str;
	str2 = str_obj2->str;
	for (i = 0; i < str_obj1->str_size; i += 1) {
		if (i == str_obj2->str_size)
			return true;
		if (*str1 > *str2)
			return false;
		str1 += 1;
		str2 += 1;
	}
	
	return true;
}



bool Con_String_not_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	int i;
	Con_String_Object* str_obj1;
	Con_String_Object* str_obj2;
	char* str1;
	char* str2;

	if (val2.type != CON_VALUE_OBJECT || val2.datum.object->type != CON_OBJECT_STRING)
		return true;
	
	str_obj1 = (Con_String_Object*) val1.datum.object;
	str_obj2 = (Con_String_Object*) val2.datum.object;
	
	if (str_obj1->hash != str_obj2->hash || str_obj1->str_size != str_obj2->str_size)
		return true;
	
	str1 = str_obj1->str;
	str2 = str_obj2->str;
	for (i = 0; i < str_obj1->str_size; i += 1) {
		if (*str1 != *str2)
			return true;
		str1 += 1;
		str2 += 1;
	}
	
	return false;
}



Con_Value Con_String_add(Con_VM* vm, Con_Value str1, Con_Value str2)
{
	Con_String_Object* str_obj;
	Con_String_Object* str1_obj;
	Con_String_Object* str2_obj;
	Con_Value result;
	int combined_size;

	Con_VM_ensure_type(vm, str1, "s", "Can't add non-string to string.");
	if (!Con_VM_is_type(vm, str2, "s"))
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_STRING_CLASS], Con_Object_get_slot(vm, str2, "instance_of"));
	
	str1_obj = (Con_String_Object*) str1.datum.object;
	str2_obj = (Con_String_Object*) str2.datum.object;
	combined_size = str1_obj->str_size + str2_obj->str_size;
	result = Con_String_new_blank(vm, combined_size);
	str_obj = (Con_String_Object*) result.datum.object;

	memmove(str_obj->str, str1_obj->str, str1_obj->str_size);
	memmove(str_obj->str + str1_obj->str_size, str2_obj->str, str2_obj->str_size);
	str_obj->str[combined_size] = 0;
	str_obj->hash = Con_String_hash(str_obj->str, combined_size);
	
	return result;
}


Con_Value Con_String_slice(Con_VM* vm, Con_Value str, int lower, int upper)
{
	Con_String_Object* str_obj;

	Con_VM_ensure_type(vm, str, "s", "Can't slice non-string.");
	str_obj = (Con_String_Object*) str.datum.object;

	lower = Con_VM_translate_slice_index(vm, lower, Con_String_get_size(vm, str));
	upper = Con_VM_translate_slice_index(vm, upper, Con_String_get_size(vm, str));

	return Con_String_new(vm, str_obj->str + lower, upper - lower);
}



Con_Value Con_String_mul(Con_VM* vm, Con_Value str, int mul)
{
	Con_Value new_str;
	Con_String_Object* new_str_obj;
	Con_String_Object* str_obj = (Con_String_Object*) str.datum.object;
	int i;
	
	new_str = Con_String_new_blank(vm, str_obj->str_size * mul);
	new_str_obj = (Con_String_Object*) new_str.datum.object;
	
	for (i = 0; i < mul; i += 1) {
		memmove(new_str_obj->str + (str_obj->str_size * i), str_obj->str, str_obj->str_size);
	}

	new_str_obj->str[str_obj->str_size * mul] = 0;
	new_str_obj->hash = Con_String_hash(new_str_obj->str, str_obj->str_size * mul);
	
	return new_str;
}



Con_Value Con_String_upper_case(Con_VM* vm, Con_Value str)
{
	Con_Value new_str;
	Con_String_Object* new_str_obj;
	Con_String_Object* str_obj = (Con_String_Object*) str.datum.object;
	int i;
	char c;
	
	new_str = Con_String_new_blank(vm, str_obj->str_size);
	new_str_obj = (Con_String_Object*) new_str.datum.object;
	
	for (i = 0; i < str_obj->str_size; i += 1) {
		c = *(str_obj->str + i);
		if ((c >= 'a') && (c <= 'z'))
			c -= 'a' - 'A';
		new_str_obj->str[i] = c;
	}

	new_str_obj->str[str_obj->str_size] = 0;
	new_str_obj->hash = Con_String_hash(new_str_obj->str, str_obj->str_size);
	
	return new_str;
}



Con_Value Con_String_lower_case(Con_VM* vm, Con_Value str)
{
	Con_Value new_str;
	Con_String_Object* new_str_obj;
	Con_String_Object* str_obj = (Con_String_Object*) str.datum.object;
	int i;
	char c;
	
	new_str = Con_String_new_blank(vm, str_obj->str_size);
	new_str_obj = (Con_String_Object*) new_str.datum.object;
	
	for (i = 0; i < str_obj->str_size; i += 1) {
		c = *(str_obj->str + i);
		if ((c >= 'A') && (c <= 'Z'))
			c -= 'A' - 'a';
		new_str_obj->str[i] = c;
	}

	new_str_obj->str[str_obj->str_size] = 0;
	new_str_obj->hash = Con_String_hash(new_str_obj->str, str_obj->str_size);
	
	return new_str;
}


//
//
//




void _Con_String_len_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "o", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(((Con_String_Object*) self.datum.object)->str_size));
	Con_VM_return(vm);
}



void _Con_String_lookup_func(Con_VM* vm)
{
	Con_Value self, lookup_val;
	int index;
	Con_String_Object* str_obj;

	Con_VM_decode_args(vm, "si", &self, &lookup_val);
	str_obj = (Con_String_Object*) self.datum.object;
	
	index = Con_VM_translate_index(vm, lookup_val.datum.integer, str_obj->str_size);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new(vm, str_obj->str + index, 1));
	Con_VM_return(vm);
}



void _Con_String_slice_func(Con_VM* vm)
{
	Con_Value self, lower_val, upper_val;
	Con_String_Object* str_obj;
	int upper, lower;

	Con_VM_decode_args(vm, "s;oo", &self, &lower_val, &upper_val);
	str_obj = (Con_String_Object*) self.datum.object;

	if (Con_VM_is(vm, lower_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		lower = 0;
	else {
		if (!Con_VM_is_type(vm, lower_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 3, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, lower_val, "instance_of"), Con_String_new_c_str(vm, "lower bound"));
		lower = lower_val.datum.integer;
	}
	lower = Con_VM_translate_slice_index(vm, lower, str_obj->str_size);

	if (Con_VM_is(vm, upper_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		upper = str_obj->str_size;
	else {
		if (!Con_VM_is_type(vm, upper_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 3, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, upper_val, "instance_of"), Con_String_new_c_str(vm, "lower bound"));
		upper = upper_val.datum.integer;
	}
	upper = Con_VM_translate_slice_index(vm, upper, str_obj->str_size);

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_slice(vm, self, lower, upper));
	Con_VM_return(vm);
}



void _Con_String_to_str_func(Con_VM* vm)
{
	Con_Value self, str_val;

	Con_VM_decode_args(vm, "o", &self);
	
	str_val = Con_String_add(vm, Con_String_new_c_str(vm, "\""), self);
	str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, "\""));
	
	Con_VM_con_stack_push_value(vm, vm->continuation, str_val);
	Con_VM_return(vm);
}



void _Con_String_prefixed_by_func(Con_VM* vm)
{
	Con_Value self, prefix_val, start_val;
	Con_String_Object* self_obj;
	Con_String_Object* prefix_obj;
	int start, i;

	Con_VM_decode_args(vm, "ss;i", &self, &prefix_val, &start_val);
	self_obj = (Con_String_Object*) self.datum.object;
	prefix_obj = (Con_String_Object*) prefix_val.datum.object;
	
	if (Con_VM_is(vm, start_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		start = 0;
	else
		start = start_val.datum.integer;
	start = Con_VM_translate_index(vm, start, self_obj->str_size);
	
	if (self_obj->str_size - start < prefix_obj->str_size)
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	else {
		for (i = 0; i < prefix_obj->str_size; i += 1) {
			if (*(self_obj->str + start + i) != *(prefix_obj->str + i))
				break;
		}
		if (i == prefix_obj->str_size)
			Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
		else
			Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	}
	Con_VM_return(vm);
}



void _Con_String_upper_case_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "s", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_upper_case(vm, self));
	Con_VM_return(vm);
}



void _Con_String_lower_case_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "s", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_lower_case(vm, self));
	Con_VM_return(vm);
}



void _Con_String_ascii_val_func(Con_VM* vm)
{
	Con_Value self;
	Con_String_Object* str_obj;

	Con_VM_decode_args(vm, "s", &self);
	str_obj = (Con_String_Object*) self.datum.object;
	
	Con_VM_translate_index(vm, 0, str_obj->str_size);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(((short*) str_obj->str)[0]));
	Con_VM_return(vm);
}




void _Con_String_iterate_func(Con_VM* vm)
{
	Con_Value self;
	Con_String_Object* str_obj;
	int i;

	Con_VM_decode_args(vm, "s", &self);
	str_obj = (Con_String_Object*) self.datum.object;

	for (i = 0; i < str_obj->str_size; i += 1) {	
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new(vm, str_obj->str + i, 1));
		Con_VM_yield(vm);
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}



// Finds overlapping substrings

void _Con_String_find_func(Con_VM* vm)
{
	Con_Value self, find_val;
	Con_String_Object* str_obj;
	Con_String_Object* find_str_obj;
	int i, j;
	bool match;

	Con_VM_decode_args(vm, "ss", &self, &find_val);
	str_obj = (Con_String_Object*) self.datum.object;
	find_str_obj = (Con_String_Object*) find_val.datum.object;

	for (i = 0; i < str_obj->str_size; i += 1) {
		if (i + find_str_obj->str_size >= str_obj->str_size)
			break;
		match = true;
		for (j = 0; j < find_str_obj->str_size; j += 1) {
			if (str_obj->str[i + j] != find_str_obj->str[j]) {
				match = false;
				break;
			}
		}
		if (match) {
			Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(i));
			Con_VM_yield(vm);
		}
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}




void _Con_String_hash_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "s", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(((Con_String_Object*) self.datum.object)->hash));
	Con_VM_return(vm);
}



// Finds overlapping substrings starting from the right

void _Con_String_rfind_func(Con_VM* vm)
{
	Con_Value self, find_val;
	Con_String_Object* str_obj;
	Con_String_Object* find_str_obj;
	int i, j;
	bool match;

	Con_VM_decode_args(vm, "ss", &self, &find_val);
	str_obj = (Con_String_Object*) self.datum.object;
	find_str_obj = (Con_String_Object*) find_val.datum.object;

	for (i = str_obj->str_size - find_str_obj->str_size; i >= 0; i -= 1) {
		match = true;
		for (j = 0; j < find_str_obj->str_size; j += 1) {
			if (str_obj->str[i + j] != find_str_obj->str[j]) {
				match = false;
				break;
			}
		}
		if (match) {
			Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(i));
			Con_VM_yield(vm);
		}
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}



void _Con_String_dcopy_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "s", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, self);
	Con_VM_return(vm);
}
