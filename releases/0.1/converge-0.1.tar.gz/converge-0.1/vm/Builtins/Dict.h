// Internals

#define Con_DICT_DEFAULT_NUMBER_ITEMS_ALLOCATED 14
#define Con_DICT_NUMBER_ITEMS_INCREMENT_ALLOCATION 30

typedef struct {
	Con_Hash hash;
	Con_Value key;
	Con_Value value;
	} Con_Dict_Item;

typedef struct {
	CON_OBJECT_HEAD
	int num_items;
	int num_items_allocated;
	Con_Dict_Item* items;
	} Con_Dict_Object;

void Con_Dict_class_bootstrap(Con_VM* vm);
Con_Value Con_Dict_new(Con_VM* vm);
Con_Value Con_Dict_new_init_from_stack(Con_VM* vm, int num_items);
void Con_Dict_set_item(Con_VM* vm, Con_Value dict_val, Con_Value key, Con_Value val);
Con_Value Con_Dict_lookup(Con_VM* vm, Con_Value dict_val, Con_Value key);
Con_Value Con_Dict_get_keys(Con_VM* vm, Con_Value dict);
Con_Value Con_Dict_get_keys_as_set(Con_VM* vm, Con_Value dict);
int Con_Dict_len(Con_VM* vm, Con_Value dict);
bool Con_Dict_contains(Con_VM* vm, Con_Value dict_val, Con_Value key);
