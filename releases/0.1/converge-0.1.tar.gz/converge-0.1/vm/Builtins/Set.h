////////////////////////////////////////////////////////////////////////////////////////////////////
// Internals
//

#define CON_SET_DEFAULT_NUMBER_ITEMS_ALLOCATED 32
#define CON_SET_NUMBER_ITEMS_INCREMENT_ALLOCATION 32

typedef struct {
	Con_Hash hash;
	Con_Value val;
	} Con_Set_Item;

typedef struct {
	CON_OBJECT_HEAD
	int num_items;
	int num_items_allocated;
	Con_Set_Item* items;
	} Con_Set_Object;


////////////////////////////////////////////////////////////////////////////////////////////////////
// Public functions
//

void Con_Set_class_bootstrap(Con_VM* vm);
Con_Value Con_Set_new(Con_VM* vm);
void Con_Set_add(Con_VM* vm, Con_Value set, Con_Value val);
bool Con_Set_contains(Con_VM* vm, Con_Value set, Con_Value val);
