typedef struct {
	CON_OBJECT_HEAD
	size_t obj_size;
	} Con_Meta_C_Class_Obj;

void Con_Meta_C_Class_bootstrap(Con_VM* vm);
Con_Value Con_Meta_C_Class_new(Con_VM* vm, Con_Value name, Con_Value supers, Con_Value fields, size_t obj_size);
