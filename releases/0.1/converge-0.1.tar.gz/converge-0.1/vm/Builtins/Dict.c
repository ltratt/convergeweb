#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Dict.h"
#include "Memory.h"
#include "Object.h"
#include "String.h"
#include "List.h"
#include "Func.h"
#include "Set.h"
#include "Object_Class.h"

#include "Builtins/Int.h"

#include "Modules/Exceptions.h"



void _Con_Dict_lookup_func(Con_VM* vm);
void _Con_Dict_set_func(Con_VM* vm);
void _Con_Dict_len_func(Con_VM* vm);
void _Con_Dict_to_str_func(Con_VM* vm);
void _Con_Dict_contains_func(Con_VM* vm);
void _Con_Dict_keys_func(Con_VM* vm);
void _Con_Dict_dcopy_func(Con_VM* vm);



void Con_Dict_class_bootstrap(Con_VM* vm)
{
	Con_Value supers, fields, lookup_func, set_func, len_func, to_str_func, contains_func, keys_func, dcopy_func;

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_DICT_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_DICT_CLASS], "name", Con_String_new_c_str(vm, "Dict"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_DICT_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));

	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_DICT_CLASS], "supers", supers);
	
	fields = Con_Dict_new(vm);
	
	lookup_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Dict_lookup_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "lookup"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "lookup"), lookup_func);

	set_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Dict_set_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "set"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "set"), set_func);

	contains_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Dict_contains_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "contains"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "contains"), contains_func);

	len_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Dict_len_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "len"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "len"), len_func);

	keys_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Dict_keys_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "keys"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "keys"), keys_func);

	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Dict_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);

	dcopy_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Dict_dcopy_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "dcopy"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "dcopy"), dcopy_func);

/*	iterate_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_iterate, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "iterate"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "iterate"), iterate_func); */
	
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_DICT_CLASS], "fields", fields);
}



Con_Value Con_Dict_new(Con_VM* vm)
{
	Con_Dict_Object* dict;
	Con_Value result;
	
	result.type = CON_VALUE_OBJECT;
	dict = Con_malloc(vm, sizeof(Con_Dict_Object), Con_MEMORY_OBJECT);
	result.datum.object = (Con_Object*) dict;
	dict->type = CON_OBJECT_DICT;
	
	Con_Object_init(vm, (Con_Object*) dict);
	
//	Con_Object_set_slot(vm, result, "instance_of", vm->builtins[CON_BUILTIN_DICT_CLASS]);
	
	dict->items = Con_malloc(vm, Con_DICT_DEFAULT_NUMBER_ITEMS_ALLOCATED * sizeof(Con_Dict_Item), Con_MEMORY_NON_GC);
	dict->num_items = 0;
	dict->num_items_allocated = Con_DICT_DEFAULT_NUMBER_ITEMS_ALLOCATED;
	
	return result;
}



Con_Value Con_Dict_new_init_from_stack(Con_VM* vm, int num_items)
{
	Con_Value result;
	int i;

	result = Con_Dict_new(vm);
	for (i = 0; i < num_items; i += 1) {
		Con_Dict_set_item(vm, result, Con_VM_con_stack_pop_value(vm, vm->continuation), Con_VM_con_stack_pop_value(vm, vm->continuation));
	}
	
	return result;
}



void Con_Dict_set_item(Con_VM* vm, Con_Value dict_val, Con_Value key, Con_Value val)
{
	Con_Value hash_val;
	Con_Hash hash;
	int i;
	Con_Dict_Object* dict = (Con_Dict_Object*) dict_val.datum.object;
	Con_Dict_Item* item;
	
	// Calculate the hash
	
	if (key.type == CON_VALUE_OBJECT && key.datum.object->type == CON_OBJECT_STRING) {
		hash = ((Con_String_Object*) key.datum.object)->hash;
	}
	else {
		hash_val = Con_VM_apply_c(vm, Con_Object_get_slot(vm, key, "hash"), 0);
		if (!Con_VM_is_type(vm, hash_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, hash_val, "instance_of"));
		hash = hash_val.datum.integer;
	}
	
	item = dict->items;
	for (i = 0; i < dict->num_items; i += 1) {
		if (item->hash == hash && Con_VM_equals(vm, key, item->key))
			break;
		item += 1;
	}
	
	if (i == dict->num_items) {
		if (dict->num_items == dict->num_items_allocated) { 
			dict->items = Con_realloc(vm, dict->items, (dict->num_items_allocated + Con_DICT_NUMBER_ITEMS_INCREMENT_ALLOCATION) * sizeof(Con_Dict_Item));
			dict->num_items_allocated += Con_DICT_NUMBER_ITEMS_INCREMENT_ALLOCATION;
		}
		item = &dict->items[dict->num_items];
		dict->num_items += 1;
	}
	
	item->hash = hash;
	item->key = key;
	item->value = val;
}



Con_Value Con_Dict_lookup(Con_VM* vm, Con_Value dict_val, Con_Value key)
{
	Con_Value hash_val;
	int i, hash;
	Con_Dict_Object* dict = (Con_Dict_Object*) dict_val.datum.object;
	Con_Dict_Item* item;
	
	// Calculate the hash
	
	if (key.type == CON_VALUE_OBJECT && key.datum.object->type == CON_OBJECT_STRING) {
		hash = ((Con_String_Object*) key.datum.object)->hash;
	}
	else {
		hash_val = Con_VM_apply_c(vm, Con_Object_get_slot(vm, key, "hash"), 0);
		if (!Con_VM_is_type(vm, hash_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, hash_val, "instance_of"));
		hash = hash_val.datum.integer;
	}
	
	item = dict->items;
	for (i = 0; i < dict->num_items; i += 1) {
		if (item->hash == hash && Con_VM_equals(vm, key, item->key))
			return item->value;
		item += 1;
	}

	Con_Mod_Exceptions_quick(vm, "Key_Exception", 1, key);
	
	// We'll never get here, but just to shut the compiler up...
	return vm->builtins[CON_BUILTIN_NULL_VAL];
}



Con_Value Con_Dict_get_keys(Con_VM* vm, Con_Value dict)
{
	Con_Dict_Object* dict_obj = (Con_Dict_Object*) dict.datum.object;
	Con_Dict_Item* item;
	Con_Value list;
	int i;
	
	list = Con_List_new(vm);
	item = dict_obj->items;
	for (i = 0; i < dict_obj->num_items; i += 1) {
		Con_List_append(vm, list, item->key);
		item += 1;
	}
	
	return list;
}



Con_Value Con_Dict_get_keys_as_set(Con_VM* vm, Con_Value dict)
{
	Con_Dict_Object* dict_obj = (Con_Dict_Object*) dict.datum.object;
	Con_Dict_Item* item;
	Con_Value set;
	int i;
	
	set = Con_Set_new(vm);
	item = dict_obj->items;
	for (i = 0; i < dict_obj->num_items; i += 1) {
		Con_Set_add(vm, set, item->key);
		item += 1;
	}
	
	return set;
}



int Con_Dict_len(Con_VM* vm, Con_Value dict)
{
	return ((Con_Dict_Object*) dict.datum.object)->num_items;
}



bool Con_Dict_contains(Con_VM* vm, Con_Value dict_val, Con_Value key)
{
	Con_Hash hash = NULL;
	int i;
	Con_Dict_Object* dict = (Con_Dict_Object*) dict_val.datum.object;
	Con_Dict_Item* item;
	
	// Calculate the hash
	
	if (key.type == CON_VALUE_OBJECT && key.datum.object->type == CON_OBJECT_STRING) {
		hash = ((Con_String_Object*) key.datum.object)->hash;
	}
	else {
		Con_Mod_Exceptions_quick(vm, "Unhashable_Exception", 1, key);
	}
	
	item = dict->items;
	for (i = 0; i < dict->num_items; i += 1) {
		if (item->hash == hash && Con_VM_equals(vm, key, item->key))
			return true;
		item += 1;
	}
	
	return false;
}



//
// Methods
//


void _Con_Dict_lookup_func(Con_VM* vm)
{
	Con_Value self, key;

	Con_VM_decode_args(vm, "do", &self, &key);

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Dict_lookup(vm, self, key));
	Con_VM_return(vm);
}



void _Con_Dict_set_func(Con_VM* vm)
{
	Con_Value self, key, val;

	Con_VM_decode_args(vm, "doo", &self, &key, &val);

	Con_Dict_set_item(vm, self, key, val);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_Dict_len_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "d", &self);

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(Con_Dict_len(vm, self)));
	Con_VM_return(vm);
}



void _Con_Dict_to_str_func(Con_VM* vm)
{
	Con_Value self, str_val, keys, key;
	int i;

	Con_VM_decode_args(vm, "d", &self);

	keys = Con_Dict_get_keys(vm, self);
	str_val = Con_String_new_c_str(vm, "Dict{");
	for (i = 0; i < Con_Dict_len(vm, self); i += 1) {
		if (i > 0)
			str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, ", "));
		key = Con_List_get_item(vm, keys, i);
		str_val = Con_String_add(vm, str_val, Con_VM_apply_c(vm, Con_Object_get_slot(vm, key, "to_str"), 0));
		str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, " : "));
		str_val = Con_String_add(vm, str_val, Con_VM_apply_c(vm, Con_Object_get_slot(vm, Con_Dict_lookup(vm, self, key), "to_str"), 0));
	}
	str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, "}"));
	
	Con_VM_con_stack_push_value(vm, vm->continuation, str_val);
	Con_VM_return(vm);
}



void _Con_Dict_contains_func(Con_VM* vm)
{
	Con_Value self, contains_val;

	Con_VM_decode_args(vm, "do", &self, &contains_val);
	
	if (Con_Dict_contains(vm, self, contains_val))
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	else
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}



void _Con_Dict_keys_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "d", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Dict_get_keys_as_set(vm, self));
	Con_VM_return(vm);
}



void _Con_Dict_dcopy_func(Con_VM* vm)
{
	Con_Value self, new_dict, key_dcopy, value_dcopy;
	Con_Dict_Object* dict;
	int i;

	Con_VM_decode_args(vm, "d", &self);
	dict = (Con_Dict_Object*) self.datum.object;
	
	new_dict = Con_Dict_new(vm);
	for (i = 0; i < dict->num_items; i += 1) {
		key_dcopy = Con_VM_apply_c(vm, Con_Object_get_slot(vm, dict->items[i].key, "dcopy"), 0);
		value_dcopy = Con_VM_apply_c(vm, Con_Object_get_slot(vm, dict->items[i].value, "dcopy"), 0);
		Con_Dict_set_item(vm, new_dict, key_dcopy, value_dcopy);
	}
	
	Con_VM_con_stack_push_value(vm, vm->continuation, new_dict);
	Con_VM_return(vm);
}
