void Con_Null_Class_bootstrap(Con_VM* vm);
