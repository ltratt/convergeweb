typedef struct {
	CON_OBJECT_HEAD
	Con_Value self_obj;
	Con_Value func;
	} Con_Object_Func_Binding;

void Con_Func_Binding_class_bootstrap(Con_VM* vm);
Con_Value Con_Func_Binding_new(Con_VM* vm, Con_Value self_obj, Con_Value func);
