#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Memory.h"
#include "Module.h"
#include "Object.h"
#include "Object_Class.h"
#include "Builtins/String.h"
#include "Builtins/Dict.h"
#include "Builtins/List.h"
#include "Builtins/Func.h"


void _Con_Module_to_str_func(Con_VM* vm);


void Con_Module_class_bootstrap(Con_VM* vm)
{
	Con_Value supers, fields, to_str_func;

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_MODULE_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_MODULE_CLASS], "name", Con_String_new_c_str(vm, "Module"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_MODULE_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));

	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_MODULE_CLASS], "supers", supers);
	
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_MODULE_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));
	
	fields = Con_Dict_new(vm);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_MODULE_CLASS], "fields", fields);

	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Module_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);
}



Con_Value Con_Module_new(Con_VM* vm, Con_Module* module)
{
	Con_Module_Obj* module_obj;
	Con_Value result;

	result.type = CON_VALUE_OBJECT;
	module_obj = Con_malloc(vm, sizeof(Con_Module_Obj), Con_MEMORY_OBJECT);
	module_obj->module = module;
	result.datum.object = (Con_Object*) module_obj;
	result.datum.object->type = CON_OBJECT_MODULE;
	
	Con_Object_init(vm, (Con_Object*) module_obj);
	
	Con_Object_set_slot(vm, result, "instance_of", vm->builtins[CON_BUILTIN_MODULE_CLASS]);
	Con_Object_set_slot(vm, result, "name", Con_String_new_c_str(vm, module->module_name));
	
	return result;
}



void _Con_Module_to_str_func(Con_VM* vm)
{
	Con_Value self, str_val;
	Con_Module_Obj* module;

	Con_VM_decode_args(vm, "m", &self);
	module = (Con_Module_Obj*) self.datum.object;

	str_val = Con_String_new_c_str(vm, "<Module ");
	str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, module->module->module_name));
	str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, ">"));

	Con_VM_con_stack_push_value(vm, vm->continuation, str_val);
	Con_VM_return(vm);
}
