#include <stdio.h>
#include <stdlib.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Int.h"
#include "Object.h"
#include "String.h"
#include "Dict.h"
#include "List.h"
#include "Func.h"
#include "Func_Binding.h"

#include "Modules/Exceptions.h"




void _Con_Int_Class_to_str(Con_VM* vm);
void _Con_Int_Class_new_func(Con_VM* vm);
void _Con_Int_Class_upto(Con_VM* vm);
void _Con_Int_Class_or(Con_VM* vm);
void _Con_Int_Class_lsl(Con_VM* vm);
void _Con_Int_Class_lsr(Con_VM* vm);
void _Con_Int_Class_and(Con_VM* vm);
void _Con_Int_Class_unot(Con_VM* vm);
void _Con_Int_Class_hash(Con_VM* vm);
void _Con_Int_Class_ascii_char(Con_VM* vm);
void _Con_Int_Class_dcopy(Con_VM* vm);




void Con_Int_Class_bootstrap(Con_VM* vm)
{
	Con_Value fields, to_str_func, supers, new_func, upto_func, or_func, lsl_func, lsr_func, and_func, unot_func, hash_func, ascii_char_func, dcopy_func;
	
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_INT_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_INT_CLASS], "name", Con_String_new_c_str(vm, "Int"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_INT_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));
	
	fields = Con_Dict_new(vm);
	
	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_INT_CLASS], "supers", supers);
	
	new_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_new_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "new"), 0, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_INT_CLASS], "new", new_func);
	
	// Methods
	
	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_to_str, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);

	upto_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_upto, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "upto"), 0, NULL, NULL);

	or_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_or, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "or"), 0, NULL, NULL);
	
	lsl_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_lsl, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "lsl"), 0, NULL, NULL);
	
	lsr_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_lsr, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "lsr"), 0, NULL, NULL);

	and_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_and, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "and"), 0, NULL, NULL);
	
	unot_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_unot, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "unot"), 0, NULL, NULL);
	
	hash_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_hash, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "hash"), 0, NULL, NULL);
	
	ascii_char_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_ascii_char, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "ascii_char"), 0, NULL, NULL);

	dcopy_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Int_Class_dcopy, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "dcopy"), 0, NULL, NULL);

	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "upto"), upto_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "or"), or_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "lsl"), lsl_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "lsr"), lsr_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "and"), and_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "unot"), unot_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "hash"), hash_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "ascii_char"), ascii_char_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "dcopy"), dcopy_func);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_INT_CLASS], "fields", fields);
}



Con_Value Con_Int_new(int integer)
{
	Con_Value result;
	
	result.type = CON_VALUE_INT;
	result.datum.integer = integer;
	
	return result;
}



bool Con_Int_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type != CON_VALUE_INT)
		return false;
	
	if (val1.datum.integer == val2.datum.integer)
		return true;
	
	return false;
}



bool Con_Int_not_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type != CON_VALUE_INT)
		XXX;
	
	if (val1.datum.integer != val2.datum.integer)
		return true;
	
	return false;
}



bool Con_Int_less_than(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type != CON_VALUE_INT)
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, val2, "instance_of"));
	
	if (val1.datum.integer < val2.datum.integer)
		return true;
	
	return false;
}



bool Con_Int_greater_than(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type != CON_VALUE_INT)
		XXX;
	
	if (val1.datum.integer > val2.datum.integer)
		return true;
	
	return false;
}



bool Con_Int_greater_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type != CON_VALUE_INT)
		XXX;
	
	if (val1.datum.integer >= val2.datum.integer)
		return true;
	
	return false;
}



bool Con_Int_less_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type != CON_VALUE_INT)
		XXX;
	
	if (val1.datum.integer <= val2.datum.integer)
		return true;
	
	return false;
}



Con_Value Con_Int_subtract(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	Con_Value result;

	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type == CON_VALUE_INT) {
		result.type = CON_VALUE_INT;
		result.datum.integer = val1.datum.integer - val2.datum.integer;
	}
	else
		XXX;
	
	return result;
}



Con_Value Con_Int_add(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	Con_Value result;

	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type == CON_VALUE_INT) {
		result.type = CON_VALUE_INT;
		result.datum.integer = val1.datum.integer + val2.datum.integer;
	}
	else
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, val2, "instance_of"));
	
	return result;
}



Con_Value Con_Int_mul(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	Con_Value result;

	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type == CON_VALUE_INT) {
		result.type = CON_VALUE_INT;
		result.datum.integer = val1.datum.integer * val2.datum.integer;
	}
	else
		XXX;
	
	return result;
}



Con_Value Con_Int_divide(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	Con_Value result;

	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type == CON_VALUE_INT) {
		result.type = CON_VALUE_INT;
		result.datum.integer = val1.datum.integer / val2.datum.integer;
	}
	else
		XXX;
	
	return result;
}



Con_Value Con_Int_modulo(Con_VM* vm, Con_Value val1, Con_Value val2)
{
	Con_Value result;

	if (val1.type != CON_VALUE_INT)
		CON_FATAL_ERROR("val1 is not an int.");
	else if (val2.type == CON_VALUE_INT) {
		result.type = CON_VALUE_INT;
		result.datum.integer = val1.datum.integer % val2.datum.integer;
	}
	else
		XXX;
	
	return result;
}



int Con_Int_extract(Con_VM* vm, Con_Value int_val)
{
	if (!Con_VM_is_type(vm, int_val, "i"))
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, int_val, "instance_of"));
	
	return int_val.datum.integer;
}



////////////////////////////////////////////////////////////////////////////////////////////////////
// Methods
//


#define MAX_INTEGER_SIZE_AS_STRING 20

void _Con_Int_Class_to_str(Con_VM* vm)
{
	Con_Value self;
	char buffer[MAX_INTEGER_SIZE_AS_STRING];

	Con_VM_decode_args(vm, "i", &self);
	
	snprintf((char*) &buffer, MAX_INTEGER_SIZE_AS_STRING, "%d", self.datum.integer);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, (char*) &buffer));
	
	Con_VM_return(vm);
}




void _Con_Int_Class_new_func(Con_VM* vm)
{
	Con_Value self, val;

	Con_VM_decode_args(vm, "cs", &self, &val);

	if (Con_VM_is_type(vm, val, "s"))
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(atoi(((Con_String_Object*) val.datum.object)->str)));
	else
		XXX
	
	Con_VM_return(vm);
}



void _Con_Int_Class_upto(Con_VM* vm)
{
	Con_Value self, upto_val;
	int i;

	Con_VM_decode_args(vm, "ii", &self, &upto_val);
	
	for (i = self.datum.integer; i < upto_val.datum.integer; i += 1) {
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(i));
		Con_VM_yield(vm);
	}
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}




void _Con_Int_Class_or(Con_VM* vm)
{
	Con_Value self, or_val;

	Con_VM_decode_args(vm, "ii", &self, &or_val);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(self.datum.integer | or_val.datum.integer));
	Con_VM_return(vm);
}



void _Con_Int_Class_lsl(Con_VM* vm)
{
	Con_Value self, lsl_val;

	Con_VM_decode_args(vm, "ii", &self, &lsl_val);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(self.datum.integer << lsl_val.datum.integer));
	Con_VM_return(vm);
}



void _Con_Int_Class_lsr(Con_VM* vm)
{
	Con_Value self, or_val;

	Con_VM_decode_args(vm, "ii", &self, &or_val);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(self.datum.integer >> or_val.datum.integer));
	Con_VM_return(vm);
}



void _Con_Int_Class_and(Con_VM* vm)
{
	Con_Value self, and_val;

	Con_VM_decode_args(vm, "ii", &self, &and_val);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(self.datum.integer & and_val.datum.integer));
	Con_VM_return(vm);
}



void _Con_Int_Class_unot(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "i", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(~self.datum.integer));
	Con_VM_return(vm);
}



void _Con_Int_Class_hash(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "i", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, self);
	Con_VM_return(vm);
}



void _Con_Int_Class_ascii_char(Con_VM* vm)
{
	Con_Value self;
	char s[2];

	Con_VM_decode_args(vm, "i", &self);
	
	if ((self.datum.integer < 0) || (self.datum.integer > 255))
		Con_Mod_Exceptions_quick(vm, "Exception", 1, Con_String_new_c_str(vm, "Integer is out of range to convert to ASCII char"));
	
	s[0] = (short) self.datum.integer;
	s[1] = 0;
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, s));
	Con_VM_return(vm);
}



void _Con_Int_Class_dcopy(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "i", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, self);
	Con_VM_return(vm);
}
