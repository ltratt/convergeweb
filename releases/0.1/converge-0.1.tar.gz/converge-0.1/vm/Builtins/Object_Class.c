#include <stddef.h>
#include <stdio.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Object_Class.h"
#include "Dict.h"
#include "Func.h"
#include "String.h"
#include "List.h"

#include "Modules/Exceptions.h"



void _Con_Object_Class_new(Con_VM* vm);
void _Con_Object_Class_new(Con_VM* vm);
void _Con_Object_Class_new_finish(Con_VM* vm);
void Con_Object_Class_new_populate(Con_VM* vm, Con_Value obj, Con_Value class);
void _Con_Object_Class_init(Con_VM* vm);
void _Con_Object_Class_to_str_func(Con_VM* vm);
void _Con_Object_Class_has_slot_func(Con_VM* vm);
void _Con_Object_Class_is_instance_func(Con_VM* vm);
void _Con_Object_Class_get_slot_func(Con_VM* vm);
void _Con_Object_Class_dcopy_func(Con_VM* vm);
void _Con_Object_Class_set_slot_func(Con_VM* vm);



void Con_Object_Class_bootstrap(Con_VM* vm)
{
	Con_Value fields, new_func, init_func, has_slot_func, to_str_func, supers, is_instance_func, get_slot_func, dcopy_func, set_slot_func;

	fields = Con_Dict_new(vm);

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "name", Con_String_new_c_str(vm, "Object"));
	
	supers = Con_List_new(vm);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "supers", supers);

	new_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Object_Class_new, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "new"), 1, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "new", new_func);	

	init_func = Con_Func_new(vm, 1, (Con_PC) (C_Function) _Con_Object_Class_init, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 1, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "init", new_func);

	has_slot_func = Con_Func_new(vm, 1, (Con_PC) (C_Function) _Con_Object_Class_has_slot_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "has_slot"), 1, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "has_slot", has_slot_func);
	vm->builtins[CON_BUILTIN_DEFAULT_HAS_SLOT_FUNC] = has_slot_func;

	get_slot_func = Con_Func_new(vm, 1, (Con_PC) (C_Function) _Con_Object_Class_get_slot_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "get_slot"), 1, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "get_slot", get_slot_func);
	vm->builtins[CON_BUILTIN_DEFAULT_GET_SLOT_FUNC] = get_slot_func;

	set_slot_func = Con_Func_new(vm, 1, (Con_PC) (C_Function) _Con_Object_Class_set_slot_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "set_slot"), 1, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "set_slot", set_slot_func);
	vm->builtins[CON_BUILTIN_DEFAULT_SET_SLOT_FUNC] = set_slot_func;

	is_instance_func = Con_Func_new(vm, 1, (Con_PC) (C_Function) _Con_Object_Class_is_instance_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "is_instance"), 1, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "is_instance", is_instance_func);

	dcopy_func = Con_Func_new(vm, 1, (Con_PC) (C_Function) _Con_Object_Class_dcopy_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "dcopy"), 1, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "dcopy", dcopy_func);

	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Object_Class_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);

	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "new"), new_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "init"), init_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "has_slot"), has_slot_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "get_slot"), get_slot_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "is_instance"), is_instance_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "dcopy"), dcopy_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "set_slot"), set_slot_func);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "fields", fields);
}



void _Con_Object_Class_new(Con_VM* vm)
{
	Con_Value self, var_args, new_obj;
	int i;

	Con_VM_decode_args(vm, "ov", &self, &var_args);

	new_obj = Con_Object_new(vm);
	Con_Object_set_slot(vm, new_obj, "instance_of", self);
	
	Con_Object_Class_new_populate(vm, new_obj, self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, new_obj);
	Con_VM_add_failure_frame(vm, (Con_PC) (C_Function) _Con_Object_Class_new_finish, PC_TYPE_C_FUNCTION);
	Con_VM_con_stack_push_value(vm, vm->continuation, new_obj);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, new_obj, "init"));
	for (i = 0; i < Con_List_get_size(vm, var_args); i += 1) {
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_get_item(vm, var_args, i));
	}
	
	Con_VM_apply(vm, Con_List_get_size(vm, var_args));
	Con_VM_con_stack_pop_value(vm, vm->continuation);

	Con_VM_return(vm);
}



void _Con_Object_Class_new_finish(Con_VM* vm)
{
	Con_VM_return(vm);
}



void Con_Object_Class_new_populate(Con_VM* vm, Con_Value new_obj, Con_Value class)
{
	char* slot_name;
	Con_Value fields, fields_keys, key, val, supers;
	int i;

	fields = Con_Object_get_slot(vm, class, "fields");
	fields_keys = Con_Dict_get_keys(vm, fields);
	for (i = 0; i < Con_List_get_size(vm, fields_keys); i += 1) {
		key = Con_List_get_item(vm, fields_keys, i);
		Con_VM_ensure_type(vm, key, "s", "fields contains keys which are not strings.");
		slot_name = ((Con_String_Object*) key.datum.object)->str;
		if (!Con_Object_has_slot(vm, new_obj, slot_name)) {
			val = Con_Dict_lookup(vm, fields, key);
			// We can't set container for things like ints...
			if (val.type == CON_VALUE_OBJECT)
				Con_Object_set_slot(vm, val, "container", class);
			Con_Object_set_slot_raw(vm, new_obj, slot_name, val);
		}
	}
	supers = Con_Object_get_slot(vm, class, "supers");
	for (i = 0; i < Con_List_get_size(vm, supers); i += 1) {
		Con_Object_Class_new_populate(vm, new_obj, Con_List_get_item(vm, supers, i));
	}
}




void _Con_Object_Class_init(Con_VM* vm)
{
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);

	Con_VM_return(vm);
}



void _Con_Object_Class_has_slot_func(Con_VM* vm)
{
	Con_Value self, slot_name;

	Con_VM_decode_args(vm, "os", &self, &slot_name);
	
	if (Con_Object_has_slot(vm, self, ((Con_String_Object*) slot_name.datum.object)->str))
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	else
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
		
	Con_VM_return(vm);
}




#define TO_STR_WIDTH (((int) sizeof(void*)) * 2 + sizeof("<Object@0x>") + 1)

void _Con_Object_Class_to_str_func(Con_VM* vm)
{
	char str[TO_STR_WIDTH];
	Con_Value self;

	Con_VM_decode_args(vm, "o", &self);

	if (snprintf(str, TO_STR_WIDTH, "<Object@%p>", self.datum.object) >= TO_STR_WIDTH)
		CON_FATAL_ERROR("Unable to print object ID");

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, (const char*) &str));
	Con_VM_return(vm);
}



void _Con_Object_Class_is_instance_func(Con_VM* vm)
{
	Con_Value self, class;

	Con_VM_decode_args(vm, "oc", &self, &class);

	if (Con_VM_instance_of(vm, self, class))
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	else
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);

	Con_VM_return(vm);
}



void _Con_Object_Class_get_slot_func(Con_VM* vm)
{
	Con_Value self, slot_name;

	Con_VM_decode_args(vm, "os", &self, &slot_name);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot_raw(vm, self, ((Con_String_Object*) slot_name.datum.object)->str));
		
	Con_VM_return(vm);
}



void _Con_Object_Class_dcopy_func(Con_VM* vm)
{
	Con_Value self, dcopy_obj, slot_val, msg;
	Con_Object* self_obj;
	char* slot_name;
	int i;

	Con_VM_decode_args(vm, "o", &self);
	self_obj = (Con_Object*) self.datum.object;

	if (!(self.type == CON_VALUE_OBJECT && self.datum.object->type == CON_NORMAL_OBJECT)) {
		msg = Con_String_new_c_str(vm, "dcopy needs to be overriden in the '");
		msg = Con_String_add(vm, msg, Con_Object_get_slot(vm, Con_Object_get_slot(vm, self, "instance_of"), "name"));
		msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "' class"));
		Con_Mod_Exceptions_quick(vm, "Exception", 1, msg);
	}

	dcopy_obj = Con_Object_new(vm);
	Con_Object_init(vm, (Con_Object*) dcopy_obj.datum.object);
	
	for (i = 0; i < self_obj->num_slots; i += 1) {
		slot_val = ((Con_Slot*) self_obj->slots)[i].value;
		slot_name = self_obj->slots_names + ((Con_Slot*) self_obj->slots)[i].name_offset;
		if (strcmp(slot_name, "instance_of") == 0) {
			Con_Object_set_slot(vm, dcopy_obj, slot_name, slot_val);
			continue;
		}
		if (slot_val.type == CON_VALUE_INT)
			Con_Object_set_slot(vm, dcopy_obj, slot_name, slot_val);
		else if (slot_val.type == CON_VALUE_OBJECT) {
			if (slot_val.datum.object->type == CON_OBJECT_FUNC)
				Con_Object_set_slot(vm, dcopy_obj, slot_name, slot_val);
			else
				Con_Object_set_slot(vm, dcopy_obj, slot_name, Con_VM_apply_c(vm, Con_Object_get_slot(vm, slot_val, "dcopy"), 0));
		}
		else {
			XXX
		}
	}
	Con_VM_con_stack_push_value(vm, vm->continuation, dcopy_obj);

	Con_VM_return(vm);
}



void _Con_Object_Class_set_slot_func(Con_VM* vm)
{
	Con_Value self, slot_name, value;

	Con_VM_decode_args(vm, "oso", &self, &slot_name, &value);
	
	Con_Object_set_slot_raw(vm, self, ((Con_String_Object*) slot_name.datum.object)->str, value);
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
		
	Con_VM_return(vm);
}
