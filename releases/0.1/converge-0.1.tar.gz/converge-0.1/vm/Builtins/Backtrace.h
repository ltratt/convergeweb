#include "VM.h"

// Internals

typedef struct {
	CON_OBJECT_HEAD
	Con_PC pc;
	Con_PC_Type pc_type;
	} Con_Backtrace_Obj;


void Con_Backtrace_Class_bootstrap(Con_VM* vm);
Con_Value Con_Backtrace_new(Con_VM* vm, Con_Value module, Con_Value func, Con_PC pc, Con_PC_Type pc_type);
