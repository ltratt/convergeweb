#include "VM.h"

// Internals

typedef struct {
	CON_OBJECT_HEAD
	Con_Module* module;
	} Con_Module_Obj;


void Con_Module_class_bootstrap(Con_VM* vm);
Con_Value Con_Module_new(Con_VM* vm, Con_Module* module);
