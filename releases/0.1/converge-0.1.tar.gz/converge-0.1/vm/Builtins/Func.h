#include "VM.h"


typedef struct {
	CON_OBJECT_HEAD
	bool is_bound;
	Con_PC pc;
	Con_PC_Type pc_type;
	int num_local_vars;
	Con_Continuation* parent_continuation;
	Con_Module* module;
	} Con_Object_Func;

void Con_Func_class_bootstrap(Con_VM* vm);
Con_Value Con_Func_new(Con_VM* vm, bool is_bound, Con_PC pc, Con_PC_Type pc_type, Con_Value name, int num_local_vars, Con_Continuation* parent_continuation, Con_Module* module);
