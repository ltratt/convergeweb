#include <errno.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Memory.h"
#include "Builtins/Dict.h"
#include "Builtins/Func.h"
#include "Builtins/String.h"
#include "Builtins/List.h"
#include "Builtins/Object_Class.h"
#include "Builtins/Int.h"
#include "Modules/Exceptions.h"

#include "Set.h"



void _Con_Set_Class_new_func(Con_VM* vm);

void _Con_Set_add_func(Con_VM* vm);
void _Con_Set_to_str_func(Con_VM* vm);
void _Con_Set_contains_func(Con_VM* vm);
void _Con_Set_len_func(Con_VM* vm);
void _Con_Set_iterate_func(Con_VM* vm);
void _Con_Set_union_func(Con_VM* vm);
void _Con_Set_complement_func(Con_VM* vm);



void Con_Set_class_bootstrap(Con_VM* vm)
{
	Con_Value supers, fields, len_func, to_str_func, contains_func, add_func, iterate_func, union_func, complement_func, new_func;

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_SET_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_SET_CLASS], "name", Con_String_new_c_str(vm, "Set"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_SET_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));

	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_SET_CLASS], "supers", supers);

	new_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Set_Class_new_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "new"), 1, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_SET_CLASS], "new", new_func);

	fields = Con_Dict_new(vm);
	
	add_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Set_add_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "add"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "add"), add_func);
	
	contains_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Set_contains_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "contains"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "contains"), contains_func);

	len_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Set_len_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "len"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "len"), len_func);

	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Set_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);

	iterate_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Set_iterate_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "iterate"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "iterate"), iterate_func);

	union_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Set_union_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "union"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "union"), union_func);

	complement_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Set_complement_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "complement"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "complement"), complement_func);

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_SET_CLASS], "fields", fields);
}


////////////////////////////////////////////////////////////////////////////////////////////////////
// Functions
//


Con_Value Con_Set_new(Con_VM* vm)
{
	Con_Set_Object* set;
	Con_Value result;
	
	result.type = CON_VALUE_OBJECT;
	set = Con_malloc(vm, sizeof(Con_Set_Object), Con_MEMORY_OBJECT);
	result.datum.object = (Con_Object*) set;
	set->type = CON_OBJECT_SET;
	
	Con_Object_init(vm, (Con_Object*) set);
	
	set->items = Con_malloc(vm, CON_SET_DEFAULT_NUMBER_ITEMS_ALLOCATED * sizeof(Con_Set_Item), Con_MEMORY_NON_GC);
	set->num_items = 0;
	set->num_items_allocated = CON_SET_DEFAULT_NUMBER_ITEMS_ALLOCATED;
	
	return result;
}



void Con_Set_add(Con_VM* vm, Con_Value set, Con_Value val)
{
	Con_Set_Object* set_obj;
	Con_Value hash_val;
	int hash;
	
	if (Con_Set_contains(vm, set, val))
		return;
	
	hash_val = Con_VM_apply_c(vm, Con_Object_get_slot(vm, val, "hash"), 0);
	if (!Con_VM_is_type(vm, hash_val, "i"))
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, hash_val, "instance_of"));
	hash = hash_val.datum.integer;
	
	set_obj = (Con_Set_Object*) set.datum.object;
	if (set_obj->num_items == set_obj->num_items_allocated) {
		set_obj->items = Con_realloc(vm, set_obj->items, (set_obj->num_items_allocated + CON_SET_NUMBER_ITEMS_INCREMENT_ALLOCATION) * sizeof(Con_Set_Item));
		set_obj->num_items_allocated += CON_SET_NUMBER_ITEMS_INCREMENT_ALLOCATION;
	}
	set_obj->items[set_obj->num_items].val = val;
	set_obj->items[set_obj->num_items].hash = hash;
	set_obj->num_items += 1;
}



bool Con_Set_contains(Con_VM* vm, Con_Value set, Con_Value val)
{
	Con_Value hash_val;
	Con_Set_Object* set_obj;
	int i, hash;

	set_obj = (Con_Set_Object*) set.datum.object;

	hash_val = Con_VM_apply_c(vm, Con_Object_get_slot(vm, val, "hash"), 0);
	if (!Con_VM_is_type(vm, hash_val, "i"))
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, hash_val, "instance_of"));
	hash = hash_val.datum.integer;

	for (i = 0; i < set_obj->num_items; i += 1) {
		if (hash == set_obj->items[i].hash) {
			if (Con_VM_equals(vm, val, set_obj->items[i].val)) {
				return true;
			}
		}
	}
	
	return false;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
//

//
// new
//

void _Con_Set_Class_new_func_loop(void);
void _Con_Set_Class_new_func_exit(void);

extern Con_VM* Con_VM_execute_vm_switch;

void _Con_Set_Class_new_func(Con_VM* vm)
{
	Con_Value self, set, initializer;
	
	Con_VM_decode_args(vm, "co", &self, &initializer);
	
	set = Con_Set_new(vm);
	
	Con_VM_var_set(vm, vm->continuation, 0, 0, set);
	
	Con_VM_add_failure_frame(vm, (Con_PC) (C_Function) _Con_Set_Class_new_func_exit, PC_TYPE_C_FUNCTION);
	Con_VM_add_fail_up_frame(vm);
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, initializer, "iterate"));
	Con_VM_apply_with_return(vm, 0, _Con_Set_Class_new_func_loop, vm->continuation->pc, vm->continuation->pc_type);
}



void _Con_Set_Class_new_func_loop(void)
{
	Con_VM* vm = Con_VM_execute_vm_switch;
	Con_Value val;

	val = Con_VM_con_stack_pop_value(vm, vm->continuation);
	Con_VM_add_fail_up_frame(vm);

	Con_Set_add(vm, Con_VM_var_lookup(vm, vm->continuation, 0, 0), val);

	Con_VM_remove_failure_frame(vm);
	Con_VM_fail(vm);
}



void _Con_Set_Class_new_func_exit(void)
{
	Con_VM* vm = Con_VM_execute_vm_switch;

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_VM_var_lookup(vm, vm->continuation, 0, 0));
	Con_VM_return(vm);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Methods
//

// lookup

void _Con_Set_add_func(Con_VM* vm)
{
	Con_Value self, val;
	
	Con_VM_decode_args(vm, "So", &self, &val);

	Con_Set_add(vm, self, val);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_Set_to_str_func(Con_VM* vm)
{
	Con_Value self, str_val;
	Con_Set_Object* set;
	int i;

	Con_VM_decode_args(vm, "S", &self);
	set = (Con_Set_Object*) self.datum.object;

	str_val = Con_String_new_c_str(vm, "Set{");
	for (i = 0; i < set->num_items; i += 1) {
		if (i > 0)
			str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, ", "));
		str_val = Con_String_add(vm, str_val, Con_VM_apply_c(vm, Con_Object_get_slot(vm, set->items[i].val, "to_str"), 0));
	}
	str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, "}"));
	
	Con_VM_con_stack_push_value(vm, vm->continuation, str_val);
	Con_VM_return(vm);
}



void _Con_Set_contains_func(Con_VM* vm)
{
	Con_Value self, val;

	Con_VM_decode_args(vm, "So", &self, &val);
	
	if (Con_Set_contains(vm, self, val))
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	else	
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);

	Con_VM_return(vm);
}



void _Con_Set_len_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "S", &self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(((Con_Set_Object*) self.datum.object)->num_items));
	Con_VM_return(vm);
}



void _Con_Set_iterate_func(Con_VM* vm)
{
	Con_Value self;
	Con_Set_Object* set;
	int i;

	Con_VM_decode_args(vm, "S", &self);
	set = (Con_Set_Object*) self.datum.object;

	for (i = 0; i < set->num_items; i += 1) {
		Con_VM_con_stack_push_value(vm, vm->continuation, set->items[i].val);
		Con_VM_yield(vm);
	}
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}



void _Con_Set_union_func(Con_VM* vm)
{
	Con_Value self, other, set_union;
	Con_Set_Object* self_obj;
	Con_Set_Object* other_obj;
	int i;

	Con_VM_decode_args(vm, "SS", &self, &other);
	self_obj = (Con_Set_Object*) self.datum.object;
	other_obj = (Con_Set_Object*) other.datum.object;

	set_union = Con_Set_new(vm);
	for (i = 0; i < self_obj->num_items; i += 1) {
		Con_Set_add(vm, set_union, self_obj->items[i].val);
	}
	for (i = 0; i < other_obj->num_items; i += 1) {
		Con_Set_add(vm, set_union, other_obj->items[i].val);
	}
	
	Con_VM_con_stack_push_value(vm, vm->continuation, set_union);
	Con_VM_return(vm);
}



void _Con_Set_complement_func(Con_VM* vm)
{
	Con_Value self, other, set_complement;
	Con_Set_Object* self_obj;
	int i;

	Con_VM_decode_args(vm, "SS", &self, &other);
	self_obj = (Con_Set_Object*) self.datum.object;

	set_complement = Con_Set_new(vm);
	for (i = 0; i < self_obj->num_items; i += 1) {
		if (!Con_Set_contains(vm, other, self_obj->items[i].val))
			Con_Set_add(vm, set_complement, self_obj->items[i].val);
	}
	
	Con_VM_con_stack_push_value(vm, vm->continuation, set_complement);
	Con_VM_return(vm);
}
