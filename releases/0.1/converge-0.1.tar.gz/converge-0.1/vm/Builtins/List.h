#include "VM.h"

#define CON_INITIAL_LIST_SIZE 6
#define CON_LIST_INCREMENT_RATIO 0.2
#define CON_LIST_INCREMENT_MIN 30
#define CON_LIST_INCREMENT_MAX 8192

typedef struct {
	CON_OBJECT_HEAD
	int list_size;
	int size_allocated;
	Con_Value* items;
	} Con_List;

void Con_List_class_bootstrap(Con_VM* vm);

// Create a new Converge list initialized with num_items items

Con_Value Con_List_new(Con_VM* vm);
Con_Value Con_List_new_with_size(Con_VM* vm, int num_elements);
Con_Value Con_List_new_init_from_stack(Con_VM* vm, int num_items);

// Get list size

int Con_List_get_size(Con_VM* vm, Con_Value list_val);

// Return item at position n in list

Con_Value Con_List_get_item(Con_VM* vm, Con_Value list, int index);

// Return true if list contains 'obj'

bool Con_List_contains(Con_VM* vm, Con_Value list, Con_Value obj);

int Con_List_index(Con_VM* vm, Con_Value list, Con_Value obj);
void Con_List_append(Con_VM* vm, Con_Value list, Con_Value val);
void Con_List_insert(Con_VM* vm, Con_Value list, int pos, Con_Value val);
void Con_List_set(Con_VM* vm, Con_Value list, int index, Con_Value val);
bool Con_List_eq(Con_VM* vm, Con_Value list1, Con_Value list2);
bool Con_List_neq(Con_VM* vm, Con_Value list1, Con_Value list2);
Con_Value Con_List_slice(Con_VM* vm, Con_Value list, int lower, int upper);
Con_Value Con_List_add(Con_VM* vm, Con_Value list1, Con_Value list2);
void Con_List_del_slice(Con_VM* vm, Con_Value list, int lower, int upper);
void Con_List_extend(Con_VM* vm, Con_Value list1, Con_Value list2);
Con_Value Con_List_mul(Con_VM* vm, Con_Value list, int mul);
void Con_List_del(Con_VM* vm, Con_Value list, int index);
void Con_List_set_slice(Con_VM* vm, Con_Value list, int lower, int upper, Con_Value new_slice);
