void Con_Class_Class_bootstrap(Con_VM* vm);
