#include <ctype.h>
#include <string.h>

#include "Config.h"
#include "Converge.h"

#include "Memory.h"
#include "Object.h"
#include "List.h"
#include "String.h"
#include "Dict.h"
#include "Func.h"
#include "Null_Class.h"


void _Con_Null_Class_to_str_func(Con_VM* vm);
void _Con_Null_Class_dcopy_func(Con_VM* vm);


void Con_Null_Class_bootstrap(Con_VM* vm)
{
	Con_Value supers, fields, to_str_func, dcopy_func;

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_NULL_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_NULL_CLASS], "name", Con_String_new_c_str(vm, "Null"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_NULL_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));

	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_NULL_CLASS], "supers", supers);
	
	fields = Con_Dict_new(vm);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_NULL_CLASS], "fields", fields);
	
	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Null_Class_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);

	dcopy_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Null_Class_dcopy_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "dcopy"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "dcopy"), dcopy_func);

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_NULL_VAL], "to_str", to_str_func);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_NULL_VAL], "instance_of", vm->builtins[CON_BUILTIN_NULL_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_NULL_VAL], "dcopy", dcopy_func);
}


// Methods

void _Con_Null_Class_to_str_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "o", &self);

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, "null"));
	Con_VM_return(vm);
}




void _Con_Null_Class_dcopy_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "o", &self);

	Con_VM_con_stack_push_value(vm, vm->continuation, self);
	Con_VM_return(vm);
}
