#include <ctype.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Func.h"
#include "Memory.h"
#include "Object.h"
#include "String.h"
#include "Dict.h"
#include "List.h"



void _Con_Func_to_str_func(Con_VM* vm);


void Con_Func_class_bootstrap(Con_VM* vm)
{
	Con_Value supers, fields, to_str_func;

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_CLASS], "name", Con_String_new_c_str(vm, "Func"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));

	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_CLASS], "supers", supers);
	
	fields = Con_Dict_new(vm);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_CLASS], "fields", fields);

	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Func_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);
}



Con_Value Con_Func_new(Con_VM* vm, bool is_bound, Con_PC pc, Con_PC_Type pc_type, Con_Value name, int num_local_vars, Con_Continuation* parent_continuation, Con_Module* module)
{
	Con_Object_Func* func_obj;
	Con_Value result;

	result.type = CON_VALUE_OBJECT;
	func_obj = Con_malloc(vm, sizeof(Con_Object_Func), Con_MEMORY_OBJECT);
	result.datum.object = (Con_Object*) func_obj;
	
	Con_Object_init(vm, (Con_Object*) func_obj);
	func_obj->type = CON_OBJECT_FUNC;
	
	func_obj->is_bound = is_bound;
	func_obj->pc = pc;
	func_obj->pc_type = pc_type;
	func_obj->num_local_vars = num_local_vars;
	func_obj->parent_continuation = parent_continuation;
	func_obj->module = module;
	
	Con_Object_set_slot(vm, result, "name", name);
	
	return result;
}



void _Con_Func_to_str_func(Con_VM* vm)
{
	Con_Value self, str;

	Con_VM_decode_args(vm, "o", &self);
	
	str = Con_String_new_c_str(vm, "<Func ");
	str = Con_String_add(vm, str, Con_Object_get_slot(vm, self, "name"));
	str = Con_String_add(vm, str, Con_String_new_c_str(vm, ">"));
	
	Con_VM_con_stack_push_value(vm, vm->continuation, str);
	Con_VM_return(vm);
}
