#include <stddef.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Class_Class.h"
#include "Object_Class.h"
#include "Dict.h"
#include "Func.h"
#include "String.h"
#include "List.h"


void _Con_Class_Class_init(Con_VM* vm);
void _Con_Class_Class_to_str_func(Con_VM* vm);



void Con_Class_Class_bootstrap(Con_VM* vm)
{
	Con_Value fields, new_func, init_func, to_str_func, supers;
	
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "name", Con_String_new_c_str(vm, "Class"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "dcopy", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "fields"), Con_String_new_c_str(vm, "dcopy")));
	
	fields = Con_Dict_new(vm);
	
	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "supers", supers);
	
	new_func = Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_OBJECT_CLASS], "fields"), Con_String_new_c_str(vm, "new"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "new", new_func);
	
	init_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Class_Class_init, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "init", init_func);

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "has_slot", vm->builtins[CON_BUILTIN_DEFAULT_HAS_SLOT_FUNC]);

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "get_slot", vm->builtins[CON_BUILTIN_DEFAULT_GET_SLOT_FUNC]);
	
	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Class_Class_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "to_str", to_str_func);
	
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "new"), new_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "init"), init_func);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields", fields);
}



void _Con_Class_Class_init(Con_VM* vm)
{
	Con_Value self, name, supers, fields;

	Con_VM_decode_args(vm, "osld", &self, &name, &supers, &fields);

	Con_Object_set_slot(vm, self, "name", name);
	Con_Object_set_slot(vm, self, "supers", supers);
	Con_Object_set_slot(vm, self, "fields", fields);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);

	Con_VM_return(vm);
}



void _Con_Class_Class_to_str_func(Con_VM* vm)
{
	Con_Value self, str;

	Con_VM_decode_args(vm, "o", &self);
	
	str = Con_String_new_c_str(vm, "<Class ");
	str = Con_String_add(vm, str, Con_Object_get_slot(vm, self, "name"));
	str = Con_String_add(vm, str, Con_String_new_c_str(vm, ">"));

	Con_VM_con_stack_push_value(vm, vm->continuation, str);

	Con_VM_return(vm);
}
