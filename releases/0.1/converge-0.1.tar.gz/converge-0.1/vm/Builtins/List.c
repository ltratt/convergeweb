#include <ctype.h>
#include <string.h>

#include "Config.h"
#include "Converge.h"

#include "Memory.h"
#include "Object.h"
#include "List.h"
#include "String.h"
#include "Dict.h"
#include "Func.h"
#include "Int.h"

#include "Modules/Exceptions.h"



void _Con_List_check_room(Con_VM* vm, Con_Value list, int num_elements);

void _Con_List_iterate(Con_VM* vm);
void _Con_List_lookup_func(Con_VM* vm);
void _Con_List_contains_func(Con_VM* vm);
void _Con_List_index_func(Con_VM* vm);
void _Con_List_append_func(Con_VM* vm);
void _Con_List_len_func(Con_VM* vm);
void _Con_List_to_str_func(Con_VM* vm);
void _Con_List_set_func(Con_VM* vm);
void _Con_List_eq_func(Con_VM* vm);
void _Con_List_slice_func(Con_VM* vm);
void _Con_List_del_slice_func(Con_VM* vm);
void _Con_List_extend_func(Con_VM* vm);
void _Con_List_riterate_func(Con_VM* vm);
void _Con_List_del_func(Con_VM* vm);
void _Con_List_insert_func(Con_VM* vm);
void _Con_List_set_slice_func(Con_VM* vm);
void _Con_List_dcopy_func(Con_VM* vm);



void Con_List_class_bootstrap(Con_VM* vm)
{
	Con_Value supers, fields, iterate_func, lookup_func, len_func, to_str_func, contains_func, append_func, set_func, eq_func, slice_func, index_func, del_slice_func, extend_func, riterate_func, del_func, insert_func, set_slice_func, dcopy_func;

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_LIST_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_LIST_CLASS], "name", Con_String_new_c_str(vm, "List"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_LIST_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));

	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_LIST_CLASS], "supers", supers);
	
	fields = Con_Dict_new(vm);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_LIST_CLASS], "fields", fields);
	
	iterate_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_iterate, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "iterate"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "iterate"), iterate_func);

	lookup_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_lookup_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "lookup"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "lookup"), lookup_func);

	set_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_set_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "set"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "set"), set_func);

	contains_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_contains_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "contains"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "contains"), contains_func);

	index_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_index_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "index"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "index"), index_func);

	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);

	eq_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_eq_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "__eq__"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "__eq__"), to_str_func);

	slice_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_slice_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "slice"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "slice"), slice_func);

	append_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_append_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "append"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "append"), append_func);

	len_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_len_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "len"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "len"), len_func);

	del_slice_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_del_slice_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "del_slice"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "del_slice"), del_slice_func);

	extend_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_extend_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "extend"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "extend"), extend_func);

	riterate_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_riterate_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "riterate"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "riterate"), riterate_func);

	del_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_del_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "del"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "del"), del_func);

	insert_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_insert_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "insert"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "insert"), insert_func);

	set_slice_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_set_slice_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "set_slice"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "set_slice"), set_slice_func);

	dcopy_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_List_dcopy_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "dcopy"), 0, NULL, NULL);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "dcopy"), dcopy_func);
}



Con_Value Con_List_new_with_size(Con_VM* vm, int num_elements)
{
	Con_List* list_obj;
	Con_Value result;
	
	result.type = CON_VALUE_OBJECT;
	result.datum.object = (void*) list_obj = Con_malloc(vm, sizeof(Con_List), Con_MEMORY_OBJECT);
	Con_Object_init(vm, (Con_Object*) list_obj);
	list_obj->type = CON_OBJECT_LIST;
	
	list_obj->items = Con_malloc(vm, sizeof(Con_Value) * num_elements, Con_MEMORY_NON_GC);
	list_obj->size_allocated = num_elements;
	list_obj->list_size = 0;
	
	return result;
}



Con_Value Con_List_new(Con_VM* vm)
{
	return Con_List_new_with_size(vm, CON_INITIAL_LIST_SIZE);
}



Con_Value Con_List_new_init_from_stack(Con_VM* vm, int num_items)
{
	Con_Value list_val;
	int i;

	list_val = Con_List_new_with_size(vm, num_items);
	for (i = 0; i < num_items; i += 1) {
		Con_List_insert(vm, list_val, 0, Con_VM_con_stack_pop_value(vm, vm->continuation));
	}
	
	return list_val;
}



int Con_List_get_size(Con_VM* vm, Con_Value list_val)
{
	return ((Con_List*) list_val.datum.object)->list_size;
}



Con_Value Con_List_get_item(Con_VM* vm, Con_Value list, int index)
{
	Con_List* list_obj = (Con_List*) list.datum.object;
	
	index = Con_VM_translate_index(vm, index, list_obj->list_size);
	
	return *(list_obj->items + index);
}



void Con_List_append(Con_VM* vm, Con_Value list, Con_Value val)
{
	Con_List* list_obj = (Con_List*) list.datum.object;

	_Con_List_check_room(vm, list, 1);
	list_obj->items[list_obj->list_size++] = val;
}



void Con_List_insert(Con_VM* vm, Con_Value list, int pos, Con_Value val)
{
	Con_List* list_obj = (Con_List*) list.datum.object;

	pos = Con_VM_translate_slice_index(vm, pos, list_obj->list_size);

	_Con_List_check_room(vm, list, 1);
	if (pos < list_obj->list_size)
		memmove(&list_obj->items[pos + 1], &list_obj->items[pos], (list_obj->list_size - pos) * sizeof(Con_Value));
	list_obj->items[pos] = val;
	
	list_obj->list_size += 1;
}



bool Con_List_contains(Con_VM* vm, Con_Value list, Con_Value obj)
{
	int i;
	
	for (i = 0; i < Con_List_get_size(vm, list); i += 1) {
		if (Con_VM_equals(vm, Con_List_get_item(vm, list, i), obj))
			return true;
	}
	
	return false;
}



int Con_List_index(Con_VM* vm, Con_Value list, Con_Value obj)
{
	int i;
	
	for (i = 0; i < Con_List_get_size(vm, list); i += 1) {
		if (Con_VM_equals(vm, Con_List_get_item(vm, list, i), obj))
			return i;
	}
	
	return -1;
}



void Con_List_set(Con_VM* vm, Con_Value list, int index, Con_Value val)
{
	Con_List* list_obj = (Con_List*) list.datum.object;

	index = Con_VM_translate_index(vm, index, list_obj->list_size);
	list_obj->items[index] = val;
}



bool Con_List_eq(Con_VM* vm, Con_Value list1, Con_Value list2)
{
	Con_List* list1_obj;
	Con_List* list2_obj;
	int i;
	
	Con_VM_ensure_type(vm, list1, "l", "Must be list1");
	
	if (!Con_VM_is_type(vm, list2, "l"))
		return false;

	if (Con_VM_is(vm, list1, list2))
		return true;

	list1_obj = (Con_List*) list1.datum.object;
	list2_obj = (Con_List*) list2.datum.object;
	
	if (list1_obj->list_size != list2_obj->list_size)
		return false;

	for (i = 0; i < Con_List_get_size(vm, list1); i += 1) {
		if (!Con_VM_equals(vm, Con_List_get_item(vm, list1, i), Con_List_get_item(vm, list2, i)))
			return false;
	}
	
	return true;
}



bool Con_List_neq(Con_VM* vm, Con_Value list1, Con_Value list2)
{
	Con_List* list1_obj;
	Con_List* list2_obj;
	int i;
	
	Con_VM_ensure_type(vm, list1, "l", "Must be list2");
	
	if (!Con_VM_is_type(vm, list2, "l"))
		return true;

	if (Con_VM_is(vm, list1, list2))
		return false;

	list1_obj = (Con_List*) list1.datum.object;
	list2_obj = (Con_List*) list2.datum.object;
	
	if (list1_obj->list_size != list2_obj->list_size)
		return true;

	for (i = 0; i < Con_List_get_size(vm, list1); i += 1) {
		if (!Con_VM_equals(vm, Con_List_get_item(vm, list1, i), Con_List_get_item(vm, list2, i)))
			return true;
	}
	
	return false;
}



Con_Value Con_List_slice(Con_VM* vm, Con_Value list, int lower, int upper)
{
	Con_Value new_list;
	Con_List* list_obj;
	Con_List* new_list_obj;

	lower = Con_VM_translate_slice_index(vm, lower, Con_List_get_size(vm, list));
	upper = Con_VM_translate_slice_index(vm, upper, Con_List_get_size(vm, list));

	new_list = Con_List_new_with_size(vm, upper - lower);
	
	list_obj = (Con_List*) list.datum.object;
	new_list_obj = (Con_List*) new_list.datum.object;

	memmove(new_list_obj->items, list_obj->items + lower, (upper - lower) * sizeof(Con_Value));
	new_list_obj->list_size = upper - lower;

	return new_list;
}



Con_Value Con_List_add(Con_VM* vm, Con_Value list1, Con_Value list2)
{
	Con_Value new_list;
	Con_List* list1_obj;
	Con_List* list2_obj;
	Con_List* new_list_obj;

	if (!Con_VM_is_type(vm, list1, "l"))
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_LIST_CLASS], Con_Object_get_slot(vm, list1, "instance_of"));


	if (!Con_VM_is_type(vm, list2, "l"))
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_LIST_CLASS], Con_Object_get_slot(vm, list2, "instance_of"));

	list1_obj = (Con_List*) list1.datum.object;
	list2_obj = (Con_List*) list2.datum.object;
	new_list = Con_List_new_with_size(vm, list1_obj->list_size + list2_obj->list_size);
	new_list_obj = (Con_List*) new_list.datum.object;

	memmove(new_list_obj->items, list1_obj->items, list1_obj->list_size * sizeof(Con_Value));
	memmove(new_list_obj->items + list1_obj->list_size, list2_obj->items, list2_obj->list_size * sizeof(Con_Value));
	new_list_obj->list_size = list1_obj->list_size + list2_obj->list_size;

	return new_list;
}



void Con_List_del_slice(Con_VM* vm, Con_Value list, int lower, int upper)
{
	Con_List* list_obj;
	
	Con_VM_ensure_type(vm, list, "l", "Must be list4");
	list_obj = (Con_List*) list.datum.object;

	lower = Con_VM_translate_slice_index(vm, lower, Con_List_get_size(vm, list));
	upper = Con_VM_translate_slice_index(vm, upper, Con_List_get_size(vm, list));

	memmove(list_obj->items + lower, list_obj->items + upper, (list_obj->list_size - upper) * sizeof(Con_Value));
	list_obj->list_size -= (upper - lower);
}



void Con_List_extend(Con_VM* vm, Con_Value list1, Con_Value list2)
{
	Con_List* list1_obj;
	Con_List* list2_obj;

	Con_VM_ensure_type(vm, list1, "l", "Must be list5");
	
	list1_obj = (Con_List*) list1.datum.object;
	list2_obj = (Con_List*) list2.datum.object;
	
	_Con_List_check_room(vm, list1, list2_obj->list_size);
	memmove(list1_obj->items + list1_obj->list_size, list2_obj->items, list2_obj->list_size * sizeof(Con_Value));
	list1_obj->list_size += list2_obj->list_size;
}



Con_Value Con_List_mul(Con_VM* vm, Con_Value list, int mul)
{
	Con_Value new_list;
	int i;

	new_list = Con_List_new_with_size(vm, Con_List_get_size(vm, list) * mul);
	
	for (i = 0; i < mul; i += 1) {
		Con_List_extend(vm, new_list, list);
	}
	
	return new_list;
}



void Con_List_del(Con_VM* vm, Con_Value list, int index)
{
	index = Con_VM_translate_slice_index(vm, index, Con_List_get_size(vm, list));
	Con_List_del_slice(vm, list, index, index + 1);
}



void Con_List_set_slice(Con_VM* vm, Con_Value list, int lower, int upper, Con_Value new_slice)
{
	Con_List* list_obj;
	Con_List* new_slice_obj;

	Con_VM_ensure_type(vm, list, "l", "Must be list");
	list_obj = (Con_List*) list.datum.object;

	lower = Con_VM_translate_slice_index(vm, lower, list_obj->list_size);
	upper = Con_VM_translate_slice_index(vm, upper, list_obj->list_size);
	
	if (new_slice.type == CON_VALUE_OBJECT && new_slice.datum.object->type == CON_OBJECT_LIST) {
		new_slice_obj = (Con_List*) new_slice.datum.object;
		if (new_slice_obj->list_size > (upper - lower))
			_Con_List_check_room(vm, list, new_slice_obj->list_size - (upper - lower));
		printf("in\n");
		memmove(list_obj->items + lower + new_slice_obj->list_size, list_obj->items + upper, (list_obj->list_size - upper) * sizeof(Con_Value));
		memmove(list_obj->items + lower, new_slice_obj->items, new_slice_obj->list_size * sizeof(Con_Value));
		printf("out\n");
		list_obj->list_size = list_obj->list_size + (new_slice_obj->list_size - (upper - lower));
	}
	else
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_LIST_CLASS], Con_Object_get_slot(vm, new_slice, "instance_of"));
}



void _Con_List_check_room(Con_VM* vm, Con_Value list, int num_elements)
{
	Con_List* list_obj;
	int new_size;
	
	list_obj = (Con_List*) list.datum.object;

	if (list_obj->list_size + num_elements <= list_obj->size_allocated)
		return;

	new_size = list_obj->size_allocated + (CON_LIST_INCREMENT_RATIO * list_obj->size_allocated);
	if (new_size < list_obj->size_allocated + CON_LIST_INCREMENT_MIN)
		new_size = list_obj->size_allocated + CON_LIST_INCREMENT_MIN;
	if (new_size < list_obj->size_allocated + num_elements)
		new_size = list_obj->size_allocated + num_elements;
	list_obj->items = Con_realloc(vm, list_obj->items, new_size * sizeof(Con_List));
	list_obj->size_allocated = new_size;
}



////////////////////////////////////////////////////////////////////////////////////////////////////
// Methods
//

void _Con_List_iterate(Con_VM* vm)
{
	Con_Value self;
	int i;

	Con_VM_decode_args(vm, "o", &self);

	for (i = 0; i < Con_List_get_size(vm, self); i += 1) {
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_get_item(vm, self, i));
		Con_VM_yield(vm);
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}



void _Con_List_lookup_func(Con_VM* vm)
{
	Con_Value self, lookup_val;
	int index;

	Con_VM_decode_args(vm, "oi", &self, &lookup_val);
	index = lookup_val.datum.integer;
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_get_item(vm, self, index));
	Con_VM_return(vm);
}



void _Con_List_len_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "o", &self);

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(Con_List_get_size(vm, self)));
	Con_VM_return(vm);
}



void _Con_List_to_str_func(Con_VM* vm)
{
	Con_Value self, str_val;
	int i;

	Con_VM_decode_args(vm, "o", &self);

	str_val = Con_String_new_c_str(vm, "[");
	for (i = 0; i < Con_List_get_size(vm, self); i += 1) {
		if (i > 0)
			str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, ", "));
		str_val = Con_String_add(vm, str_val, Con_VM_apply_c(vm, Con_Object_get_slot(vm, Con_List_get_item(vm, self, i), "to_str"), 0));
	}
	str_val = Con_String_add(vm, str_val, Con_String_new_c_str(vm, "]"));
	
	Con_VM_con_stack_push_value(vm, vm->continuation, str_val);
	Con_VM_return(vm);
}



void _Con_List_contains_func(Con_VM* vm)
{
	Con_Value self, contains_val;

	Con_VM_decode_args(vm, "oo", &self, &contains_val);
	
	if (Con_List_contains(vm, self, contains_val))
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	else
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}



void _Con_List_index_func(Con_VM* vm)
{
	Con_Value self, val;
	int index;

	Con_VM_decode_args(vm, "oo", &self, &val);
	
	index = Con_List_index(vm, self, val);
	if (index == -1)
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	else
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(index));
	Con_VM_return(vm);
}



void _Con_List_append_func(Con_VM* vm)
{
	Con_Value self, val;

	Con_VM_decode_args(vm, "oo", &self, &val);
	
	Con_List_append(vm, self, val);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}




void _Con_List_set_func(Con_VM* vm)
{
	Con_Value self, index_val, val;

	Con_VM_decode_args(vm, "oio", &self, &index_val, &val);
	
	Con_List_set(vm, self, index_val.datum.integer, val);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}




void _Con_List_eq_func(Con_VM* vm)
{
	Con_Value self, obj;

	Con_VM_decode_args(vm, "oo", &self, &obj);
	
	if (Con_List_eq(vm, self, obj))
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	else
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}



void _Con_List_slice_func(Con_VM* vm)
{
	Con_Value self, lower_val, upper_val;
	int lower, upper;

	Con_VM_decode_args(vm, "l;oo", &self, &lower_val, &upper_val);
	
	if (Con_VM_is(vm, lower_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		lower = 0;
	else {
		if (!Con_VM_is_type(vm, lower_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, lower_val, "instance_of"));
		lower = lower_val.datum.integer;
	}
	lower = Con_VM_translate_slice_index(vm, lower, Con_List_get_size(vm, self));

	if (Con_VM_is(vm, upper_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		upper = Con_List_get_size(vm, self);
	else {
		if (!Con_VM_is_type(vm, upper_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, upper_val, "instance_of"));
		upper = upper_val.datum.integer;
	}
	upper = Con_VM_translate_slice_index(vm, upper, Con_List_get_size(vm, self));
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_slice(vm, self, lower, upper));
	Con_VM_return(vm);
}



void _Con_List_del_slice_func(Con_VM* vm)
{
	Con_Value self, lower_val, upper_val;
	int lower, upper;

	Con_VM_decode_args(vm, "l;oo", &self, &lower_val, &upper_val);
	
	if (Con_VM_is(vm, lower_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		lower = 0;
	else {
		if (!Con_VM_is_type(vm, lower_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, lower_val, "instance_of"));
		lower = lower_val.datum.integer;
	}
	lower = Con_VM_translate_slice_index(vm, lower, Con_List_get_size(vm, self));

	if (Con_VM_is(vm, upper_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		upper = Con_List_get_size(vm, self);
	else {
		if (!Con_VM_is_type(vm, upper_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, upper_val, "instance_of"));
		upper = upper_val.datum.integer;
	}
	upper = Con_VM_translate_slice_index(vm, upper, Con_List_get_size(vm, self));
	
	Con_List_del_slice(vm, self, lower, upper);
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_List_extend_func(Con_VM* vm)
{
	Con_Value self, val;

	Con_VM_decode_args(vm, "ll", &self, &val);
	
	Con_List_extend(vm, self, val);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_List_riterate_func(Con_VM* vm)
{
	Con_Value self;
	int i;

	Con_VM_decode_args(vm, "l", &self);

	for (i = Con_List_get_size(vm, self) - 1; i >= 0; i -= 1) {
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_get_item(vm, self, i));
		Con_VM_yield(vm);
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}



void _Con_List_del_func(Con_VM* vm)
{
	Con_Value self, index_val;

	Con_VM_decode_args(vm, "oi", &self, &index_val);
	
	Con_List_del(vm, self, index_val.datum.integer);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_List_insert_func(Con_VM* vm)
{
	Con_Value self, index_val, val;

	Con_VM_decode_args(vm, "oio", &self, &index_val, &val);
	
	Con_List_insert(vm, self, index_val.datum.integer, val);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_List_set_slice_func(Con_VM* vm)
{
	Con_Value self, lower_val, upper_val, new_slice;
	int lower, upper;

	Con_VM_decode_args(vm, "looo", &self, &lower_val, &upper_val, &new_slice);
	
	if (Con_VM_is(vm, lower_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		lower = 0;
	else {
		if (!Con_VM_is_type(vm, lower_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, lower_val, "instance_of"));
		lower = lower_val.datum.integer;
	}

	if (Con_VM_is(vm, upper_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		upper = Con_List_get_size(vm, self);
	else {
		if (!Con_VM_is_type(vm, upper_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, upper_val, "instance_of"));
		upper = upper_val.datum.integer;
	}
	
	Con_List_set_slice(vm, self, lower, upper, new_slice);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_List_dcopy_func(Con_VM* vm)
{
	Con_Value self, new_list;
	int i;

	Con_VM_decode_args(vm, "l", &self);
	
	new_list = Con_List_new_with_size(vm, Con_List_get_size(vm, self));
	for (i = 0; i < Con_List_get_size(vm, self); i += 1) {
		Con_List_append(vm, new_list, Con_VM_apply_c(vm, Con_Object_get_slot(vm, Con_List_get_item(vm, self, i), "dcopy"), 0));
	}
	
	Con_VM_con_stack_push_value(vm, vm->continuation, new_list);
	Con_VM_return(vm);
}
