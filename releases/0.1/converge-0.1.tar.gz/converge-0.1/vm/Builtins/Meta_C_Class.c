#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Memory.h"

#include "Meta_C_Class.h"
#include "List.h"
#include "Dict.h"
#include "String.h"
#include "Func.h"
#include "Object_Class.h"


void _Con_Meta_C_Class__Meta_C_Class_new_func(Con_VM* vm);
void _Con_Meta_C_Class__Meta_C_Class_new_func_finish(Con_VM* vm);


void Con_Meta_C_Class_bootstrap(Con_VM* vm)
{
	Con_Value meta_c_class_supers, meta_c_class_fields, meta_c_class_new_func;

	//
	// class Meta_C_Class
	//
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	// Name
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, "Meta_C_Class"));
	// Supers
	meta_c_class_supers = Con_List_new(vm);
	Con_List_append(vm, meta_c_class_supers, vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_VM_con_stack_push_value(vm, vm->continuation, meta_c_class_supers);
	// Fields
	meta_c_class_fields = Con_Dict_new(vm);
	// new
	meta_c_class_new_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Meta_C_Class__Meta_C_Class_new_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "new"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, meta_c_class_fields, Con_String_new_c_str(vm, "new"), meta_c_class_new_func);
	// Push fields
	Con_VM_con_stack_push_value(vm, vm->continuation, meta_c_class_fields);
	Con_VM_apply(vm, 3);

	vm->builtins[CON_BUILTIN_META_C_CLASS] = Con_VM_con_stack_pop_value(vm, vm->continuation);
}



Con_Value Con_Meta_C_Class_new(Con_VM* vm, Con_Value name, Con_Value supers, Con_Value fields, size_t obj_size)
{
	Con_Meta_C_Class_Obj* new_class_obj;
	Con_Value new_class;

	new_class_obj = Con_malloc(vm, sizeof(Con_Meta_C_Class_Obj), Con_MEMORY_OBJECT);
	new_class_obj->type = CON_OBJECT_META_C_CLASS;
	new_class_obj->obj_size = obj_size;
	Con_Object_init(vm, (Con_Object*) new_class_obj);
	
	new_class.type = CON_VALUE_OBJECT;
	new_class.datum.object = (Con_Object*) new_class_obj;
	
	Con_Object_set_slot(vm, new_class, "instance_of", vm->builtins[CON_BUILTIN_META_C_CLASS]);
	Con_Object_Class_new_populate(vm, new_class, vm->builtins[CON_BUILTIN_META_C_CLASS]);
	
	Con_VM_apply_c(vm, Con_Object_get_slot(vm, new_class, "init"), 3, name, supers, fields);
	
	return new_class;
}



////////////////////////////////////////////////////////////////////////////////////////////////////
// class Meta_C_Class
//

//
// new
//

void _Con_Meta_C_Class__Meta_C_Class_new_func(Con_VM* vm)
{
	Con_Value self, var_args, new_obj;
	int i;
	Con_Meta_C_Class_Obj* self_obj;
	Con_Object* obj;

	Con_VM_decode_args(vm, "ov", &self, &var_args);
	self_obj = (Con_Meta_C_Class_Obj*) self.datum.object;
	
	new_obj.type = CON_VALUE_OBJECT;
	obj = Con_malloc(vm, self_obj->obj_size, Con_MEMORY_OBJECT);
	new_obj.datum.object = (Con_Object*) obj;
	new_obj.datum.object->type = CON_NORMAL_OBJECT;
	Con_Object_init(vm, (Con_Object*) obj);

	Con_Object_set_slot(vm, new_obj, "instance_of", self);
	
	Con_Object_Class_new_populate(vm, new_obj, self);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, new_obj);
	Con_VM_add_failure_frame(vm, (Con_PC) (C_Function) _Con_Meta_C_Class__Meta_C_Class_new_func_finish, PC_TYPE_C_FUNCTION);
	Con_VM_con_stack_push_value(vm, vm->continuation, new_obj);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, new_obj, "init"));
	for (i = 0; i < Con_List_get_size(vm, var_args); i += 1) {
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_get_item(vm, var_args, i));
	}
	
	Con_VM_apply(vm, Con_List_get_size(vm, var_args));
	Con_VM_remove_failure_frame(vm);

	Con_VM_return(vm);
}



void _Con_Meta_C_Class__Meta_C_Class_new_func_finish(Con_VM* vm)
{
	Con_VM_return(vm);
}
