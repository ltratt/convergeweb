void Con_Object_Class_bootstrap(Con_VM* vm);
void Con_Object_Class_new_populate(Con_VM* vm, Con_Value obj, Con_Value class);
