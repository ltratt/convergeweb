// Internals

typedef struct {
	CON_OBJECT_HEAD
	int str_size;
	Con_Hash hash;
	char str[0];
	} Con_String_Object;

void Con_String_class_bootstrap(Con_VM* vm);

Con_Hash Con_String_hash(const char *str, int size);

Con_Value Con_String_new_blank(Con_VM* vm, int str_size);

// Create a new Converge string from a non-null terminated character buffer 'str'

Con_Value Con_String_new(Con_VM* vm, const char* str, int str_size);

// Create a new Converge string from a null terminated C string 'str'

Con_Value Con_String_new_c_str(Con_VM* vm, const char* str);

// Return the non-null terminated string buffer housed by the Converge string

char* Con_String_get_str(Con_VM* vm, Con_Value str_val);

// Return the size of a Converge string

int Con_String_get_size(Con_VM* vm, Con_Value str_val);

// Return a string slice

Con_Value Con_String_slice(Con_VM* vm, Con_Value str, int lower, int upper);

bool Con_String_equals(Con_VM* vm, Con_Value val1, Con_Value val2);
bool Con_String_not_equals(Con_VM* vm, Con_Value val1, Con_Value val2);
bool Con_String_greater_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2);
bool Con_String_less_than_equals(Con_VM* vm, Con_Value val1, Con_Value val2);
Con_Value Con_String_add(Con_VM* vm, Con_Value str1, Con_Value str2);
Con_Value Con_String_mul(Con_VM* vm, Con_Value str, int mul);
Con_Value Con_String_upper_case(Con_VM* vm, Con_Value str);
Con_Value Con_String_lower_case(Con_VM* vm, Con_Value str);
