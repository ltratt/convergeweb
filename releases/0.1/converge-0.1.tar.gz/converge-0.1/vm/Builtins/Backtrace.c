#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Memory.h"
#include "Backtrace.h"
#include "Module.h"
#include "Object.h"
#include "Builtins/String.h"


void Con_Backtrace_Class_bootstrap(Con_VM* vm)
{
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_BACKTRACE_CLASS], "instance_of", vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_BACKTRACE_CLASS], "name", Con_String_new_c_str(vm, "Backtrace"));
}



Con_Value Con_Backtrace_new(Con_VM* vm, Con_Value module, Con_Value func, Con_PC pc, Con_PC_Type pc_type)
{
	Con_Backtrace_Obj* backtrace_obj;
	Con_Value result;

	result.type = CON_VALUE_OBJECT;
	backtrace_obj = Con_malloc(vm, sizeof(Con_Backtrace_Obj), Con_MEMORY_OBJECT);
	backtrace_obj->pc = pc;
	backtrace_obj->pc_type = pc_type;
	result.datum.object = (Con_Object*) backtrace_obj;
	result.datum.object->type = CON_OBJECT_BACKTRACE;
	
	Con_Object_init(vm, (Con_Object*) backtrace_obj);
	Con_Object_set_slot(vm, result, "module", module);
	Con_Object_set_slot(vm, result, "func", func);
	
	Con_Object_set_slot(vm, result, "instance_of", vm->builtins[CON_BUILTIN_BACKTRACE_CLASS]);
	
	return result;
}
