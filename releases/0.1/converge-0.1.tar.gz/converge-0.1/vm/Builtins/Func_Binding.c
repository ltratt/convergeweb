#include <ctype.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Func.h"
#include "Func_Binding.h"
#include "Memory.h"
#include "Object.h"
#include "String.h"
#include "Dict.h"
#include "List.h"



void _Con_Func_Binding_Class_new_func(Con_VM* vm);



void Con_Func_Binding_class_bootstrap(Con_VM* vm)
{
	Con_Value supers, fields, new_func;

	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_BINDING_CLASS], "instance_of", vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_BINDING_CLASS], "name", Con_String_new_c_str(vm, "Func_Binding"));
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_BINDING_CLASS], "to_str", Con_Dict_lookup(vm, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_CLASS_CLASS], "fields"), Con_String_new_c_str(vm, "to_str")));

	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_BINDING_CLASS], "supers", supers);
	
	fields = Con_Dict_new(vm);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_BINDING_CLASS], "fields", fields);

	new_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Func_Binding_Class_new_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "new"), 1, NULL, NULL);
	Con_Object_set_slot(vm, vm->builtins[CON_BUILTIN_FUNC_BINDING_CLASS], "new", new_func);	
}



void _Con_Func_Binding_Class_new_func(Con_VM* vm)
{
	Con_Value self, obj, func;

	Con_VM_decode_args(vm, "ooo", &self, &obj, &func);

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Func_Binding_new(vm, obj, func));

	Con_VM_return(vm);
}



Con_Value Con_Func_Binding_new(Con_VM* vm, Con_Value self_obj, Con_Value func)
{
	Con_Object_Func_Binding* func_binding_obj;
	Con_Value result;
	
	result.type = CON_VALUE_OBJECT;
	
	func_binding_obj = Con_malloc(vm, sizeof(Con_Object_Func_Binding), Con_MEMORY_OBJECT);
	
	result.datum.object = (Con_Object*) func_binding_obj;
	
	Con_Object_init(vm, (Con_Object*) func_binding_obj);
	func_binding_obj->type = CON_OBJECT_FUNC_BINDING;
	
//	Con_Object_set_slot(vm, result, "instance_of", vm->builtins[CON_BUILTIN_FUNC_BINDING_CLASS]);
	
	func_binding_obj->self_obj = self_obj;
	func_binding_obj->func = func;
	
	return result;
}
