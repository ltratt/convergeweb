#include <stdbool.h>

#define NAME "Converge"
#define VERSION "0.1"
#define DATE "2004/08/03"
#define COPYRIGHT "Copyright (C)King's College London 2003-2004, Created by Laurence Tratt"

#define XXX do { printf("XXX exit line %d %s\n", __LINE__, __FILE__); exit(1); } while (0);
#define CON_FATAL_ERROR(x) do { printf("Fatal error line %d file %s:\n  %s.\n", __LINE__, __FILE__, x); exit(1); } while (1)
#define CON_FATAL_ERROR_OVERFLOW CON_FATAL_ERROR("Buffer overflow.");

typedef long Con_Hash;
