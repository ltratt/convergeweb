void Con_Mod_Sys_init(Con_VM* vm);
