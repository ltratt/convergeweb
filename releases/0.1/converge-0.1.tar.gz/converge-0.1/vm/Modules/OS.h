void Con_Mod_OS_init(Con_VM* vm);
