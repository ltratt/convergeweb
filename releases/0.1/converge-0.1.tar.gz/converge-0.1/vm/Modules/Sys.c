#include <stddef.h>
#include <stdio.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Builtins/Func.h"
#include "Builtins/String.h"
#include "Builtins/List.h"

#include "Sys.h"



void Con_Mod_Sys_print_func(Con_VM* vm);
void Con_Mod_Sys_println_func(Con_VM* vm);
void Con_Mod_Sys_exit_func(Con_VM* vm);


void Con_Mod_Sys_init(Con_VM* vm)
{
	Con_Value print_func, println_func, argv_val, exit_func;
	int i;

	if (vm->program_path == NULL)
		Con_Object_set_slot(vm, vm->continuation->module->module_val, "program_path", vm->builtins[CON_BUILTIN_NULL_VAL]);
	else
		Con_Object_set_slot(vm, vm->continuation->module->module_val, "program_path", Con_String_new_c_str(vm, vm->program_path));

	print_func = Con_Func_new(vm, false, (Con_PC) (C_Function) Con_Mod_Sys_print_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "print"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "print", print_func);

	println_func = Con_Func_new(vm, false, (Con_PC) (C_Function) Con_Mod_Sys_println_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "println"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "println", println_func);

	exit_func = Con_Func_new(vm, false, (Con_PC) (C_Function) Con_Mod_Sys_exit_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "exit"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "exit", exit_func);
	
	argv_val = Con_List_new(vm);
	for (i = 0; i < vm->argc; i += 1) {
		Con_List_append(vm, argv_val, Con_String_new_c_str(vm, vm->argv[i]));
	}
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "argv", argv_val);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void Con_Mod_Sys_print_func(Con_VM* vm)
{
	Con_Value var_args, item, str;
	Con_String_Object* str_obj;
	int i, j;

	Con_VM_decode_args(vm, "v", &var_args);

	for (i = 0; i < Con_List_get_size(vm, var_args); i += 1) {
		item = Con_List_get_item(vm, var_args, i);
		if (Con_VM_instance_of(vm, item, vm->builtins[CON_BUILTIN_STRING_CLASS]))
			str_obj = (Con_String_Object*) item.datum.object;
		else {
			Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, item, "to_str"));
			Con_VM_apply(vm, 0);
			str = Con_VM_con_stack_pop_value(vm, vm->continuation);
			Con_VM_ensure_type(vm, str, "s", "to_str expected to return a string");
			str_obj = (Con_String_Object*) str.datum.object;
		}
		for (j = 0; j < str_obj->str_size; j += 1) {
			switch (str_obj->str[j]) {
				case 0:
					printf("\\0");
					break;
				default:
					printf("%c", str_obj->str[j]);
					break;
			}
		}
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void Con_Mod_Sys_println_func(Con_VM* vm)
{
	Con_Value var_args;
	int i;

	Con_VM_decode_args(vm, "v", &var_args);

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, vm->continuation->module->module_val, "print"));
for (i = 0; i < Con_List_get_size(vm, var_args); i += 1) {
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_get_item(vm, var_args, i));
	}
	Con_VM_apply(vm, Con_List_get_size(vm, var_args));
	printf("\n");
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void Con_Mod_Sys_exit_func(Con_VM* vm)
{
	Con_Value status;

	Con_VM_decode_args(vm, "i", &status);

	exit(status.datum.integer);
}
