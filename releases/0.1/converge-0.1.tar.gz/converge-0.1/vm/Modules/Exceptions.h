void Con_Mod_Exceptions_init(Con_VM* vm);
void Con_Mod_Exceptions_quick(Con_VM* vm, const char* exception_name, int num_args, ...);
