#include <ctype.h>
#include <string.h>
#include <stdarg.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Exceptions.h"
#include "Object.h"
#include "Builtins/String.h"
#include "Builtins/List.h"
#include "Builtins/Dict.h"
#include "Builtins/Func.h"
#include "Builtins/Int.h"



void _Con_Mod_Exceptions_new(Con_VM* vm, const char* name, const char* parent, Con_Value fields);

void _Con_Mod_Exceptions_init_func(Con_VM* vm);
void _Con_Mod_Exceptions_to_str_func(Con_VM* vm);

void _Con_Mod_Exceptions_Type_Exception_init_func(Con_VM* vm);
void _Con_Mod_Exceptions_Slot_Exception_init_func(Con_VM* vm);
void _Con_Mod_Exceptions_Bounds_Exception_init_func(Con_VM* vm);
void _Con_Mod_Exceptions_Key_Exception_init_func(Con_VM* vm);
void _Con_Mod_Exceptions_Unhashable_Exception_init_func(Con_VM* vm);
void _Con_Mod_Exceptions_Apply_Exception_init_func(Con_VM* vm);



void Con_Mod_Exceptions_init(Con_VM* vm)
{
	Con_Value supers, fields, init_func, to_str_func, exception_fields, exception_init;
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	// Name
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, "Exception"));
	// Supers
	supers = Con_List_new(vm);
	Con_List_append(vm, supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_VM_con_stack_push_value(vm, vm->continuation, supers);
	// Fields
	fields = Con_Dict_new(vm);
	// init
	init_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Exceptions_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "init"), init_func);
	// to_str
	to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Exceptions_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, fields, Con_String_new_c_str(vm, "to_str"), to_str_func);
	// Push fields
	Con_VM_con_stack_push_value(vm, vm->continuation, fields);
	Con_VM_apply(vm, 3);
	
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "Exception", Con_VM_con_stack_pop_value(vm, vm->continuation));
	
	_Con_Mod_Exceptions_new(vm, "Internal_Exception", "Exception", Con_Dict_new(vm));
	_Con_Mod_Exceptions_new(vm, "Parameters_Exception", "Exception", Con_Dict_new(vm));
	
	// Type_Exception
	
	exception_fields = Con_Dict_new(vm);
	exception_init = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Exceptions_Type_Exception_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, exception_fields, Con_String_new_c_str(vm, "init"), exception_init);
	_Con_Mod_Exceptions_new(vm, "Type_Exception", "Exception", exception_fields);
	
	// Slot_Exception

	exception_fields = Con_Dict_new(vm);
	exception_init = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Exceptions_Slot_Exception_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, exception_fields, Con_String_new_c_str(vm, "init"), exception_init);
	_Con_Mod_Exceptions_new(vm, "Slot_Exception", "Exception", exception_fields);

	// Bounds_Exception

	exception_fields = Con_Dict_new(vm);
	exception_init = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Exceptions_Bounds_Exception_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, exception_fields, Con_String_new_c_str(vm, "init"), exception_init);
	_Con_Mod_Exceptions_new(vm, "Bounds_Exception", "Exception", exception_fields);

	// Key_Exception

	exception_fields = Con_Dict_new(vm);
	exception_init = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Exceptions_Key_Exception_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, exception_fields, Con_String_new_c_str(vm, "init"), exception_init);
	_Con_Mod_Exceptions_new(vm, "Key_Exception", "Exception", exception_fields);

	// Unhashable_Exception

	exception_fields = Con_Dict_new(vm);
	exception_init = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Exceptions_Unhashable_Exception_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, exception_fields, Con_String_new_c_str(vm, "init"), exception_init);
	_Con_Mod_Exceptions_new(vm, "Unhashable_Exception", "Exception", exception_fields);

	// Apply_Exception

	exception_fields = Con_Dict_new(vm);
	exception_init = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Exceptions_Apply_Exception_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, exception_fields, Con_String_new_c_str(vm, "init"), exception_init);
	_Con_Mod_Exceptions_new(vm, "Apply_Exception", "Exception", exception_fields);

	// Misc
	
	_Con_Mod_Exceptions_new(vm, "Not_Implemented_Exception", "Exception", Con_Dict_new(vm));
	_Con_Mod_Exceptions_new(vm, "Import_Exception", "Exception", Con_Dict_new(vm));
	_Con_Mod_Exceptions_new(vm, "Unpack_Exception", "Exception", Con_Dict_new(vm));
	_Con_Mod_Exceptions_new(vm, "VM_Exception", "Exception", Con_Dict_new(vm));
	
	_Con_Mod_Exceptions_new(vm, "IO_Exception", "Exception", Con_Dict_new(vm));
	_Con_Mod_Exceptions_new(vm, "File_Exception", "IO_Exception", Con_Dict_new(vm));
	_Con_Mod_Exceptions_new(vm, "Unassigned_Var_Exception", "IO_Exception", Con_Dict_new(vm));
	_Con_Mod_Exceptions_new(vm, "Exception_Exception", "IO_Exception", Con_Dict_new(vm));
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);

	Con_VM_return(vm);
}



void _Con_Mod_Exceptions_new(Con_VM* vm, const char* name, const char* parent_name, Con_Value fields)
{
	Con_Value parents, exception_class;
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, name));
	parents = Con_List_new(vm);
	Con_List_append(vm, parents, Con_Object_get_slot(vm, vm->continuation->module->module_val, parent_name));
	Con_VM_con_stack_push_value(vm, vm->continuation, parents);
	Con_VM_con_stack_push_value(vm, vm->continuation, fields);
	Con_VM_apply(vm, 3);
	exception_class = Con_VM_con_stack_pop_value(vm, vm->continuation);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, name, exception_class);
	Con_Object_set_slot(vm, exception_class, "container", vm->continuation->module->module_val);
}



void _Con_Mod_Exceptions_init_func(Con_VM* vm)
{
	Con_Value self, msg;

	Con_VM_decode_args(vm, "o;s", &self, &msg);
	
	if (Con_VM_is(vm, msg, vm->builtins[CON_BUILTIN_NULL_VAL]))
		Con_Object_set_slot(vm, self, "msg", Con_String_new_c_str(vm, ""));
	else
		Con_Object_set_slot(vm, self, "msg", msg);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);	
}



void _Con_Mod_Exceptions_to_str_func(Con_VM* vm)
{
	Con_Value self, str;

	Con_VM_decode_args(vm, "o", &self);
	
	str = Con_String_add(vm, Con_Object_get_slot(vm, Con_Object_get_slot(vm, self, "instance_of"), "name"), Con_String_new_c_str(vm, ": "));
	str = Con_String_add(vm, str, Con_Object_get_slot(vm, self, "msg"));

	Con_VM_con_stack_push_value(vm, vm->continuation, str);
	Con_VM_return(vm);	
}



void _Con_Mod_Exceptions_Type_Exception_init_func(Con_VM* vm)
{
	Con_Value self, should_be, is, msg, thing;

	Con_VM_decode_args(vm, "occ;s", &self, &should_be, &is, &thing);

	msg = Con_String_new_c_str(vm, "Expected ");
	if (!Con_VM_is(vm, thing, vm->builtins[CON_BUILTIN_NULL_VAL])) {
		msg = Con_String_add(vm, msg, thing);
		msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, " to be instance of "));
	}
	else
		msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "instance of "));
	msg = Con_String_add(vm, msg, Con_Object_get_slot(vm, should_be, "name"));
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, ", but got instance of "));
	msg = Con_String_add(vm, msg, Con_Object_get_slot(vm, is, "name"));
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "."));
	
	Con_Object_set_slot(vm, self, "msg", msg);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);	
}



void _Con_Mod_Exceptions_Slot_Exception_init_func(Con_VM* vm)
{
	Con_Value self, slot_name, msg, class;

	Con_VM_decode_args(vm, "os;c", &self, &slot_name, &class);

	msg = Con_String_new_c_str(vm, "No such slot '");
	msg = Con_String_add(vm, msg, slot_name);
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "'"));
	if (!Con_VM_is(vm, class, vm->builtins[CON_BUILTIN_NULL_VAL])) {
		msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, " in instance of "));
		msg = Con_String_add(vm, msg, Con_Object_get_slot(vm, class, "name"));
	}
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "."));
	
	Con_Object_set_slot(vm, self, "msg", msg);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);	
}



void _Con_Mod_Exceptions_Bounds_Exception_init_func(Con_VM* vm)
{
	Con_Value self, index, bound, msg;

	Con_VM_decode_args(vm, "o;ii", &self, &index, &bound);
	
	if (!Con_VM_is(vm, index, vm->builtins[CON_BUILTIN_NULL_VAL]) && Con_VM_is(vm, bound, vm->builtins[CON_BUILTIN_NULL_VAL]))
		Con_Mod_Exceptions_quick(vm, "Parameters_Exception", 1, Con_String_new_c_str(vm, "'bound' parameter must not be null if 'index' parameter is an integer."));

	if (!Con_VM_is(vm, index, vm->builtins[CON_BUILTIN_NULL_VAL])) {
		msg = Con_VM_apply_c(vm, Con_Object_get_slot(vm, index, "to_str"), 0);
		if (index.datum.integer >= bound.datum.integer)
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, " exceeds upper bound "));
		else
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, " below lower bound "));
		msg = Con_String_add(vm, msg, Con_VM_apply_c(vm, Con_Object_get_slot(vm, bound, "to_str"), 0));
	}
	else
		msg = Con_String_new_c_str(vm, "Index out of bounds.");

	
	Con_Object_set_slot(vm, self, "msg", msg);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);	
}


void _Con_Mod_Exceptions_Key_Exception_init_func(Con_VM* vm)
{
	Con_Value self, key, msg;

	Con_VM_decode_args(vm, "os", &self, &key);

	msg = Con_String_new_c_str(vm, "No such key ");
	msg = Con_String_add(vm, msg, Con_VM_apply_c(vm, Con_Object_get_slot(vm, key, "to_str"), 0));
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "."));
	
	Con_Object_set_slot(vm, self, "msg", msg);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);	
}



void _Con_Mod_Exceptions_Unhashable_Exception_init_func(Con_VM* vm)
{
	Con_Value self, key, msg;

	Con_VM_decode_args(vm, "oo", &self, &key);

	msg = Con_VM_apply_c(vm, Con_Object_get_slot(vm, key, "to_str"), 0);
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, " is unhashable."));

	Con_Object_set_slot(vm, self, "msg", msg);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);	
}



void _Con_Mod_Exceptions_Apply_Exception_init_func(Con_VM* vm)
{
	Con_Value self, val, msg;

	Con_VM_decode_args(vm, "oo", &self, &val);

	msg = Con_String_new_c_str(vm, "Do not know how to apply ");
	msg = Con_String_add(vm, msg, Con_VM_apply_c(vm, Con_Object_get_slot(vm, val, "to_str"), 0));
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "."));

	Con_Object_set_slot(vm, self, "msg", msg);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);	
}

//
//
//


void Con_Mod_Exceptions_quick(Con_VM* vm, const char* exception_name, int num_args, ...)
{
	va_list ap;
	int args_processed;
	Con_Value arg;

	va_start(ap, num_args);
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_EXCEPTIONS_MODULE], exception_name));
	for (args_processed = 0; args_processed < num_args; args_processed += 1) {
		arg = va_arg(ap, Con_Value);
		Con_VM_con_stack_push_value(vm, vm->continuation, arg);
	}
	va_end(ap);

	Con_VM_apply(vm, num_args);
	Con_VM_raise(vm, Con_VM_con_stack_pop_value(vm, vm->continuation));
}
