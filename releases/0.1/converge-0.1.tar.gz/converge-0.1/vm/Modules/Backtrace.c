#include <ctype.h>
#include <string.h>
#include <stdio.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"

#include "Backtrace.h"
#include "Bytecode.h"
#include "Builtins/String.h"
#include "Builtins/List.h"
#include "Builtins/Dict.h"
#include "Builtins/Func.h"
#include "Builtins/Func_Binding.h"
#include "Builtins/Int.h"
#include "Builtins/Backtrace.h"
#include "Builtins/Module.h"



void _Con_Mod_Backtrace_backtrace_func(Con_VM* vm);



void Con_Mod_Backtrace_init(Con_VM* vm)
{
	Con_Value backtrace_func;

	backtrace_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_Backtrace_backtrace_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "backtrace"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "backtrace", backtrace_func);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);

	Con_VM_return(vm);
}



void _Con_Mod_Backtrace_backtrace_func(Con_VM* vm)
{
	Con_Value exception, backtrace, backtrace_objs, module_val, func_val, container, contained;
	Con_Module* module;
	Con_Bytecode* module_bytecode;
	Con_Bytecode* line_numbers;
	Con_Backtrace_Obj* backtrace_obj;
	int bytecode_pos, instruction_src_pos, i, j, k, column;

	Con_VM_decode_args(vm, "o", &exception);
	backtrace_objs = Con_Object_get_slot(vm, exception, "backtrace_objs");

	// If there is nothing in the backtrace, then the exception occurred at the top level and hence
	// it's not worth trying to print anything.

	if (Con_List_get_size(vm, backtrace_objs) == 0)
		backtrace = Con_String_new_c_str(vm, "");
	else
		backtrace = Con_String_new_c_str(vm, "Traceback (most recent call last):\n");
	
	for (i = 0; i < Con_List_get_size(vm, backtrace_objs); i += 1) {
		if (i > 0)
			backtrace = Con_String_add(vm, backtrace, Con_String_new_c_str(vm, "\n"));
		backtrace_obj = (Con_Backtrace_Obj*) Con_List_get_item(vm, backtrace_objs, i).datum.object;
		module_val = Con_Object_get_slot(vm, Con_List_get_item(vm, backtrace_objs, i), "module");
		if (Con_VM_is(vm, module_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
			module = NULL;
		else
			module = ((Con_Module_Obj*) module_val.datum.object)->module;
		func_val = ((Con_Object_Func_Binding*) Con_Object_get_slot(vm, Con_List_get_item(vm, backtrace_objs, i), "func").datum.object)->func;
		if (module != NULL && module->type == Con_IMPORT_CVB) {
			backtrace = Con_String_add(vm, backtrace, Con_String_new_c_str(vm, "  File \""));
			backtrace = Con_String_add(vm, backtrace, Con_String_new_c_str(vm, module->full_name));
			backtrace = Con_String_add(vm, backtrace, Con_String_new_c_str(vm, "\", line "));
			module_bytecode = vm->bytecode + module->bytecode_offset / sizeof(Con_Bytecode);
			bytecode_pos = backtrace_obj->pc.bytecode - module->bytecode_offset - module_bytecode[Con_BYTECODE_MODULE_PROGRAM];
			instruction_src_pos = module_bytecode[module_bytecode[Con_BYTECODE_MODULE_SRC_POSITIONS] / sizeof(Con_Bytecode) + bytecode_pos / sizeof(Con_Bytecode)];
			j = 0;
			line_numbers = module_bytecode + module_bytecode[Con_BYTECODE_MODULE_NEWLINES] / sizeof(Con_Bytecode);
			while (true) {
				if (instruction_src_pos < line_numbers[j]) {
					j -= 1;
					break;
				}
				j += 1;
			}
			Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, Con_Int_new(j + 1), "to_str"));
			Con_VM_apply(vm, 0);
			backtrace = Con_String_add(vm, backtrace, Con_VM_con_stack_pop_value(vm, vm->continuation));
			column = instruction_src_pos - line_numbers[j];
			backtrace = Con_String_add(vm, backtrace, Con_String_new_c_str(vm, ", column "));
			Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, Con_Int_new(column), "to_str"));
			Con_VM_apply(vm, 0);
			backtrace = Con_String_add(vm, backtrace, Con_VM_con_stack_pop_value(vm, vm->continuation));
			
			if (!Con_VM_is(vm, vm->builtins[CON_BUILTIN_NULL_VAL], func_val)) {
				backtrace = Con_String_add(vm, backtrace, Con_String_new_c_str(vm, ", in "));
				backtrace = Con_String_add(vm, backtrace, Con_Object_get_slot(vm, func_val, "name"));
			}
		}
		else {
			backtrace = Con_String_add(vm, backtrace, Con_String_new_c_str(vm, "  Internal: "));
			container = func_val;
			j = 0;
			while (Con_Object_has_slot(vm, container, "container")) {
				container = Con_Object_get_slot(vm, container, "container");
				j += 1;
			}
			while (j >= 0) {
				contained = func_val;
				k = j;
				while (k > 0) {
					contained = Con_Object_get_slot(vm, contained, "container");
					k -= 1;
				}
				backtrace = Con_String_add(vm, backtrace, Con_Object_get_slot(vm, contained, "name"));
				j -= 1;
				if (j >= 0)
					backtrace = Con_String_add(vm, backtrace, Con_String_new_c_str(vm, "."));
			}
		}
	}
	Con_VM_con_stack_push_value(vm, vm->continuation, backtrace);
	Con_VM_return(vm);	
}
