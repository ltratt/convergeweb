#include <errno.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <fcntl.h>
#include <dirent.h>
#include <unistd.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Memory.h"
#include "Builtins/Dict.h"
#include "Builtins/Func.h"
#include "Builtins/String.h"
#include "Builtins/List.h"
#include "Builtins/Object_Class.h"
#include "Builtins/Int.h"
#include "Builtins/Meta_C_Class.h"
#include "Modules/Exceptions.h"

#include "File.h"


void _Con_Mod_file_error(Con_VM* vm, Con_Value file_name, const char* reason);

void _Con_Mod_File_open_func(Con_VM* vm);
void _Con_Mod_File_exists_func(Con_VM* vm);
void _Con_Mod_File_canon_path_func(Con_VM* vm);
void _Con_Mod_File_is_dir_func(Con_VM* vm);
void _Con_Mod_File_dir_entries_func(Con_VM* vm);

void _Con_Mod_File_File_Class_init_func(Con_VM* vm);
void _Con_Mod_File_File_Class_to_str_func(Con_VM* vm);
void _Con_Mod_File_File_Class_read_line_func(Con_VM* vm);
void _Con_Mod_File_File_Class_read_func(Con_VM* vm);
void _Con_Mod_File_File_Class_write_func(Con_VM* vm);
void _Con_Mod_File_File_Class_close_func(Con_VM* vm);


void Con_Mod_File_init(Con_VM* vm)
{
	Con_Value file_class_supers, file_class_fields, file_class_init_func, file_class_to_str_func, file_class, file_class_read_line_func, file_class_read_func, file_class_write_func, file_class_close_func;
	Con_Value open_func, exists_func, canon_path_func, is_dir_func, dir_entries_func;

	// open
	
	open_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_File_open_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "open"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "open", open_func);

	// exists
	
	exists_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_File_exists_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "exists"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "exists", exists_func);

	// canon_path
	
	canon_path_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_File_canon_path_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "canon_path"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "canon_path", canon_path_func);

	// is_dir
	
	is_dir_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_File_is_dir_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "is_dir"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "is_dir", is_dir_func);

	// dir_entries
	
	dir_entries_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_File_dir_entries_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "dir_entries"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "dir_entries", dir_entries_func);

	// Supers
	file_class_supers = Con_List_new(vm);
	Con_List_append(vm, file_class_supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	// Fields
	file_class_fields = Con_Dict_new(vm);
	// init
	file_class_init_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_File_File_Class_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, file_class_fields, Con_String_new_c_str(vm, "init"), file_class_init_func);
	// to_str
	file_class_to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_File_File_Class_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, file_class_fields, Con_String_new_c_str(vm, "to_str"), file_class_to_str_func);
	// read_line
	file_class_read_line_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_File_File_Class_read_line_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "read_line"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, file_class_fields, Con_String_new_c_str(vm, "read_line"), file_class_read_line_func);
	// read
	file_class_read_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_File_File_Class_read_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "read"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, file_class_fields, Con_String_new_c_str(vm, "read"), file_class_read_func);
	// write
	file_class_write_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_File_File_Class_write_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "write"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, file_class_fields, Con_String_new_c_str(vm, "write"), file_class_write_func);
	// close
	file_class_close_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_File_File_Class_close_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "close"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, file_class_fields, Con_String_new_c_str(vm, "close"), file_class_close_func);
	
	file_class = Con_Meta_C_Class_new(vm, Con_String_new_c_str(vm, "File"), file_class_supers, file_class_fields, sizeof(Con_File_Object));
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "File", file_class);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



// error routine

void _Con_Mod_file_error(Con_VM* vm, Con_Value file_name, const char* reason)
{
	Con_Value msg;
	
	msg = Con_String_new_c_str(vm, "Failed when ");
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, reason));
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, " '"));
	msg = Con_String_add(vm, msg, file_name);
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "': "));
	switch (errno) {
		case ENOENT:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "no such file or directory"));
			break;
		case EACCES:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "permission denied"));
			break;
		case ENOTDIR:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "not a directory"));
			break;
		case EISDIR:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "is a directory"));
			break;
		case ENOSPC:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "device out of space"));
			break;
		case ESPIPE:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "illegal seek"));
			break;
		case EROFS:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "read-only file system"));
			break;
		case EAGAIN:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "resource temporarily unavailable"));
			break;
		case ENAMETOOLONG:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "name too long"));
			break;
		case EDQUOT:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "disk quota exceeded"));
			break;
		default:
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "[unknown errno="));
			msg = Con_String_add(vm, msg, Con_VM_apply_c(vm, Con_Object_get_slot(vm, Con_Int_new(errno), "to_str"), 0));
			msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "]"));
			break;
	}
	msg = Con_String_add(vm, msg, Con_String_new_c_str(vm, "."));
	Con_Mod_Exceptions_quick(vm, "File_Exception", 1, msg);
}



// open

void _Con_Mod_File_open_func(Con_VM* vm)
{
	Con_Value name, mode;
	
	Con_VM_decode_args(vm, "ss", &name, &mode);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_VM_apply_c(vm, Con_Object_get_slot(vm, vm->continuation->module->module_val, "File"), 2, name, mode));
	Con_VM_return(vm);
}




// exists

void _Con_Mod_File_exists_func(Con_VM* vm)
{
	struct stat file_stat;
	Con_Value file_name;
	
	Con_VM_decode_args(vm, "s", &file_name);
	
	if (stat(((Con_String_Object*) file_name.datum.object)->str, &file_stat) == -1) {
		if (errno == ENOENT)
			Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
		else
			_Con_Mod_file_error(vm, file_name, "stat'ing");
	}
	else
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
		
	Con_VM_return(vm);
}



// canon_path

void _Con_Mod_File_canon_path_func(Con_VM* vm)
{
	Con_Value file_name;
	char* canon_path;
	
	Con_VM_decode_args(vm, "s", &file_name);
	
	canon_path = Con_malloc(vm, MAXPATHLEN, Con_MEMORY_GC);
	if (realpath(((Con_String_Object*) file_name.datum.object)->str, canon_path) == NULL)
		XXX
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, canon_path));
	Con_VM_return(vm);
}



// is_dir

void _Con_Mod_File_is_dir_func(Con_VM* vm)
{
	struct stat file_stat;
	Con_Value file_name;
	
	Con_VM_decode_args(vm, "s", &file_name);
	
	if (stat(((Con_String_Object*) file_name.datum.object)->str, &file_stat) == -1)
		_Con_Mod_file_error(vm, file_name, "stat'ing");

	if (file_stat.st_mode & S_IFDIR)
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	else
		Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
		
	Con_VM_return(vm);
}



// dir_entries

void _Con_Mod_File_dir_entries_func(Con_VM* vm)
{
	Con_Value dir_name, dir_entries;
#ifdef HAVE_GETDIRENTRIES
	char* buf;
	struct stat dir_stat;
	int fd, getdirentries_rtn, errno_backup;
	long basep;
#else
	DIR* dirp;
#endif
	struct dirent* entry;
	
	Con_VM_decode_args(vm, "s", &dir_name);

#ifdef HAVE_GETDIRENTRIES
	if (stat(((Con_String_Object*) dir_name.datum.object)->str, &dir_stat) == -1)
		_Con_Mod_file_error(vm, dir_name, "stat'ing");

	if ((fd = open(((Con_String_Object*) dir_name.datum.object)->str, O_RDONLY, 0)) < 0)
		_Con_Mod_file_error(vm, dir_name, "opening");

	buf = Con_malloc(vm, dir_stat.st_blksize, Con_MEMORY_GC_NO_PTRS);
	
	dir_entries = Con_List_new(vm);

	while (1) {
		getdirentries_rtn = getdirentries(fd, buf, dir_stat.st_blksize, &basep);
		if (getdirentries_rtn == 0)
			break;
		else if (getdirentries_rtn == -1) {
			errno_backup = errno;
			close(fd);
			errno = errno_backup;
			_Con_Mod_file_error(vm, dir_name, "reading directory entries");
		}
		entry = (struct dirent*) buf;
		while ((char*) entry < buf + getdirentries_rtn) {
			if (!(entry->DIRENT_D_FILENO == 0 || strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0))
				Con_List_append(vm, dir_entries, Con_String_new_c_str(vm, entry->d_name));
#ifdef DIRENT_HAS_D_RECLEN
			entry = ((void*) entry) + entry->d_reclen;
#else /* DIRENT_HAS_D_RECLEN */
			entry = ((void*) entry) + sizeof(
#endif /* DIRENT_HAS_D_RECLEN */
		}
	}

	if (close(fd) == -1)
		_Con_Mod_file_error(vm, dir_name, "closing directory");

#else /* HAVE_GETDIRENTRIES */

	if ((dirp = opendir(((Con_String_Object*) dir_name.datum.object)->str)) == NULL)
		_Con_Mod_file_error(vm, dir_name, "opening directory");
	
	dir_entries = Con_List_new(vm);

	while (1) {
		entry = readdir(dirp);
		if (entry == NULL)
			break;
		if (!(entry->DIRENT_D_FILENO == 0 || strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)) {
			Con_List_append(vm, dir_entries, Con_String_new_c_str(vm, entry->d_name));
		}
	}
	
	if (closedir(dirp) != 0)
		_Con_Mod_file_error(vm, dir_name, "closing directory");
#endif /* HAVE_GETDIRENTRIES */

	Con_VM_con_stack_push_value(vm, vm->continuation, dir_entries);
	Con_VM_return(vm);
}



////////////////////////////////////////////////////////////////////////////////////////////////////
// class File
//


void _Con_Mod_File_File_Class_init_func(Con_VM* vm)
{
	Con_Value self, name, mode;
	Con_File_Object* file_obj;

	Con_VM_decode_args(vm, "oss", &self, &name, &mode);
	self.datum.object->type = CON_OBJECT_FILE;
	file_obj = (Con_File_Object*) self.datum.object;
	
	file_obj->file = fopen(((Con_String_Object*) name.datum.object)->str, ((Con_String_Object*) mode.datum.object)->str);
//	printf("%d\n", errno);
	if (file_obj->file == NULL)
		_Con_Mod_file_error(vm, name, "opening");
		
	Con_Object_set_slot(vm, self, "name", name);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_Mod_File_File_Class_to_str_func(Con_VM* vm)
{
	Con_Value self;

	Con_VM_decode_args(vm, "o", &self);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_Mod_File_File_Class_read_line_func(Con_VM* vm)
{
	Con_File_Object* file_obj;
	Con_Value self;
	char* str;
	int str_len;
	
	Con_VM_decode_args(vm, "o", &self);
	file_obj = (Con_File_Object*) self.datum.object;
	
	while (1) {
		str = fgetln(file_obj->file, &str_len);
		if (str == NULL) {
			if (feof(file_obj->file) != 0) {
				Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
				Con_VM_return(vm);
			}
			else if (ferror(file_obj->file) != 0)
				_Con_Mod_file_error(vm, Con_Object_get_slot(vm, self, "name"), "reading line");
			else
				CON_FATAL_ERROR("Unexpected file state");
		}
		Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new(vm, str, str_len));
		Con_VM_yield(vm);
	}
}



void _Con_Mod_File_File_Class_read_func(Con_VM* vm)
{
	Con_File_Object* file_obj;
	Con_String_Object* str_obj;
	Con_Value self, data, size;
	int data_size, amount_read;
	struct stat file_stat;
	
	Con_VM_decode_args(vm, "o;i", &self, &size);
	file_obj = (Con_File_Object*) self.datum.object;
	
	if (fstat(fileno(file_obj->file), &file_stat) == -1)
		XXX;
	
	if (!Con_VM_is(vm, size, vm->builtins[CON_BUILTIN_NULL_VAL]))
		data_size = size.datum.integer;
	else
		data_size = file_stat.st_size - ftell(file_obj->file);

	data = Con_String_new_blank(vm, data_size);
	
	str_obj = (Con_String_Object*) data.datum.object;
	
	if ((amount_read = fread(str_obj->str, 1, data_size, file_obj->file)) != data_size) {
		printf("read: %d %d\n", amount_read, data_size);
		if (ferror(file_obj->file))
			_Con_Mod_file_error(vm, Con_Object_get_slot(vm, self, "name"), "reading");
	}
	str_obj->hash = Con_String_hash(str_obj->str, data_size);
	str_obj->str[data_size] = 0;
	
	Con_VM_con_stack_push_value(vm, vm->continuation, data);
	Con_VM_return(vm);
}




void _Con_Mod_File_File_Class_write_func(Con_VM* vm)
{
	Con_File_Object* file_obj;
	Con_String_Object* str_obj;
	Con_Value self, data;
	
	Con_VM_decode_args(vm, "os", &self, &data);
	file_obj = (Con_File_Object*) self.datum.object;
	
	str_obj = (Con_String_Object*) data.datum.object;
	
	if (fwrite(str_obj->str, 1, str_obj->str_size, file_obj->file) < 0)
		XXX;
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_Mod_File_File_Class_close_func(Con_VM* vm)
{
	Con_File_Object* file_obj;
	Con_Value self;
	
	Con_VM_decode_args(vm, "o", &self);
	file_obj = (Con_File_Object*) self.datum.object;
	
	if (fclose(file_obj->file) != 0)
		_Con_Mod_file_error(vm, Con_Object_get_slot(vm, self, "name"), "closing");
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}
