void Con_Mod_Backtrace_init(Con_VM* vm);
