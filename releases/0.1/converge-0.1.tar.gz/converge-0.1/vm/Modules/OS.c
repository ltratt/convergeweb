#include <stddef.h>
#include <stdio.h>
#include <sys/utsname.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Memory.h"
#include "Object.h"
#include "Builtins/Func.h"
#include "Builtins/String.h"
#include "Builtins/List.h"

#include "OS.h"



void Con_Mod_OS_init(Con_VM* vm)
{
	struct utsname* name;
	
	name = Con_malloc(vm, sizeof(struct utsname), Con_MEMORY_GC);

	if (uname(name) != 0)
		CON_FATAL_ERROR("uname failed");
	
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "name", Con_String_new_c_str(vm, name->sysname));
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "version", Con_String_new_c_str(vm, name->version));
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "release", Con_String_new_c_str(vm, name->release));
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "machine", Con_String_new_c_str(vm, name->machine));

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}
