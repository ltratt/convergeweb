#define CON_MOD_ARRAY_INITIAL_SIZE 256
#define CON_MOD_ARRAY_INCREMENT 512

typedef enum {CON_MOD_ARRAY_INT} Con_Mod_Array_Type;

typedef struct {
	CON_OBJECT_HEAD
	Con_Mod_Array_Type array_type;
	int num_elements, num_elements_allocated;
	void* elements;
	} Con_Mod_Array_Array_Object;

void Con_Mod_Array_init(Con_VM* vm);
