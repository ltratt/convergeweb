void Con_Mod_C_Parser_init(Con_VM* vm);
