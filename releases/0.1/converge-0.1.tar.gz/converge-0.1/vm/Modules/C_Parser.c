#include <errno.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Memory.h"
#include "Builtins/Dict.h"
#include "Builtins/Func.h"
#include "Builtins/String.h"
#include "Builtins/List.h"
#include "Builtins/Object_Class.h"
#include "Builtins/Int.h"
#include "Modules/Exceptions.h"

#include "C_Parser.h"


void _Con_Mod_C_Parser_Class_parse_func(Con_VM* vm);


void Con_Mod_C_Parser_init(Con_VM* vm)
{
	Con_Value c_parser_class, c_parser_class_supers, c_parser_class_fields, c_parser_class_parse_func;
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	// Name
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, "C_Parser"));
	// Supers
	c_parser_class_supers = Con_List_new(vm);
	Con_List_append(vm, c_parser_class_supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	Con_VM_con_stack_push_value(vm, vm->continuation, c_parser_class_supers);
	// Fields
	c_parser_class_fields = Con_Dict_new(vm);
	// new
	c_parser_class_parse_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_C_Parser_Class_parse_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "parse"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, c_parser_class_fields, Con_String_new_c_str(vm, "parse"), c_parser_class_parse_func);
	// Push fields
	Con_VM_con_stack_push_value(vm, vm->continuation, c_parser_class_fields);
	Con_VM_apply(vm, 3);

	c_parser_class = Con_VM_con_stack_pop_value(vm, vm->continuation);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "C_Parser", c_parser_class);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}


////////////////////////////////////////////////////////////////////////////////////////////////////
// The parser
//

typedef struct {
	Con_Value grammar, alternatives_map, productions, precedences, open_curly, close_curly, nullables, states;
	int num_unique_productions;
	} Vars;

typedef struct {
	int p;
	int j;
	int f;
	Con_Value tree;
	int num_entries, num_entries_allocated;
	} Item;

typedef struct {
	int num_items;
	int num_items_allocated;
	Item* items;
	Con_Value already_predicted;
	} State;

#define STATE_P 0
#define STATE_J 1
#define STATE_F 2
#define STATE_T 3

int _Con_Mod_C_Parser_find_item(Con_VM* vm, Vars* vars, int state_i, int p, int j, int f);
void _Con_C_Parser_add_complete(Con_VM* vm, Vars* vars, int state_i, Con_Value f_item, int p, int j, int f, Con_Value tree_item);
Con_Value _Con_C_Parser_create_tree(Con_VM* vm, Vars* vars, Con_Value item);
int _Con_Mod_C_Parser_calc_length(Con_VM* vm, Con_Value tree);
void _Con_Mod_C_Parser_add_item_to_state(Con_VM* vm, Vars* vars, int state_i, Con_Value item);


void _Con_Mod_C_Parser_Class_parse_func(Con_VM* vm)
{
	Con_Value self, tokens, production, f_production, production_alternatives, temp_tree1, temp_tree2, already_predicted, item, new_item, f_state, f_item, state;
	Vars* vars;
	int i, j, k, l, item_j, item_p, item_f, f_item_j, f_item_p, f_item_f;

	vars = Con_malloc(vm, sizeof(Vars), Con_MEMORY_GC);
	Con_VM_decode_args(vm, "ol", &self, &tokens);
	vars->grammar = Con_Object_get_slot(vm, self, "grammar");
	vars->productions = Con_Object_get_slot(vm, vars->grammar, "productions");
	vars->alternatives_map = Con_Object_get_slot(vm, vars->grammar, "alternatives_map");
	vars->num_unique_productions = Con_Dict_len(vm, vars->alternatives_map);
	vars->nullables = Con_Object_get_slot(vm, vars->grammar, "nullables");
	vars->precedences = Con_Object_get_slot(vm, vars->grammar, "precedences");
	vars->open_curly = Con_String_new_c_str(vm, "{");
	vars->close_curly = Con_String_new_c_str(vm, "}*");
	
	temp_tree1 = Con_List_new(vm);
	Con_List_append(vm, temp_tree1, Con_Int_new(0));
	Con_List_append(vm, temp_tree1, Con_Int_new(1));
	Con_List_append(vm, temp_tree1, Con_Int_new(0));
	Con_List_append(vm, temp_tree1, Con_List_new(vm));
	temp_tree2 = Con_List_new(vm);
	Con_List_append(vm, temp_tree2, temp_tree1);
	vars->states = Con_List_new(vm);
	Con_List_append(vm, vars->states, temp_tree2);

	for (i = 0; i <= Con_List_get_size(vm, tokens); i += 1) {
		if (i < Con_List_get_size(vm, tokens)) {
			Con_List_append(vm, vars->states, Con_List_new(vm));
		}
		j = 0;
		already_predicted = Con_List_new(vm);
		while (j < Con_List_get_size(vm, Con_List_get_item(vm, vars->states, i))) {
			item = Con_List_get_item(vm, Con_List_get_item(vm, vars->states, i), j);
			item_j = Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_J));
			item_p = Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_P));
			item_f = Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_F));
			production = Con_List_get_item(vm, vars->productions, item_p);
			if ((i < Con_List_get_size(vm, tokens)) &&
				(item_j < Con_List_get_size(vm, production)) &&
				(!Con_Dict_contains(vm, vars->alternatives_map, Con_List_get_item(vm, production, item_j))) &&
				(Con_VM_equals(vm, Con_List_get_item(vm, production, item_j), Con_Object_get_slot(vm, Con_List_get_item(vm, tokens, i), "type")))) {
//				printf("scanner\n");
				new_item = Con_List_new(vm);
				Con_List_append(vm, new_item, Con_Int_new(item_p));
				Con_List_append(vm, new_item, Con_Int_new(item_j + 1));
				Con_List_append(vm, new_item, Con_Int_new(item_f));
				temp_tree1 = Con_List_new(vm);
				Con_List_append(vm, temp_tree1, Con_List_get_item(vm, tokens, i));
				Con_List_append(vm, new_item, Con_List_add(vm, Con_List_get_item(vm, item, STATE_T), temp_tree1));
				_Con_Mod_C_Parser_add_item_to_state(vm, vars, i + 1, new_item);
			}
			else if ((item_j < Con_List_get_size(vm, production)) &&
				(Con_Dict_contains(vm, vars->alternatives_map, Con_List_get_item(vm, production, item_j))) &&
				(!Con_List_contains(vm, already_predicted, Con_List_get_item(vm, production, item_j)))) {
//				printf("predictor\n");
				Con_List_append(vm, already_predicted, Con_List_get_item(vm, production, item_j));
				production_alternatives = Con_Dict_lookup(vm, vars->alternatives_map, Con_List_get_item(vm, production, item_j));
				for (k = 0; k < Con_List_get_size(vm, production_alternatives); k += 1) {
					new_item = Con_List_new(vm);
					Con_List_append(vm, new_item, Con_List_get_item(vm, production_alternatives, k));
					Con_List_append(vm, new_item, Con_Int_new(1));
					Con_List_append(vm, new_item, Con_Int_new(i));
					Con_List_append(vm, new_item, Con_List_new(vm));
					_Con_Mod_C_Parser_add_item_to_state(vm, vars, i, new_item);
				}
				if (Con_Int_extract(vm, Con_Dict_lookup(vm, vars->nullables, Con_List_get_item(vm, production, item_j))) == 1) {
					new_item = Con_List_new(vm);
					Con_List_append(vm, new_item, Con_Int_new(item_p));
					Con_List_append(vm, new_item, Con_Int_new(item_j + 1));
					Con_List_append(vm, new_item, Con_Int_new(item_f));
					temp_tree1 = Con_List_new(vm);
					temp_tree2 = Con_List_new(vm);
					Con_List_append(vm, temp_tree1, temp_tree2);
					Con_List_append(vm, new_item, Con_List_add(vm, Con_List_get_item(vm, item, STATE_T), temp_tree1));
					_Con_Mod_C_Parser_add_item_to_state(vm, vars, i, new_item);
				}
			}
			else if (item_j == Con_List_get_size(vm, production)) {
//				printf("completer\n");
				f_state = Con_List_get_item(vm, vars->states, item_f);
				for (k = 0; k < Con_List_get_size(vm, f_state); k += 1) {
					f_item = Con_List_get_item(vm, f_state, k);
					f_item_p = Con_Int_extract(vm, Con_List_get_item(vm, f_item, STATE_P));
					f_item_j = Con_Int_extract(vm, Con_List_get_item(vm, f_item, STATE_J));
					f_item_f = Con_Int_extract(vm, Con_List_get_item(vm, f_item, STATE_F));
					f_production = Con_List_get_item(vm, vars->productions, f_item_p);
					if ((f_item_j < Con_List_get_size(vm, f_production)) &&
						(Con_VM_equals(vm, Con_List_get_item(vm, f_production, f_item_j), Con_List_get_item(vm, production, 0)))) {
						if ((f_item_j + 1 < Con_List_get_size(vm, f_production)) &&
							(Con_VM_equals(vm, Con_List_get_item(vm, f_production, f_item_j + 1), vars->open_curly))) {
							_Con_C_Parser_add_complete(vm, vars, i, f_item, f_item_p, f_item_j + 2, f_item_f, item);
							l = f_item_j + 2;
							while (!Con_VM_equals(vm, Con_List_get_item(vm, f_production, l), vars->close_curly))
								l += 1;
							_Con_C_Parser_add_complete(vm, vars, i, f_item, f_item_p, l + 1, f_item_f, item);
						}
						else if ((f_item_j + 1 < Con_List_get_size(vm, f_production)) &&
							(Con_VM_equals(vm, Con_List_get_item(vm, f_production, f_item_j + 1), vars->close_curly))) {
							_Con_C_Parser_add_complete(vm, vars, i, f_item, f_item_p, f_item_j + 2, f_item_f, item);
							l = f_item_j - 1;
							while (!Con_VM_equals(vm, Con_List_get_item(vm, f_production, l), vars->open_curly))
								l -= 1;
							_Con_C_Parser_add_complete(vm, vars, i, f_item, f_item_p, l + 1, f_item_f, item);
						}
						else
							_Con_C_Parser_add_complete(vm, vars, i, f_item, f_item_p, f_item_j + 1, f_item_f, item);
					}
				}
			}
			j += 1;
		}
		if ((i < Con_List_get_size(vm, tokens)) && (Con_List_get_size(vm, Con_List_get_item(vm, vars->states, i + 1)) == 0)) {
			Con_VM_apply_c(vm, Con_Object_get_slot(vm, self, "error"), 1, Con_List_get_item(vm, tokens, i));
		}
	}

	state = Con_List_get_item(vm, vars->states, i - 1);
	for (j = 0; j < Con_List_get_size(vm, state); j += 1) {
		item = Con_List_get_item(vm, state, j);
		if ((Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_P)) == 0) && 
			(Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_J)) == 2) &&
			(Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_F)) == 0))
			break;
	}
	if (j == Con_List_get_size(vm, state))
		printf("err2\n");

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_get_item(vm, _Con_C_Parser_create_tree(vm, vars, item), 1));
//	Con_VM_con_stack_push_value(vm, vm->continuation, Con_List_get_item(vm, Con_VM_apply_c(vm, Con_Object_get_slot(vm, self, "_create_tree"), 1, item), 1));
	Con_VM_return(vm);
}




void _Con_Mod_C_Parser_add_item_to_state(Con_VM* vm, Vars* vars, int state_i, Con_Value item)
{
	Con_Value production, new_item, item_t;
	int k, item_j, item_p, item_f;

	item_p = Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_P));
	item_j = Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_J));
	item_f = Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_F));
	item_t = Con_List_get_item(vm, item, STATE_T);
	production = Con_List_get_item(vm, vars->productions, item_p);
	
	if ((item_j < Con_List_get_size(vm, production)) &&
		(Con_VM_equals(vm, Con_List_get_item(vm, production, item_j), vars->open_curly))) {
		if (_Con_Mod_C_Parser_find_item(vm, vars, state_i, item_p, item_j + 1, item_f) == -1) {
			new_item = Con_List_new(vm);
			Con_List_append(vm, new_item, Con_Int_new(item_p));
			Con_List_append(vm, new_item, Con_Int_new(item_j + 1));
			Con_List_append(vm, new_item, Con_Int_new(item_f));
			Con_List_append(vm, new_item, Con_List_slice(vm, item_t, 0, Con_List_get_size(vm, item_t)));
			Con_List_append(vm, Con_List_get_item(vm, vars->states, state_i), new_item);
		}
		k = item_j + 1;
		while (!Con_VM_equals(vm, Con_List_get_item(vm, production, k), vars->close_curly))
			k += 1;
		if (_Con_Mod_C_Parser_find_item(vm, vars, state_i, item_p, k + 1, item_f) == -1) {
			new_item = Con_List_new(vm);
			Con_List_append(vm, new_item, Con_Int_new(item_p));
			Con_List_append(vm, new_item, Con_Int_new(k + 1));
			Con_List_append(vm, new_item, Con_Int_new(item_f));
			Con_List_append(vm, new_item, Con_List_slice(vm, item_t, 0, Con_List_get_size(vm, item_t)));
			Con_List_append(vm, Con_List_get_item(vm, vars->states, state_i), new_item);
		}
	}
	else if ((item_j < Con_List_get_size(vm, production)) &&
		(Con_VM_equals(vm, Con_List_get_item(vm, production, item_j), vars->close_curly))) {
		if (_Con_Mod_C_Parser_find_item(vm, vars, state_i, item_p, item_j + 1, item_f) == -1) {
			new_item = Con_List_new(vm);
			Con_List_append(vm, new_item, Con_Int_new(item_p));
			Con_List_append(vm, new_item, Con_Int_new(item_j + 1));
			Con_List_append(vm, new_item, Con_Int_new(item_f));
			Con_List_append(vm, new_item, Con_List_slice(vm, item_t, 0, Con_List_get_size(vm, item_t)));
			Con_List_append(vm, Con_List_get_item(vm, vars->states, state_i), new_item);
		}
		k = item_j - 1;
		while (!Con_VM_equals(vm, Con_List_get_item(vm, production, k), vars->open_curly))
			k -= 1;
		if (_Con_Mod_C_Parser_find_item(vm, vars, state_i, item_p, k + 1, item_f) == -1) {
			new_item = Con_List_new(vm);
			Con_List_append(vm, new_item, Con_Int_new(item_p));
			Con_List_append(vm, new_item, Con_Int_new(k + 1));
			Con_List_append(vm, new_item, Con_Int_new(item_f));
			Con_List_append(vm, new_item, Con_List_slice(vm, item_t, 0, Con_List_get_size(vm, item_t)));
			Con_List_append(vm, Con_List_get_item(vm, vars->states, state_i), new_item);
		}
	}
	else if (_Con_Mod_C_Parser_find_item(vm, vars, state_i, item_p, item_j, item_f) == -1)
		Con_List_append(vm, Con_List_get_item(vm, vars->states, state_i), item);
}



int _Con_Mod_C_Parser_find_item(Con_VM* vm, Vars* vars, int state_i, int p, int j, int f)
{
	Con_Value state, item;
	int i, state_len;

	state = Con_List_get_item(vm, vars->states, state_i);
	state_len = Con_List_get_size(vm, state);
	for (i = 0; i < state_len; i += 1) {
		item = Con_List_get_item(vm, state, i);
		if ((Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_P)) == p) && 
			(Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_J)) == j) &&
			(Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_F)) == f))
			return i;
	}
	
	return -1;
}



void _Con_C_Parser_add_complete(Con_VM* vm, Vars* vars, int state_i, Con_Value f_item, int p, int j, int f, Con_Value tree_item)
{
	Con_Value new_item, temp_tree1, temp_tree2;
	int pos;
	
	if ((pos = _Con_Mod_C_Parser_find_item(vm, vars, state_i, p, j, f)) != -1) {
		Con_List_append(vm, Con_List_get_item(vm, Con_List_get_item(vm, Con_List_get_item(vm, Con_List_get_item(vm, vars->states, state_i), pos), STATE_T), -1), tree_item);
	}
	else {
		new_item = Con_List_new(vm);
		Con_List_append(vm, new_item, Con_Int_new(p));
		Con_List_append(vm, new_item, Con_Int_new(j));
		Con_List_append(vm, new_item, Con_Int_new(f));
		temp_tree1 = Con_List_new(vm);
		temp_tree2 = Con_List_new(vm);
		Con_List_append(vm, temp_tree2, tree_item);
		Con_List_append(vm, temp_tree1, temp_tree2);
		Con_List_append(vm, new_item, Con_List_add(vm, Con_List_get_item(vm, f_item, STATE_T), temp_tree1));
		_Con_Mod_C_Parser_add_item_to_state(vm, vars, state_i, new_item);
	}
}



int _Con_Mod_C_Parser_calc_length(Con_VM* vm, Con_Value tree)
{
	Con_Value node;
	int i, length;
	
	length = 0;
	for (i = 0; i < Con_List_get_size(vm, tree); i += 1) {
		node = Con_List_get_item(vm, tree, i);
		if (Con_VM_is_type(vm, node, "l"))
			length += _Con_Mod_C_Parser_calc_length(vm, node);
		else
			length += 1;
	}
	
	return length;
}



Con_Value _Con_C_Parser_create_tree(Con_VM* vm, Vars* vars, Con_Value item)
{
	Con_Value tree, sub_tree, node, item_tree;
	Con_Value* sub_trees = NULL;
	int* priorities = NULL;
	int* lengths = NULL;
	int i, k, lists_size, lowest_priority_pos, node_length, shortest_pos;
	
	tree = Con_List_new(vm);
	Con_List_append(vm, tree, Con_List_get_item(vm, Con_List_get_item(vm, vars->productions, Con_Int_extract(vm, Con_List_get_item(vm, item, STATE_P))), 0));
	
	lists_size = 0;
	item_tree = Con_List_get_item(vm, item, STATE_T);
	for (i = 0; i < Con_List_get_size(vm, item_tree); i += 1) {
		node = Con_List_get_item(vm, item_tree, i);
		if (Con_VM_is_type(vm, node, "l")) {
			node_length = Con_List_get_size(vm, node);
			// If there's only one entry in the node, there's no point going through the general case
			if (node_length == 1) {
				Con_List_append(vm, tree, _Con_C_Parser_create_tree(vm, vars, Con_List_get_item(vm, node, 0)));
				continue;
			}
			if (node_length > lists_size) {
				lists_size = node_length;
				sub_trees = Con_malloc(vm, lists_size * sizeof(Con_Value), Con_MEMORY_GC);
				priorities = Con_malloc(vm, lists_size * sizeof(int), Con_MEMORY_GC);
				lengths = Con_malloc(vm, lists_size * sizeof(int), Con_MEMORY_GC);
			}
			// Calculate priorities
			for (k = 0; k < node_length; k += 1) {
				sub_tree = _Con_C_Parser_create_tree(vm, vars, Con_List_get_item(vm, node, k));
				sub_trees[k] = sub_tree;
				lengths[k] = _Con_Mod_C_Parser_calc_length(vm, sub_tree);
				priorities[k] = Con_List_get_item(vm, vars->precedences, Con_List_get_item(vm, Con_List_get_item(vm, node, k), 0).datum.integer).datum.integer;
			}
			
			// What we have to do now is a two stage thing. First of all, if any subtrees are
			// shorter than others, they get instant precedence. So we need to see if the length of
			// all subtrees is the same first. shortest_pos will be set to the index of the first
			// of the shortest trees. If all trees are the same length, shortest_pos will be equal to
			// 0 after the loop ends.
			
			shortest_pos = 0;
			for (k = 1; k < node_length; k += 1) {
				if (lengths[k] < lengths[shortest_pos])
					shortest_pos = k;
			}
			
			// Now we go back through the list and - whilst only taking notice of trees which have
			// the shortest length - find the lowest priority tree.
			
			lowest_priority_pos = shortest_pos;
			for (k = shortest_pos + 1; k < node_length; k += 1) {
				if (lengths[k] == lengths[shortest_pos] && priorities[k] < priorities[lowest_priority_pos])
					lowest_priority_pos = k;
			}
			Con_List_append(vm, tree, sub_trees[lowest_priority_pos]);
		}
		else
			Con_List_append(vm, tree, node);
	}

	return tree;
}
