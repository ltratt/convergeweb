#include <errno.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Memory.h"
#include "Builtins/Dict.h"
#include "Builtins/Func.h"
#include "Builtins/String.h"
#include "Builtins/List.h"
#include "Builtins/Int.h"
#include "Builtins/Set.h"
#include "Bytecode.h"
#include "Modules/Exceptions.h"
#include "Modules/Array.h"
#include "Mod_VM.h"
#include "Import.h"



void _Con_Mod_VM_add_modules_func(Con_VM* vm);
void _Con_Mod_VM_loaded_module_names_func(Con_VM* vm);


void Con_Mod_VM_init(Con_VM* vm)
{
	Con_Value add_modules_func, loaded_module_names_func;
	
	// add_modules

	add_modules_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_VM_add_modules_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "add_modules"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "add_modules", add_modules_func);

	// loaded_module_names

	loaded_module_names_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_VM_loaded_module_names_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "loaded_module_names"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "loaded_module_names", loaded_module_names_func);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



// add_modules

void _Con_Mod_VM_add_modules_func(Con_VM* vm)
{
	Con_Value bytecode, modules, array_module;
	Con_Mod_Array_Array_Object* array_obj;
	Con_Module* module_obj = NULL;
	int i;
	
	Con_VM_decode_args(vm, "l", &modules);
	
	if (Con_List_get_size(vm, modules) == 0)
		Con_Mod_Exceptions_quick(vm, "Exception", 1, Con_String_new_c_str(vm, "At least one module must be passed."));
	
	for (i = 0; i < Con_List_get_size(vm, modules); i += 1) {
		bytecode = Con_List_get_item(vm, modules, i);
	
		if (bytecode.type != CON_VALUE_OBJECT || bytecode.datum.object->type != CON_MOD_ARRAY_ARRAY) {
			array_module = Con_Import_builtin_module(vm, "Array");
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, Con_Object_get_slot(vm, array_module, "Array"), Con_Object_get_slot(vm, bytecode, "instance_of"));
		}

		array_obj = (Con_Mod_Array_Array_Object*) bytecode.datum.object;

		if (array_obj->array_type != CON_MOD_ARRAY_INT)
			XXX

		if (i == 0)
			module_obj = Con_Bytecode_add_module(vm, array_obj->elements);
		else
			Con_Bytecode_add_module(vm, array_obj->elements);
	}
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Import_module(vm, module_obj));
	Con_VM_return(vm);
}



// loaded_module_names

void _Con_Mod_VM_loaded_module_names_func(Con_VM* vm)
{
	Con_Value module_names;
	int i;
	
	Con_VM_decode_args(vm, "");

	module_names = Con_Set_new(vm);	
	for (i = 0; i < vm->modules_size; i += 1) {
		Con_Set_add(vm, module_names, Con_String_new_c_str(vm, vm->modules[i]->full_name));
	}
	
	Con_VM_con_stack_push_value(vm, vm->continuation, module_names);
	Con_VM_return(vm);
}
