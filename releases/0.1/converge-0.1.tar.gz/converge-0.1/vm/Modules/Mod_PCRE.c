#include <errno.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Memory.h"
#include "Builtins/Dict.h"
#include "Builtins/Func.h"
#include "Builtins/String.h"
#include "Builtins/List.h"
#include "Builtins/Object_Class.h"
#include "Builtins/Int.h"
#include "Builtins/Meta_C_Class.h"
#include "Modules/Exceptions.h"

#include "pcre.h"
#include "Mod_PCRE.h"


void _Con_Mod_PCRE_compile_func(Con_VM* vm);

void _Con_Mod_PCRE_PCRE_Class_init_func(Con_VM* vm);
void _Con_Mod_PCRE_Pattern_Class_match_func(Con_VM* vm);

void _Con_Mod_PCRE_Match_Class_init_func(Con_VM* vm);
void _Con_Mod_PCRE_Match_Class_lookup_func(Con_VM* vm);


void Con_Mod_PCRE_init(Con_VM* vm)
{
	Con_Value pattern_class, pattern_class_supers, pattern_class_fields, pattern_class_init_func, pattern_class_match_func;
	Con_Value match_class, match_class_supers, match_class_fields, match_class_init_func, match_class_lookup_func;
	Con_Value compile_func;
	
	// open
	
	compile_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_PCRE_compile_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "compile"), 0, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "compile", compile_func);


	//
	// class Pattern
	//

	// Supers
	pattern_class_supers = Con_List_new(vm);
	Con_List_append(vm, pattern_class_supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	// Fields
	pattern_class_fields = Con_Dict_new(vm);
	// init
	pattern_class_init_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_PCRE_PCRE_Class_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, pattern_class_fields, Con_String_new_c_str(vm, "init"), pattern_class_init_func);
	// match
	pattern_class_match_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_PCRE_Pattern_Class_match_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "match"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, pattern_class_fields, Con_String_new_c_str(vm, "match"), pattern_class_match_func);
	
	pattern_class = Con_Meta_C_Class_new(vm, Con_String_new_c_str(vm, "Pattern"), pattern_class_supers, pattern_class_fields, sizeof(Con_PCRE_Pattern_Object));
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "Pattern", pattern_class);

	//
	// class Match
	//

	// Name
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, "Match"));
	// Supers
	match_class_supers = Con_List_new(vm);
	Con_List_append(vm, match_class_supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	// Fields
	match_class_fields = Con_Dict_new(vm);
	// init
	match_class_init_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_PCRE_Match_Class_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, match_class_fields, Con_String_new_c_str(vm, "init"), match_class_init_func);
	// lookup
	match_class_lookup_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_PCRE_Match_Class_lookup_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "lookup"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, match_class_fields, Con_String_new_c_str(vm, "lookup"), match_class_lookup_func);
	
	match_class = Con_Meta_C_Class_new(vm, Con_String_new_c_str(vm, "Match"), match_class_supers, match_class_fields, sizeof(Con_PCRE_Match_Object));
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "Match", match_class);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}


// compile

void _Con_Mod_PCRE_compile_func(Con_VM* vm)
{
	Con_Value pattern;
	
	Con_VM_decode_args(vm, "s", &pattern);
	
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_VM_apply_c(vm, Con_Object_get_slot(vm, vm->continuation->module->module_val, "Pattern"), 1, pattern));
	Con_VM_return(vm);
}



////////////////////////////////////////////////////////////////////////////////////////////////////
// class Pattern
//

void _Con_Mod_PCRE_PCRE_Class_init_func(Con_VM* vm)
{
	Con_Value self, pattern;
	Con_String_Object* pattern_string_obj;
	Con_PCRE_Pattern_Object* pattern_obj;
	const char* errptr;
	int erroffset;

	Con_VM_decode_args(vm, "os", &self, &pattern);
	self.datum.object->type = CON_OBJECT_PCRE_PATTERN;
	
	pattern_obj = (Con_PCRE_Pattern_Object*) self.datum.object;
	pattern_string_obj = (Con_String_Object*) pattern.datum.object;

	if ((pattern_obj->compiled_re = pcre_compile(pattern_string_obj->str, 0, &errptr, &erroffset, NULL)) == NULL)
		XXX

	if (pcre_fullinfo(pattern_obj->compiled_re, NULL, PCRE_INFO_CAPTURECOUNT, &pattern_obj->num_captures) != 0)
		XXX

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_Mod_PCRE_Pattern_Class_match_func(Con_VM* vm)
{
	Con_Value self, string, match, start_pos_val;
	Con_PCRE_Pattern_Object* pattern_obj;
	Con_String_Object* string_obj;
	int* ovector;
	int ovector_size, start_pos, err;

	Con_VM_decode_args(vm, "os;i", &self, &string, &start_pos_val);
	pattern_obj = (Con_PCRE_Pattern_Object*) self.datum.object;
	string_obj = (Con_String_Object*) string.datum.object;

	if (Con_VM_is(vm, start_pos_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		start_pos = 0;
	else
		start_pos = start_pos_val.datum.integer;
	start_pos = Con_VM_translate_index(vm, start_pos, string_obj->str_size);

	ovector_size = (1 + pattern_obj->num_captures) * 3;
	ovector = Con_malloc(vm, ovector_size * sizeof(int), Con_MEMORY_GC);
	if ((err = pcre_exec(pattern_obj->compiled_re, NULL, string_obj->str, string_obj->str_size, start_pos, PCRE_ANCHORED, ovector, ovector_size)) < 0) {
		if (err == PCRE_ERROR_NOMATCH) {
			Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
			Con_VM_return(vm);
		}
		else
			XXX
	}

	match = Con_VM_apply_c(vm, Con_Object_get_slot(vm, vm->continuation->module->module_val, "Match"), 2, self, string);
	((Con_PCRE_Match_Object*) match.datum.object)->ovector = ovector;

	Con_VM_con_stack_push_value(vm, vm->continuation, match);
	Con_VM_return(vm);
}



////////////////////////////////////////////////////////////////////////////////////////////////////
// class Match
//


void _Con_Mod_PCRE_Match_Class_init_func(Con_VM* vm)
{
	Con_Value self, pattern, string;

	Con_VM_decode_args(vm, "oos", &self, &pattern, &string);
	self.datum.object->type = CON_OBJECT_PCRE_MATCH;

	Con_Object_set_slot(vm, self, "pattern", pattern);
	Con_Object_set_slot(vm, self, "string", string);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}


void _Con_Mod_PCRE_Match_Class_lookup_func(Con_VM* vm)
{
	Con_Value self, group_num, pattern;
	Con_PCRE_Match_Object* match_obj;
	Con_PCRE_Pattern_Object* pattern_obj;
	int index;

	Con_VM_decode_args(vm, "oi", &self, &group_num);
	match_obj = (Con_PCRE_Match_Object*) self.datum.object;
	
	pattern = Con_Object_get_slot(vm, self, "pattern");
	if (pattern.type != CON_VALUE_OBJECT || pattern.datum.object->type != CON_OBJECT_PCRE_PATTERN)
		XXX
	pattern_obj = (Con_PCRE_Pattern_Object*) pattern.datum.object;
	
	index = Con_VM_translate_index(vm, group_num.datum.integer, 1 + pattern_obj->num_captures);

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_slice(vm, Con_Object_get_slot(vm, self, "string"), match_obj->ovector[index * 2], match_obj->ovector[index * 2 + 1]));
	Con_VM_return(vm);
}
