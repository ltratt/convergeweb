void Con_Mod_VM_init(Con_VM* vm);
