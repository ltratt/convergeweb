typedef struct {
	CON_OBJECT_HEAD
	FILE* file;
	} Con_File_Object;

void Con_Mod_File_init(Con_VM* vm);
