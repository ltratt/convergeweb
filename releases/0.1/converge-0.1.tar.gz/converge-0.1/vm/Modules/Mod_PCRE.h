typedef struct {
	CON_OBJECT_HEAD
	pcre* compiled_re;
	int num_captures;
	} Con_PCRE_Pattern_Object;

typedef struct {
	CON_OBJECT_HEAD
	int* ovector;
	} Con_PCRE_Match_Object;


void Con_Mod_PCRE_init(Con_VM* vm);
