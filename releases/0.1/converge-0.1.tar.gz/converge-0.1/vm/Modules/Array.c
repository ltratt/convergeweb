#include <errno.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Object.h"
#include "Memory.h"
#include "Builtins/Dict.h"
#include "Builtins/Func.h"
#include "Builtins/String.h"
#include "Builtins/List.h"
#include "Builtins/Object_Class.h"
#include "Builtins/Int.h"
#include "Builtins/Meta_C_Class.h"
#include "Modules/Exceptions.h"

#include "Array.h"


void _Con_Mod_Array_append(Con_VM* vm, Con_Value array, Con_Value val);
Con_Value _Con_Mod_Array_lookup(Con_VM* vm, Con_Value array, int index);

void _Con_Mod_Array_create_func(Con_VM* vm);

void _Con_Mod_Array_Array_Class_init_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_append_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_to_str_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_set_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_len_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_extend_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_lookup_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_slice_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_append_from_string_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_iterate_func(Con_VM* vm);
void _Con_Mod_Array_Array_Class_serialize_func(Con_VM* vm);



void Con_Mod_Array_init(Con_VM* vm)
{
	Con_Value create_func;
	Con_Value array_exception_class, array_exception_class_supers, array_exception_class_fields;
	Con_Value array_class_supers, array_class_fields, array_class_init_func, array_class, array_class_append_func, array_class_to_str_func, array_class_set_func, array_class_len_func, array_class_extend_func, array_class_lookup_func, array_class_slice_func, array_class_append_from_string_func, array_class_iterate_func, array_class_serialize_func;

	create_func = Con_Func_new(vm, false, (Con_PC) (C_Function) _Con_Mod_Array_create_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "create"), 1, NULL, vm->continuation->module);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "create", create_func);

	// Class Array_Exception

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_CLASS_CLASS]);
	// Name
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_String_new_c_str(vm, "Array_Exception"));
	// Supers
	array_exception_class_supers = Con_List_new(vm);
	Con_List_append(vm, array_exception_class_supers, Con_Object_get_slot(vm, vm->builtins[CON_BUILTIN_EXCEPTIONS_MODULE], "Exception"));
	Con_VM_con_stack_push_value(vm, vm->continuation, array_exception_class_supers);
	// Fields
	array_exception_class_fields = Con_Dict_new(vm);
	// Push fields
	Con_VM_con_stack_push_value(vm, vm->continuation, array_exception_class_fields);
	Con_VM_apply(vm, 3);

	array_exception_class = Con_VM_con_stack_pop_value(vm, vm->continuation);
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "Array_Exception", array_exception_class);

	// Class Array

	// Supers
	array_class_supers = Con_List_new(vm);
	Con_List_append(vm, array_class_supers, vm->builtins[CON_BUILTIN_OBJECT_CLASS]);
	// Fields
	array_class_fields = Con_Dict_new(vm);
	// init
	array_class_init_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_init_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "init"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "init"), array_class_init_func);
	// append
	array_class_append_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_append_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "append"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "append"), array_class_append_func);
	// to_str
	array_class_to_str_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_to_str_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "to_str"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "to_str"), array_class_to_str_func);
	// set
	array_class_set_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_set_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "set"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "set"), array_class_set_func);
	// len
	array_class_len_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_len_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "len"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "len"), array_class_len_func);
	// extend
	array_class_extend_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_extend_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "extend"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "extend"), array_class_extend_func);
	// lookup
	array_class_lookup_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_lookup_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "lookup"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "lookup"), array_class_lookup_func);
	// slice
	array_class_slice_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_slice_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "slice"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "slice"), array_class_slice_func);
	// append_from_string
	array_class_append_from_string_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_append_from_string_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "append_from_string"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "append_from_string"), array_class_append_from_string_func);
	// iterate
	array_class_iterate_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_iterate_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "iterate"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "iterate"), array_class_iterate_func);
	// serialize
	array_class_serialize_func = Con_Func_new(vm, true, (Con_PC) (C_Function) _Con_Mod_Array_Array_Class_serialize_func, PC_TYPE_C_FUNCTION, Con_String_new_c_str(vm, "serialize"), 0, NULL, vm->continuation->module);
	Con_Dict_set_item(vm, array_class_fields, Con_String_new_c_str(vm, "serialize"), array_class_serialize_func);

	array_class = Con_Meta_C_Class_new(vm, Con_String_new_c_str(vm, "Array"), array_class_supers, array_class_fields, sizeof(Con_Mod_Array_Array_Object));
	Con_Object_set_slot(vm, vm->continuation->module->module_val, "Array", array_class);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



//


void _Con_Mod_Array_append(Con_VM* vm, Con_Value array, Con_Value val)
{
	Con_Mod_Array_Array_Object* array_obj;
	
	array_obj = (Con_Mod_Array_Array_Object*) array.datum.object;

	if (array_obj->num_elements == array_obj->num_elements_allocated) {
		switch (array_obj->array_type) {
			case CON_MOD_ARRAY_INT:
				array_obj->elements = Con_realloc(vm, array_obj->elements, (array_obj->num_elements_allocated + CON_MOD_ARRAY_INCREMENT) * sizeof(int));
				break;
			default:
				XXX
		}
		array_obj->num_elements_allocated += CON_MOD_ARRAY_INCREMENT;
	}
	
	switch (array_obj->array_type) {
		case CON_MOD_ARRAY_INT:
			if (!Con_VM_is_type(vm, val, "i"))
				Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, val, "instance_of"));
			((int*) array_obj->elements)[array_obj->num_elements] = val.datum.integer;
			break;
		default:
			XXX
	}
	array_obj->num_elements += 1;
}



Con_Value _Con_Mod_Array_lookup(Con_VM* vm, Con_Value array, int index)
{
	Con_Mod_Array_Array_Object* array_obj;
	
	array_obj = (Con_Mod_Array_Array_Object*) array.datum.object;
	index = Con_VM_translate_slice_index(vm, index, array_obj->num_elements);

	switch (array_obj->array_type) {
		case CON_MOD_ARRAY_INT:
			return Con_Int_new(((int*) array_obj->elements)[index]);
			break;
		default:
			XXX
	}
}


//
// create
//

void _Con_Mod_Array_create_func_loop(void);
void _Con_Mod_Array_create_func_exit(void);

extern Con_VM* Con_VM_execute_vm_switch;

void _Con_Mod_Array_create_func(Con_VM* vm)
{
	Con_Value type, initializer, new_array;

	Con_VM_decode_args(vm, "s;o", &type, &initializer);
	
	new_array = Con_VM_apply_c(vm, Con_Object_get_slot(vm, vm->continuation->module->module_val, "Array"), 1, type);
	Con_VM_var_set(vm, vm->continuation, 0, 0, new_array);
	if (Con_VM_is(vm, initializer, vm->builtins[CON_BUILTIN_NULL_VAL]))
		_Con_Mod_Array_create_func_exit();
	
	Con_VM_add_failure_frame(vm, (Con_PC) (C_Function) _Con_Mod_Array_create_func_exit, PC_TYPE_C_FUNCTION);
	Con_VM_add_fail_up_frame(vm);
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, initializer, "iterate"));
	Con_VM_apply_with_return(vm, 0, _Con_Mod_Array_create_func_loop, vm->continuation->pc, vm->continuation->pc_type);
}



void _Con_Mod_Array_create_func_loop(void)
{
	Con_VM* vm = Con_VM_execute_vm_switch;
	Con_Value val;

	val = Con_VM_con_stack_pop_value(vm, vm->continuation);
	Con_VM_add_fail_up_frame(vm);

	_Con_Mod_Array_append(vm, Con_VM_var_lookup(vm, vm->continuation, 0, 0), val);

	Con_VM_remove_failure_frame(vm);
	Con_VM_fail(vm);
}



void _Con_Mod_Array_create_func_exit(void)
{
	Con_VM* vm = Con_VM_execute_vm_switch;

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_VM_var_lookup(vm, vm->continuation, 0, 0));
	Con_VM_return(vm);
}


//
// Array
//

void _Con_Mod_Array_Array_Class_init_func(Con_VM* vm)
{
	Con_Value self, type;
	Con_Mod_Array_Array_Object* array_obj;

	Con_VM_decode_args(vm, "os", &self, &type);
	self.datum.object->type = CON_MOD_ARRAY_ARRAY;
	array_obj = (Con_Mod_Array_Array_Object*) self.datum.object;
	
	if (!Con_VM_equals(vm, type, Con_String_new_c_str(vm, "i")))
		Con_VM_raise(vm, Con_VM_apply_c(vm, Con_Object_get_slot(vm, vm->continuation->module->module_val, "Array_Exception"), 1, Con_String_new_c_str(vm, "Unknown array type.")));
		
	array_obj->array_type = CON_MOD_ARRAY_INT;

	array_obj->num_elements = 0;
	array_obj->num_elements_allocated = CON_MOD_ARRAY_INITIAL_SIZE;
	switch (array_obj->array_type) {
		case CON_MOD_ARRAY_INT:
			array_obj->elements = Con_malloc(vm, sizeof(int) * CON_MOD_ARRAY_INITIAL_SIZE, Con_MEMORY_NON_GC);
			break;
		default:
			XXX
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_Mod_Array_Array_Class_append_func(Con_VM* vm)
{
	Con_Value self, val;

	Con_VM_decode_args(vm, "oo", &self, &val);

	_Con_Mod_Array_append(vm, self, val);

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}




void _Con_Mod_Array_Array_Class_to_str_func(Con_VM* vm)
{
	XXX
}



void _Con_Mod_Array_Array_Class_set_func(Con_VM* vm)
{
	Con_Value self, index_val, val;
	Con_Mod_Array_Array_Object* array_obj;
	int index;

	Con_VM_decode_args(vm, "oio", &self, &index_val, &val);
	array_obj = (Con_Mod_Array_Array_Object*) self.datum.object;	

	index = Con_VM_translate_index(vm, index_val.datum.integer, array_obj->num_elements);
	
	switch (array_obj->array_type) {
		case CON_MOD_ARRAY_INT:
			if (!Con_VM_is_type(vm, val, "i"))
				Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, val, "instance_of"));
			((int*) array_obj->elements)[index] = val.datum.integer;
			break;
		default:
			XXX
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



void _Con_Mod_Array_Array_Class_len_func(Con_VM* vm)
{
	Con_Value self;
	Con_Mod_Array_Array_Object* array_obj;

	Con_VM_decode_args(vm, "o", &self);
	array_obj = (Con_Mod_Array_Array_Object*) self.datum.object;	

	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(array_obj->num_elements));
	Con_VM_return(vm);
}



// extend

void _Con_Mod_Array_Array_Class_extend_func(Con_VM* vm)
{
	Con_Value self, other;
	Con_Mod_Array_Array_Object* array_obj;
	Con_Mod_Array_Array_Object* other_array_obj;
	int increment;

	Con_VM_decode_args(vm, "oo", &self, &other);
	array_obj = (Con_Mod_Array_Array_Object*) self.datum.object;
	
	if (!((other.type == CON_VALUE_OBJECT) && (other.datum.object->type == CON_MOD_ARRAY_ARRAY)))
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, Con_Object_get_slot(vm, self, "instance_of"), Con_Object_get_slot(vm, other, "instance_of"));
	
	other_array_obj = (Con_Mod_Array_Array_Object*) other.datum.object;
	
	if (other_array_obj->array_type != array_obj->array_type)
		Con_Mod_Exceptions_quick(vm, "Type_Exception", 1, Con_String_new_c_str(vm, "XXX"));

	if (array_obj->num_elements + other_array_obj->num_elements >= array_obj->num_elements) {
		increment = other_array_obj->num_elements_allocated;
		switch (array_obj->array_type) {
			case CON_MOD_ARRAY_INT:
				array_obj->elements = Con_realloc(vm, array_obj->elements, (array_obj->num_elements_allocated + increment) * sizeof(int));
				break;
			default:
				XXX
		}
		array_obj->num_elements_allocated += increment;
	}

	switch (array_obj->array_type) {
		case CON_MOD_ARRAY_INT:
			memmove(((int*) array_obj->elements) + array_obj->num_elements, other_array_obj->elements, other_array_obj->num_elements * sizeof(int));
			break;
		default:
			XXX
	}
	array_obj->num_elements += other_array_obj->num_elements;
	
	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



// lookup

void _Con_Mod_Array_Array_Class_lookup_func(Con_VM* vm)
{
	Con_Value self, index_val;
	int index;
	Con_Mod_Array_Array_Object* array_obj;
	
	Con_VM_decode_args(vm, "oi", &self, &index_val);
	array_obj = (Con_Mod_Array_Array_Object*) self.datum.object;
	
	index = Con_VM_translate_index(vm, index_val.datum.integer, array_obj->num_elements);
	
	switch (array_obj->array_type) {
		case CON_MOD_ARRAY_INT:
			Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(((int*) array_obj->elements)[index]));
			break;
		default:
			XXX
	}
	
	Con_VM_return(vm);
}




// slice

void _Con_Mod_Array_Array_Class_slice_func(Con_VM* vm)
{
	Con_Value self, lower_val, upper_val, new_array;
	int lower, upper;
	Con_Mod_Array_Array_Object* array_obj;
	Con_Mod_Array_Array_Object* new_array_obj;

	Con_VM_decode_args(vm, "o;oo", &self, &lower_val, &upper_val);
	array_obj = (Con_Mod_Array_Array_Object*) self.datum.object;
	
	if (Con_VM_is(vm, lower_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		lower = 0;
	else {
		if (!Con_VM_is_type(vm, lower_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, lower_val, "instance_of"));
		lower = lower_val.datum.integer;
	}
	lower = Con_VM_translate_slice_index(vm, lower, array_obj->num_elements);

	if (Con_VM_is(vm, upper_val, vm->builtins[CON_BUILTIN_NULL_VAL]))
		upper = array_obj->num_elements;
	else {
		if (!Con_VM_is_type(vm, upper_val, "i"))
			Con_Mod_Exceptions_quick(vm, "Type_Exception", 2, vm->builtins[CON_BUILTIN_INT_CLASS], Con_Object_get_slot(vm, upper_val, "instance_of"));
		upper = upper_val.datum.integer;
	}
	upper = Con_VM_translate_slice_index(vm, upper, array_obj->num_elements);

	switch (array_obj->array_type) {
		case CON_MOD_ARRAY_INT:
			new_array = Con_VM_apply_c(vm, Con_Object_get_slot(vm, vm->continuation->module->module_val, "create"), 1, Con_String_new_c_str(vm, "i"));
			new_array_obj = (Con_Mod_Array_Array_Object*) new_array.datum.object;
			new_array_obj->elements = Con_realloc(vm, new_array_obj->elements, (upper - lower) * sizeof(int));
			new_array_obj->num_elements_allocated = upper - lower;
			new_array_obj->num_elements = upper - lower;
			memmove(new_array_obj->elements, ((void*) array_obj->elements) + (lower * sizeof(int)), (upper - lower) * sizeof(int));
			break;
		default:
			XXX
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, new_array);
	Con_VM_return(vm);
}



// append_from_string

void _Con_Mod_Array_Array_Class_append_from_string_func(Con_VM* vm)
{
	Con_Value self, str;
	Con_String_Object* str_obj;
	unsigned char* str_shorts;
	int i, byte1, byte2, byte3, byte4;

	Con_VM_decode_args(vm, "os", &self, &str);
	str_obj = (Con_String_Object*) str.datum.object;
	
	// check it's aligned
	
	if (str_obj->str_size % sizeof(int) != 0)
		XXX
	
	str_shorts = str_obj->str;
	for (i = 0; i < str_obj->str_size; i += 4) {
		byte1 = str_shorts[i];
		byte2 = str_shorts[i + 1];
		byte3 = str_shorts[i + 2];
		byte4 = str_shorts[i + 3];
		_Con_Mod_Array_append(vm, self, Con_Int_new(byte1 | (byte2 << 8) | (byte3 << 16) | (byte4 << 24)));
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_NULL_VAL]);
	Con_VM_return(vm);
}



// iterate

void _Con_Mod_Array_Array_Class_iterate_func(Con_VM* vm)
{
	Con_Value self;
	int i;
	Con_Mod_Array_Array_Object* array_obj;

	Con_VM_decode_args(vm, "o", &self);
	array_obj = (Con_Mod_Array_Array_Object*) self.datum.object;
	
	for (i = 0; i < array_obj->num_elements; i += 1) {
		switch (array_obj->array_type) {
			case CON_MOD_ARRAY_INT:
				Con_VM_con_stack_push_value(vm, vm->continuation, Con_Int_new(((int*) array_obj->elements)[i]));
				Con_VM_yield(vm);
				break;
			default:
				XXX
		}
	}

	Con_VM_con_stack_push_value(vm, vm->continuation, vm->builtins[CON_BUILTIN_FAIL_VAL]);
	Con_VM_return(vm);
}



// serialize

void _Con_Mod_Array_Array_Class_serialize_func(Con_VM* vm)
{
	Con_Value self, str_val;
	Con_Mod_Array_Array_Object* array_obj;
	Con_String_Object* str_obj;

	Con_VM_decode_args(vm, "o", &self);
	array_obj = (Con_Mod_Array_Array_Object*) self.datum.object;

	switch (array_obj->array_type) {
		case CON_MOD_ARRAY_INT:
			str_val = Con_String_new_blank(vm, array_obj->num_elements * sizeof(int));
			str_obj = (Con_String_Object*) str_val.datum.object;
			memmove(str_obj->str, array_obj->elements, array_obj->num_elements * sizeof(int));
			str_obj->str[(array_obj->num_elements * sizeof(int))] = 0;
			str_obj->hash = Con_String_hash(str_obj->str, array_obj->num_elements * sizeof(int));
			break;
		default:
			XXX
	}
	
	Con_VM_con_stack_push_value(vm, vm->continuation, str_val);
	Con_VM_return(vm);
}
