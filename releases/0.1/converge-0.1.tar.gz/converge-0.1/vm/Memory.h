#ifndef Con_MEMORY_H
#define Con_MEMORY_H

#include <stdlib.h>
#include <stdio.h>

#include "VM.h"


typedef enum {Con_MEMORY_OBJECT, Con_MEMORY_GC, Con_MEMORY_GC_NO_PTRS, Con_MEMORY_NON_GC} Con_Memory_Type;


#define Con_MEMORY_ENTRY_FLAGS_TYPE 0x0000000F
#define Con_MEMORY_ENTRY_MARK_BIT (1<<31)


typedef struct {
	void* ptr;
	} Con_Memory_Entry;

typedef struct {
	int flags;
	size_t size;
	} Con_Memory_Header;

#define Con_MEMORY_DEFAULT_NUM_ENTRIES 10000
#define Con_MEMORY_NUM_ENTRIES_INCREMENT 5000
#define Con_MEMORY_STACK_DEFAULT_SIZE (12*2048)

typedef struct {
	void* low_addr;
	void* high_addr;
	int num_entries;
	int num_entries_allocated;
	Con_Memory_Entry* entries;
	int mark_stack_size;
	int mark_stack_size_allocated;
	Con_Memory_Header** mark_stack;
	} Con_Memory_Info;


// Standard(ish) routines

void* Con_malloc(Con_VM* vm, size_t size, Con_Memory_Type type);
void* Con_malloc_normal(Con_VM* vm, size_t size);
void* Con_realloc(Con_VM* vm, void *ptr, size_t size);
void Con_free(Con_VM* vm, void* ptr);

// Garbage collector interface

void Con_Memory_gcollect(Con_VM* vm);
void Con_Memory_init(Con_VM* vm);

#endif /* Con_MEMORY_H */
