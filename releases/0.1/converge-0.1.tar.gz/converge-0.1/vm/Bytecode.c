#include <string.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"

#include "Bytecode.h"
#include "Memory.h"

#define BYTECODE_TO_STRING_BUFFER_SIZE 256



void Con_Bytecode_append_cvb(Con_VM* vm, Con_Bytecode* bytecode)
{
	Con_Bytecode* module_bytecode;
	int i;
	
	for (i = 0; i < bytecode[Con_BYTECODE_NUMBER_OF_MODULES]; i += 1) {
		module_bytecode = bytecode + (bytecode[Con_BYTECODE_MODULES + i] / sizeof(Con_Bytecode));
		Con_Bytecode_add_module(vm, module_bytecode);
	}
}



Con_Module* Con_Bytecode_add_module(Con_VM* vm, Con_Bytecode* module_bytecode)
{
	Con_Bytecode* imports_bytecode;
	Con_Module* module;
	int j, vm_bytecode_offset;

	vm_bytecode_offset = vm->bytecode_size;
	vm->bytecode = Con_realloc(vm, vm->bytecode, vm->bytecode_size + module_bytecode[Con_BYTECODE_MODULE_SIZE]);
	memmove(((void*) vm->bytecode) + vm->bytecode_size, module_bytecode, module_bytecode[Con_BYTECODE_MODULE_SIZE]);
	vm->bytecode_size += module_bytecode[Con_BYTECODE_MODULE_SIZE];

	module = Con_malloc(vm, sizeof(Con_Module), Con_MEMORY_NON_GC);
	
	// Copy the module name
	module->module_name = Con_malloc(vm, module_bytecode[Con_BYTECODE_MODULE_NAME_SIZE] + 1, Con_MEMORY_NON_GC);
	memmove(module->module_name, module_bytecode + module_bytecode[Con_BYTECODE_MODULE_NAME] / sizeof(Con_Bytecode), module_bytecode[Con_BYTECODE_MODULE_NAME_SIZE]);
	module->module_name[module_bytecode[Con_BYTECODE_MODULE_NAME_SIZE]] = 0;
	module->type = module_bytecode[Con_BYTECODE_MODULE_TYPE];
	module->module_val.type = CON_VALUE_UNASSIGNED;
	if (module_bytecode[Con_BYTECODE_MODULE_TYPE] == Con_IMPORT_BUILTIN) {
		module->pc_type = PC_TYPE_C_FUNCTION;
	}
	else {
		module->pc.bytecode = vm_bytecode_offset + module_bytecode[Con_BYTECODE_MODULE_PROGRAM];
		module->pc_type = PC_TYPE_BYTECODE;
		module->num_local_vars = module_bytecode[Con_BYTECODE_MODULE_LOCAL_VARS];
		module->module_val.type = CON_VALUE_UNASSIGNED;
		module->bytecode_offset = vm_bytecode_offset;

		// Copy the full name
		module->full_name = Con_malloc(vm, module_bytecode[Con_BYTECODE_MODULE_FULL_NAME_SIZE] + 1, Con_MEMORY_NON_GC);
		memmove(module->full_name, module_bytecode + module_bytecode[Con_BYTECODE_MODULE_FULL_NAME] / sizeof(Con_Bytecode), module_bytecode[Con_BYTECODE_MODULE_FULL_NAME_SIZE]);
		module->full_name[module_bytecode[Con_BYTECODE_MODULE_FULL_NAME_SIZE]] = 0;
	}
	module->imports = Con_malloc(vm, module_bytecode[Con_BYTECODE_NUM_IMPORTS] * sizeof(Con_Module_Import), Con_MEMORY_NON_GC);
	imports_bytecode = module_bytecode + module_bytecode[Con_BYTECODE_IMPORTS] / sizeof(Con_Bytecode);
	for (j = 0; j < module_bytecode[Con_BYTECODE_NUM_IMPORTS]; j += 1) {
		module->imports[j].type = imports_bytecode[Con_BYTECODE_MODULE_IMPORT_TYPE];
		module->imports[j].full_name = Con_malloc(vm, imports_bytecode[Con_BYTECODE_MODULE_IMPORT_FULL_NAME_SIZE] + 1, Con_MEMORY_NON_GC);
		memmove(module->imports[j].full_name, imports_bytecode + Con_BYTECODE_MODULE_IMPORT_FULL_NAME, imports_bytecode[Con_BYTECODE_MODULE_IMPORT_FULL_NAME_SIZE]);
		module->imports[j].full_name[imports_bytecode[Con_BYTECODE_MODULE_IMPORT_FULL_NAME_SIZE]] = 0;
		imports_bytecode += Con_BYTECODE_MODULE_IMPORT_FULL_NAME + Con_Bytecode_align(imports_bytecode[Con_BYTECODE_MODULE_IMPORT_FULL_NAME_SIZE]) / sizeof(Con_Bytecode);
	}
	if (vm->modules_size == vm->modules_size_allocated) {
		vm->modules = Con_realloc(vm, vm->modules, (vm->modules_size_allocated + CON_VM_MODULES_SIZE_ALLOCATED_INCREMENT) * sizeof(Con_Module*));
		vm->modules_size_allocated += CON_VM_MODULES_SIZE_ALLOCATED_INCREMENT;
	}
	vm->modules[vm->modules_size] = module;
	vm->modules_size += 1;

	return module;
}



char* Con_Bytecode_to_string(Con_VM* vm, int bytecode_offset)
{
	char* result;
	int instruction, offset, int_val;

	result = Con_malloc(vm, BYTECODE_TO_STRING_BUFFER_SIZE, Con_MEMORY_NON_GC);
	instruction = vm->bytecode[vm->continuation->pc.bytecode / sizeof(Con_Bytecode)];
	switch (instruction & 0x000000FF) {
		case Con_INSTR_ASSIGN:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "ASSIGN") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_POP:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "POP") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_VAR_REF:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "VAR_REF %d %d", (instruction & 0x000FFF00) >> 8, (instruction & 0xFFF0000) >> 20) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_PULL:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "PULL %d", (instruction & 0xFFFFFF00) >> 8) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_BUILTIN_LOOKUP:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "BUILTIN_LOOKUP %d", (instruction & 0x0000FF00) >> 8) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_FUNC_DEF:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "FUNC_DEF %d %d %.*s", (instruction & 0x0000FF00) >> 8, (instruction & 0xFF000000) >> 24, (instruction & 0x00FF0000) >> 16, (char*) &vm->bytecode[(vm->continuation->pc.bytecode + sizeof(Con_Bytecode)) / sizeof(Con_Bytecode)]) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_BRANCH:
			offset = (instruction & 0x7FFFFF00) >> 8;
			if (instruction & (1 << 31))
				offset = -offset;
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "BRANCH %d", offset) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_DICT:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "DICT %d", (instruction & 0xFFFFFF00) >> 8) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_ADD_FAILURE_FRAME:
			offset = (instruction & 0x7FFFFF00) >> 8;
			if (instruction & (1 << 31))
				offset = -offset;
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "ADD_FAILURE_FRAME %d", offset) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_IS_ASSIGNED:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "IS_ASSIGNED") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_REMOVE_FAILURE_FRAME:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "REMOVE_FAILURE_FRAME") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_DUP:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "DUP") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_SLOT_LOOKUP:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "SLOT_LOOKUP %.*s", (int) (instruction & 0xFFFFFF00) >> 8, (char*) &vm->bytecode[(vm->continuation->pc.bytecode + sizeof(Con_Bytecode)) / sizeof(Con_Bytecode)]) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_STRING:
//			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "STRING %.*s", (int) (instruction & 0xFFFFFF00) >> 8, (char*) &vm->bytecode[(vm->continuation->pc.bytecode + sizeof(Con_Bytecode)) / sizeof(Con_Bytecode)]) >= BYTECODE_TO_STRING_BUFFER_SIZE)
//				CON_FATAL_ERROR_OVERFLOW;
			snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "STRING %.*s", (int) (instruction & 0xFFFFFF00) >> 8, (char*) &vm->bytecode[(vm->continuation->pc.bytecode + sizeof(Con_Bytecode)) / sizeof(Con_Bytecode)]);
			break;
		case Con_INSTR_VAR_LOOKUP:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "VAR_LOOKUP %d %d", (instruction & 0x000FFF00) >> 8, (instruction & 0xFFF0000) >> 20) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_APPLY:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "APPLY %d", (instruction & 0x0000FF00) >> 8) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_SET_ITEM:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "SET_ITEM") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_RETURN:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "RETURN") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_SLOT_REF:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "SLOT_REF %.*s", (int) (instruction & 0xFFFFFF00) >> 8, (char*) &vm->bytecode[(vm->continuation->pc.bytecode + sizeof(Con_Bytecode)) / sizeof(Con_Bytecode)]) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_INT:
			int_val = (instruction & 0x7FFFFF00) >> 8;
			if (instruction & (1 << 31))
				int_val = -int_val;
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "INT %d", int_val) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_EQUALS:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "EQUALS") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_SUBTRACT:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "SUBTRACT") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_CHANGE_FAIL_POINT:
			int_val = (instruction & 0x7FFFFF00) >> 8;
			if (instruction & (1 << 31))
				int_val = -int_val;
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "CHANGE_FAIL_POINT %d", int_val) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_NOT_EQUALS:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "NOT_EQUALS") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_ADD_FAIL_UP_FRAME:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "ADD_FAIL_UP_FRAME") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_LIST:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "LIST %d", (instruction & 0xFFFFFF00) >> 8) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_ADD:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "ADD") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_LESS_THAN:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "LESS_THAN") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_YIELD:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "YIELD") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_FAIL_NOW:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "FAIL_NOW") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_EYIELD:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "EYIELD") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_GREATER_THAN:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "GREATER_THAN") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_INSTANCE_OF:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "INSTANCE_OF") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_IMPORT:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "IMPORT %d", (int) (instruction & 0xFFFFFF00) >> 8) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_IS:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "IS") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_UNPACK_ARGS:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "UNPACK_ARGS %d %d %s", (instruction & 0x0000FF00) >> 8, (instruction & 0x00FF0000) >> 16, (instruction & (1 << 31)) == 1 << 31 ? "true" : "false") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_RAISE:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "RAISE") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_ADD_EXCEPTION_FRAME:
			offset = (instruction & 0x7FFFFF00) >> 8;
			if (instruction & (1 << 31))
				offset = -offset;
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "ADD_EXCEPTION_FRAME %d", offset) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_PUSH_EXCEPTION:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "PUSH_EXCEPTION") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_GREATER_THAN_EQUALS:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "GREATER_THAN_EQUALS") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_LESS_THAN_EQUALS:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "LESS_THAN_EQUALS") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_MUL:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "MUL") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_DIVIDE:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "DIVIDE") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_MODULO:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "MODULO") >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_SET:
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "SET %d", (instruction & 0xFFFFFF00) >> 8) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		case Con_INSTR_BRANCH_IF_NOT_FAIL:
			offset = (instruction & 0x7FFFFF00) >> 8;
			if (instruction & (1 << 31))
				offset = -offset;
			if (snprintf(result, BYTECODE_TO_STRING_BUFFER_SIZE, "BRANCH_IF_NOT_FAIL %d", offset) >= BYTECODE_TO_STRING_BUFFER_SIZE)
				CON_FATAL_ERROR_OVERFLOW;
			break;
		default:
			printf("Unknown instruction %d at %d\n", instruction & 0x000000FF, vm->continuation->pc.bytecode);
			exit(1);
	}
	
	return result;
}



int Con_Bytecode_align(int bytecode_offset)
{
	int new_offset;
	
	new_offset = (bytecode_offset / sizeof(Con_Bytecode)) * sizeof(Con_Bytecode);
	if (bytecode_offset % sizeof(Con_Bytecode) != 0)
		new_offset += sizeof(Con_Bytecode);
	
	return new_offset;
}
