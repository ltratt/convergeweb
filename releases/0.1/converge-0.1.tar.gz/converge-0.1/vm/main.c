#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/param.h>

#include "Config.h"
#include "Converge.h"
#include "VM.h"
#include "Bytecode.h"
#include "Import.h"
#include "Builtins/Func_Binding.h"
#include "Memory.h"
#include "Object.h"

#include "Builtins/String.h"

#include "Modules/Exceptions.h"


void main_1(Con_VM* vm);
void main_2(Con_VM* vm);


int main(int argc, char **argv) {
	Con_VM* vm = NULL;
	Con_Continuation* continuation;
	Con_Bytecode* bytecode;
	FILE* input_file;
	char* program_path;
	struct stat input_file_stat;

	if (DEBUG)
		printf("%s %s (%s) %s\n", NAME, VERSION, DATE, COPYRIGHT);

	Con_Memory_init(vm);

	if (argc == 1) {
		fprintf(stderr, "Usage: converge <file> [args]\n");
		exit(1);
	}
	
	if (stat(argv[1], &input_file_stat) == -1) {
		fprintf(stderr, "Error trying to stat %s\n", argv[1]);
		exit(1);
	}
	
	input_file = fopen(argv[1], "rb");
	if (input_file == NULL) {
		fprintf(stderr, "Unable to open %s\n", argv[1]);
		exit(1);
	}

	program_path = Con_malloc(vm, MAXPATHLEN, Con_MEMORY_NON_GC);
	if (realpath(argv[1], program_path) == NULL)
		program_path = NULL;

	vm = Con_VM_create(argv + 2, argc - 2, program_path);

	bytecode = Con_malloc(vm, input_file_stat.st_size, Con_MEMORY_NON_GC);
	fread(bytecode, 1, input_file_stat.st_size, input_file);

	Con_Bytecode_append_cvb(vm, bytecode);

	continuation = Con_VM_continuation_create(vm, 0, NULL, NULL, NULL, vm->builtins[CON_BUILTIN_NULL_VAL]);
	continuation->pc.c_function = (C_Function) main_1;
	continuation->pc_type = PC_TYPE_C_FUNCTION;

	Con_VM_execute(vm, continuation, NULL, (Con_PC) (C_Function) NULL, PC_TYPE_NULL);
	
	return 0;
}



void main_1(Con_VM* vm)
{
	Con_Value main_module;
	
	Con_VM_init(vm);

	Con_VM_add_failure_frame(vm, (Con_PC) (C_Function) main_2, PC_TYPE_C_FUNCTION);
#if DEBUG
	printf("Importing main module...\n");
#endif
	main_module = Con_Import_module(vm, vm->modules[0]);
	if (!Con_Object_has_slot(vm, main_module, "main"))
		Con_Mod_Exceptions_quick(vm, "Exception", 1, Con_String_new_c_str(vm, "Main module is missing 'main' function."));
	Con_VM_con_stack_push_value(vm, vm->continuation, Con_Object_get_slot(vm, main_module, "main"));
#if DEBUG
	printf("Calling main function...\n");
#endif

	Con_VM_apply(vm, 0);
	
	Con_Memory_gcollect(vm);
	
	exit(0);
}



void main_2(Con_VM* vm)
{
	// main returned fail, which we define to mean success of the overall program

	Con_Memory_gcollect(vm);
	
	exit(0);
}
