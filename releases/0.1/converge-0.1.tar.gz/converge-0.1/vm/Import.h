#include "VM.h"

Con_Value Con_Import_module(Con_VM* vm, Con_Module* module);
Con_Value Con_Import_module_in_bytecode(Con_VM* vm, int module_num);
Con_Value Con_Import_builtin_module(Con_VM* vm, const char* name);
Con_Value Con_Import_user_module(Con_VM* vm, char* name);
